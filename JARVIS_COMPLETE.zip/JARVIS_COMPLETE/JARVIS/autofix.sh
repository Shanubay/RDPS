#!/bin/bash

RED='\033[0;31m'; GREEN='\033[0;32m'
YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'

echo -e "${CYAN}"
echo "  ╔══════════════════════════════════════╗"
echo "  ║     JARVIS AUTO-FIX SCRIPT v2        ║"
echo "  ╚══════════════════════════════════════╝"
echo -e "${NC}"

# ── Auto detect Java 17 ───────────────────────────────────────────────────
echo -e "${CYAN}[1] Finding Java 17...${NC}"
JAVA17=""
for p in \
  /usr/lib/jvm/java-17-openjdk-amd64 \
  /usr/lib/jvm/java-17-openjdk \
  /usr/lib/jvm/java-17 \
  /usr/local/lib/jvm/java-17 \
  $(update-alternatives --list java 2>/dev/null | grep "17" | sed 's|/bin/java||'); do
  if [ -f "$p/bin/java" ]; then
    JAVA17="$p"
    break
  fi
done

if [ -z "$JAVA17" ]; then
  echo -e "${YELLOW}  Java 17 not found. Installing...${NC}"
  sudo apt-get install -y openjdk-17-jdk -q
  JAVA17=/usr/lib/jvm/java-17-openjdk-amd64
fi

echo -e "${GREEN}  ✔ Java 17 found: $JAVA17${NC}"
export JAVA_HOME=$JAVA17
export PATH=$JAVA_HOME/bin:$PATH

# Update gradle.properties
sed -i '/org.gradle.java.home/d' gradle.properties
echo "org.gradle.java.home=$JAVA17" >> gradle.properties
echo -e "${GREEN}  ✔ gradle.properties updated${NC}"

# ── Fix XML namespaces ────────────────────────────────────────────────────
echo -e "${CYAN}[2] Fixing XML namespaces...${NC}"
find app/src/main/res -name "*.xml" | while read f; do
  if grep -q 'tools:' "$f" && ! grep -q 'xmlns:tools' "$f"; then
    sed -i 's|<resources>|<resources xmlns:tools="http://schemas.android.com/tools">|g' "$f"
    echo -e "${GREEN}  ✔ Fixed: $f${NC}"
  fi
done

# ── Fix themes.xml ────────────────────────────────────────────────────────
echo -e "${CYAN}[3] Fixing themes.xml...${NC}"
cat > app/src/main/res/values/themes.xml << 'THEMES'
<?xml version="1.0" encoding="utf-8"?>
<resources xmlns:tools="http://schemas.android.com/tools">
    <style name="Theme.Jarvis" parent="Theme.AppCompat.NoActionBar">
        <item name="android:windowBackground">@color/jarvis_bg</item>
        <item name="android:statusBarColor">@color/jarvis_bg</item>
        <item name="android:navigationBarColor">@color/jarvis_bg</item>
        <item name="android:windowLightStatusBar" tools:targetApi="m">false</item>
        <item name="android:windowLightNavigationBar" tools:targetApi="o_mr1">false</item>
        <item name="android:windowTranslucentStatus">false</item>
        <item name="android:windowTranslucentNavigation">false</item>
    </style>
    <style name="Theme.Jarvis.Splash" parent="Theme.SplashScreen">
        <item name="windowSplashScreenBackground">@color/jarvis_bg</item>
        <item name="windowSplashScreenAnimatedIcon">@drawable/ic_jarvis_logo</item>
        <item name="windowSplashScreenAnimationDuration">1000</item>
        <item name="postSplashScreenTheme">@style/Theme.Jarvis</item>
    </style>
</resources>
THEMES
echo -e "${GREEN}  ✔ themes.xml fixed${NC}"

# ── Fix colors.xml ────────────────────────────────────────────────────────
echo -e "${CYAN}[4] Fixing colors.xml...${NC}"
cat > app/src/main/res/values/colors.xml << 'COLORS'
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="jarvis_bg">#FF030508</color>
    <color name="jarvis_cyan">#FF00D4FF</color>
    <color name="jarvis_gold">#FFFFB800</color>
    <color name="jarvis_red">#FFFF3B30</color>
    <color name="jarvis_green">#FF00FF88</color>
    <color name="black">#FF000000</color>
    <color name="white">#FFFFFFFF</color>
</resources>
COLORS
echo -e "${GREEN}  ✔ colors.xml fixed${NC}"

# ── Fix gradlew ───────────────────────────────────────────────────────────
echo -e "${CYAN}[5] Fixing gradlew...${NC}"
chmod +x gradlew 2>/dev/null
if [ ! -f "gradlew" ]; then
  gradle wrapper --gradle-version 8.7 --distribution-type bin
fi
echo -e "${GREEN}  ✔ gradlew OK${NC}"

# ── Clean cache ───────────────────────────────────────────────────────────
echo -e "${CYAN}[6] Cleaning cache...${NC}"
rm -rf app/build/generated app/build/tmp .gradle/caches/build-cache 2>/dev/null
echo -e "${GREEN}  ✔ Cache cleared${NC}"

# ── Build ─────────────────────────────────────────────────────────────────
echo -e "\n${CYAN}[7] Building...${NC}\n"
./gradlew clean assembleDebug 2>&1 | tee /tmp/jarvis_build.log | tail -50

if grep -q "BUILD SUCCESSFUL" /tmp/jarvis_build.log; then
  echo -e "\n${GREEN}  ╔══════════════════════════════════╗"
  echo "  ║   ✔  BUILD SUCCESSFUL!           ║"
  echo "  ║   APK: app/build/outputs/apk/    ║"
  echo -e "  ╚══════════════════════════════════╝${NC}"
else
  echo -e "\n${RED}  BUILD FAILED — Top errors:${NC}"
  grep -E "^e:|error:|Error:" /tmp/jarvis_build.log | grep -v "^>" | head -15
  echo -e "${YELLOW}  Full log: cat /tmp/jarvis_build.log${NC}"
fi
