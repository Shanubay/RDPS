package com.jarvis.assistant.core.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioManager

/**
 * PowerEventReceiver — Responds to power connection events.
 *
 * Charger plugged   → Enable full-power AI mode
 * Charger unplugged → Switch to battery-optimized mode
 * Battery low       → Switch to minimum power mode
 */
class PowerEventReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_POWER_CONNECTED -> {
                // Full power mode — enable cloud AI, high quality TTS
                broadcastPowerMode(context, PowerMode.CHARGING)
            }
            Intent.ACTION_POWER_DISCONNECTED -> {
                // Battery mode — prefer local AI when possible
                broadcastPowerMode(context, PowerMode.BATTERY)
            }
            Intent.ACTION_BATTERY_LOW -> {
                // Critical battery — switch to ultra-low power
                broadcastPowerMode(context, PowerMode.LOW_BATTERY)
                // Optionally set silent mode
                val audioManager = context.getSystemService(AudioManager::class.java)
                audioManager?.ringerMode = AudioManager.RINGER_MODE_SILENT
            }
        }
    }

    private fun broadcastPowerMode(context: Context, mode: PowerMode) {
        val intent = Intent(ACTION_POWER_MODE_CHANGED).apply {
            putExtra(EXTRA_POWER_MODE, mode.name)
            setPackage(context.packageName)
        }
        context.sendBroadcast(intent)
    }

    enum class PowerMode { CHARGING, BATTERY, LOW_BATTERY }

    companion object {
        const val ACTION_POWER_MODE_CHANGED = "com.jarvis.action.POWER_MODE_CHANGED"
        const val EXTRA_POWER_MODE = "power_mode"
    }
}
