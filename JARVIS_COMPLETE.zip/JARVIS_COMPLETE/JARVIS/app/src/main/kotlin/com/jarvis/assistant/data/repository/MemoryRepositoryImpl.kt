package com.jarvis.assistant.data.repository

import com.jarvis.assistant.core.constants.AppConstants
import com.jarvis.assistant.core.utils.EmbeddingUtils
import com.jarvis.assistant.data.local.JarvisDatabase
import com.jarvis.assistant.data.local.toDomain
import com.jarvis.assistant.data.local.toEntity
import com.jarvis.assistant.domain.entities.Memory
import com.jarvis.assistant.domain.entities.MemoryType
import com.jarvis.assistant.domain.repository.MemoryRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MemoryRepositoryImpl @Inject constructor(
    private val db: JarvisDatabase,
    private val embeddingUtils: EmbeddingUtils
) : MemoryRepository {

    private val dao get() = db.memoryDao()

    override fun getAllMemories(): Flow<List<Memory>> =
        dao.getAllMemories().map { list -> list.map { it.toDomain() } }

    override fun getMemoriesByType(type: MemoryType): Flow<List<Memory>> =
        dao.getMemoriesByType(type.name).map { list -> list.map { it.toDomain() } }

    override fun getTopMemories(limit: Int): Flow<List<Memory>> =
        dao.getTopMemories(limit).map { list -> list.map { it.toDomain() } }

    override suspend fun insertMemory(memory: Memory) {
        // Deduplicate — don't save if exact content already exists
        val existing = dao.findByExactContent(memory.content)
        if (existing != null) {
            dao.touchMemory(existing.id)
            return
        }

        // Prune if at capacity
        val count = dao.getMemoryCount()
        if (count >= AppConstants.MAX_LONG_TERM_MEMORIES) {
            dao.pruneLowestPriorityMemories(10)
        }

        // Embed if no embedding provided
        val withEmbedding = if (memory.embeddingStr.isBlank()) {
            val vec = embeddingUtils.embed(memory.content)
            memory.copy(
                embedding    = vec,
                embeddingStr = embeddingUtils.serializeEmbedding(vec)
            )
        } else memory

        dao.insertMemory(withEmbedding.toEntity())
    }

    override suspend fun updateMemory(memory: Memory) =
        dao.updateMemory(memory.toEntity())

    override suspend fun deleteMemory(memoryId: String) =
        dao.deleteMemory(memoryId)

    override suspend fun clearAllMemories() =
        dao.deleteAllMemories()

    override suspend fun getAllMemoriesWithEmbeddings(): List<Memory> =
        dao.getAllMemoriesWithEmbeddings().map { it.toDomain() }

    override suspend fun getContextMemories(limit: Int): List<Memory> =
        dao.getTopMemoriesOnce(limit).map { it.toDomain() }

    override suspend fun touchMemory(memoryId: String) =
        dao.touchMemory(memoryId)
}
