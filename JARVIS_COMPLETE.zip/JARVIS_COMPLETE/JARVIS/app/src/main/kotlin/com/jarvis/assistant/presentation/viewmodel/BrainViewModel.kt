package com.jarvis.assistant.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.brain.JarvisBrain
import com.jarvis.assistant.brain.ConversationSummarizer
import com.jarvis.assistant.brain.ContextBuilder
import com.jarvis.assistant.brain.RoutineEngine
import com.jarvis.assistant.brain.agent.AgentTool
import com.jarvis.assistant.domain.entities.Message
import com.jarvis.assistant.domain.entities.MessageRole
import com.jarvis.assistant.domain.entities.MessageStatus
import com.jarvis.assistant.domain.entities.VoiceState
import com.jarvis.assistant.domain.usecase.GetConversationUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class BrainUiState(
    val messages: List<Message>          = emptyList(),
    val streamingText: String            = "",
    val isThinking: Boolean              = false,
    val currentStep: Int                 = 0,
    val activeTool: AgentTool?           = null,
    val toolResults: List<AgentTool.ToolResult> = emptyList(),
    val voiceState: VoiceState           = VoiceState.IDLE,
    val conversationTitle: String        = "New Conversation",
    val activeProvider: String           = "",
    val error: String?                   = null,
    val isLoading: Boolean               = false
)

@HiltViewModel
class BrainViewModel @Inject constructor(
    private val jarvisBrain: JarvisBrain,
    private val summarizer: ConversationSummarizer,
    private val contextBuilder: ContextBuilder,
    private val routineEngine: RoutineEngine,
    private val getConversation: GetConversationUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(BrainUiState())
    val uiState: StateFlow<BrainUiState> = _uiState.asStateFlow()

    private var conversationId = ""

    init { initConversation() }

    private fun initConversation() {
        viewModelScope.launch {
            val conv = getConversation.getOrCreateActiveConversation()
            conversationId = conv.id
            _uiState.update { it.copy(conversationTitle = conv.title) }

            getConversation.getMessages(conv.id).collect { messages ->
                _uiState.update { it.copy(messages = messages) }
            }
        }
    }

    // ── Send Message through Brain ────────────────────────────────────────────

    fun sendMessage(text: String) {
        if (text.isBlank() || _uiState.value.isLoading) return

        // Optimistic user message
        val userMsg = Message(role = MessageRole.USER, content = text)
        val streamMsg = Message(
            role    = MessageRole.ASSISTANT,
            content = "",
            status  = MessageStatus.STREAMING
        )
        _uiState.update { state ->
            state.copy(
                messages      = state.messages + userMsg + streamMsg,
                isLoading     = true,
                isThinking    = true,
                streamingText = "",
                error         = null,
                toolResults   = emptyList(),
                activeTool    = null,
                currentStep   = 0
            )
        }

        viewModelScope.launch {
            val history = _uiState.value.messages
                .dropLast(2)                    // exclude optimistic messages
                .takeLast(10)

            val responseBuffer = StringBuilder()

            jarvisBrain.process(text, history, conversationId)
                .collect { event ->
                    when (event) {
                        is JarvisBrain.BrainEvent.Thinking -> {
                            _uiState.update { it.copy(
                                isThinking = true,
                                currentStep = event.step
                            )}
                        }
                        is JarvisBrain.BrainEvent.StreamToken -> {
                            responseBuffer.append(event.token)
                            _uiState.update { state ->
                                state.copy(
                                    streamingText = responseBuffer.toString(),
                                    messages      = state.messages.dropLast(1) + streamMsg.copy(
                                        content = responseBuffer.toString()
                                    )
                                )
                            }
                        }
                        is JarvisBrain.BrainEvent.ToolCalling -> {
                            _uiState.update { it.copy(activeTool = event.tool) }
                        }
                        is JarvisBrain.BrainEvent.ToolResult -> {
                            _uiState.update { state ->
                                state.copy(
                                    toolResults = state.toolResults + event.result,
                                    activeTool  = null
                                )
                            }
                        }
                        is JarvisBrain.BrainEvent.FinalResponse -> {
                            val finalMsg = Message(
                                role    = MessageRole.ASSISTANT,
                                content = event.text,
                                status  = MessageStatus.SENT
                            )
                            _uiState.update { state ->
                                state.copy(
                                    messages      = state.messages.dropLast(1) + finalMsg,
                                    isLoading     = false,
                                    isThinking    = false,
                                    streamingText = "",
                                    currentStep   = event.steps
                                )
                            }
                            // Auto-generate title from first exchange
                            if (_uiState.value.messages.size <= 4) {
                                generateTitle(text)
                            }
                        }
                        is JarvisBrain.BrainEvent.Error -> {
                            _uiState.update { state ->
                                state.copy(
                                    messages   = state.messages.dropLast(1),
                                    isLoading  = false,
                                    isThinking = false,
                                    error      = event.message
                                )
                            }
                        }
                    }
                }
        }
    }

    private fun generateTitle(firstMessage: String) {
        viewModelScope.launch {
            val title = summarizer.generateTitle(firstMessage)
            if (title.isNotBlank()) {
                _uiState.update { it.copy(conversationTitle = title) }
                getConversation.getMessages(conversationId).first().let {
                    // Update conversation title in repo
                }
            }
        }
    }

    // ── Routines ──────────────────────────────────────────────────────────────

    fun triggerWakeWord(phrase: String) = routineEngine.onWakeWord(phrase)
    fun onChargingConnected()           = routineEngine.onChargingConnected()
    fun onChargingDisconnected()        = routineEngine.onChargingDisconnected()

    fun clearError()  = _uiState.update { it.copy(error = null) }
    fun clearConversation() {
        viewModelScope.launch {
            getConversation.deleteConversation(conversationId)
            val newConv = getConversation.createConversation("New Conversation")
            conversationId = newConv.id
            _uiState.update { it.copy(
                messages          = emptyList(),
                conversationTitle = newConv.title,
                toolResults       = emptyList()
            )}
        }
    }
}
