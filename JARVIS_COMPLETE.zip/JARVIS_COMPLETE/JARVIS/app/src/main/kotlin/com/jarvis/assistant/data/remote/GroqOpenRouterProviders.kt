package com.jarvis.assistant.data.remote

import com.google.gson.Gson
import com.jarvis.assistant.core.constants.AppConstants
import com.jarvis.assistant.core.utils.AppPreferences
import com.jarvis.assistant.data.remote.api.OpenAiApi
import com.jarvis.assistant.data.remote.api.SseParser
import com.jarvis.assistant.data.remote.dto.OpenAiMessage
import com.jarvis.assistant.data.remote.dto.OpenAiRequest
import com.jarvis.assistant.domain.entities.Message
import com.jarvis.assistant.domain.entities.MessageRole
import com.jarvis.assistant.domain.usecase.AIProvider
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Inject
import javax.inject.Singleton

// ══════════════════════════════════════════════════════════════════════════════
// GroqProvider — ultra-fast inference via Groq's LPU hardware
// Model: llama-3.1-8b-instant (fastest) or mixtral-8x7b-32768
// ══════════════════════════════════════════════════════════════════════════════

@Singleton
class GroqProvider @Inject constructor(
    private val prefs: AppPreferences,
    private val gson: Gson,
    private val sseParser: SseParser,
    private val okHttpClient: OkHttpClient
) : AIProvider {

    override val id   = AppConstants.AIProvider.GROQ
    override val name = "Groq (Ultra Fast)"
    override val requiresInternet = true

    companion object {
        private const val MODEL_FAST    = "llama-3.1-8b-instant"
        private const val MODEL_QUALITY = "llama-3.1-70b-versatile"
    }

    private val api: OpenAiApi by lazy {
        Retrofit.Builder()
            .baseUrl(AppConstants.ApiUrl.GROQ)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()
            .create(OpenAiApi::class.java)
    }

    private suspend fun getKey() = prefs.groqKey.first()

    override suspend fun complete(
        messages: List<Message>,
        systemPrompt: String,
        maxTokens: Int,
        temperature: Float
    ): String {
        val key = getKey()
        if (key.isBlank()) return "[Groq key not set]"

        val request = OpenAiRequest(
            model       = MODEL_FAST,
            messages    = toOpenAiMessages(messages, systemPrompt),
            maxTokens   = maxTokens,
            temperature = temperature,
            stream      = false
        )

        val response = api.chatComplete("Bearer $key", request)
        if (!response.isSuccessful) {
            throw Exception("Groq HTTP ${response.code()}: ${response.errorBody()?.string()}")
        }
        return response.body()?.choices?.firstOrNull()?.message?.content
            ?: throw Exception("Empty Groq response")
    }

    override fun stream(
        messages: List<Message>,
        systemPrompt: String,
        maxTokens: Int,
        temperature: Float
    ): Flow<String> = flow {
        val key = getKey()
        if (key.isBlank()) { emit("[Groq key not set]"); return@flow }

        val request = OpenAiRequest(
            model       = MODEL_FAST,
            messages    = toOpenAiMessages(messages, systemPrompt),
            maxTokens   = maxTokens,
            temperature = temperature,
            stream      = true
        )

        val response = api.chatStream("Bearer $key", request)
        if (!response.isSuccessful) { emit("[Groq error: ${response.code()}]"); return@flow }
        val body = response.body() ?: run { emit("[Empty Groq stream]"); return@flow }
        sseParser.parseOpenAiStream(body).collect { emit(it) }
    }

    override suspend fun isAvailable(): Boolean = getKey().isNotBlank()

    private fun toOpenAiMessages(messages: List<Message>, systemPrompt: String) = buildList {
        add(OpenAiMessage("system", systemPrompt))
        messages.takeLast(AppConstants.MAX_CONTEXT_MESSAGES).forEach { msg ->
            add(OpenAiMessage(
                role    = if (msg.role == MessageRole.USER) "user" else "assistant",
                content = msg.content
            ))
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// OpenRouterProvider — fallback multi-model router
// Routes to best available free/paid model automatically
// ══════════════════════════════════════════════════════════════════════════════

@Singleton
class OpenRouterProvider @Inject constructor(
    private val prefs: AppPreferences,
    private val gson: Gson,
    private val sseParser: SseParser,
    private val okHttpClient: OkHttpClient
) : AIProvider {

    override val id   = AppConstants.AIProvider.OPENROUTER
    override val name = "OpenRouter (Fallback)"
    override val requiresInternet = true

    // Best free-tier models on OpenRouter
    private val FALLBACK_MODEL = "meta-llama/llama-3.1-8b-instruct:free"

    private val api: OpenAiApi by lazy {
        Retrofit.Builder()
            .baseUrl(AppConstants.ApiUrl.OPENROUTER)
            .client(
                okHttpClient.newBuilder()
                    .addInterceptor { chain ->
                        val request = chain.request().newBuilder()
                            .addHeader("HTTP-Referer", "https://jarvis-ai.app")
                            .addHeader("X-Title", "JARVIS AI Assistant")
                            .build()
                        chain.proceed(request)
                    }.build()
            )
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()
            .create(OpenAiApi::class.java)
    }

    private suspend fun getKey() = prefs.groqKey.first() // reuse field or add dedicated

    override suspend fun complete(
        messages: List<Message>,
        systemPrompt: String,
        maxTokens: Int,
        temperature: Float
    ): String {
        val key = prefs.aiProvider.first() // placeholder — add openrouter key pref
        val request = OpenAiRequest(
            model       = FALLBACK_MODEL,
            messages    = toMessages(messages, systemPrompt),
            maxTokens   = maxTokens,
            temperature = temperature,
            stream      = false
        )
        val response = api.chatComplete("Bearer $key", request)
        if (!response.isSuccessful) throw Exception("OpenRouter ${response.code()}")
        return response.body()?.choices?.firstOrNull()?.message?.content
            ?: throw Exception("Empty OpenRouter response")
    }

    override fun stream(
        messages: List<Message>,
        systemPrompt: String,
        maxTokens: Int,
        temperature: Float
    ): Flow<String> = flow {
        val key = prefs.aiProvider.first()
        val request = OpenAiRequest(
            model       = FALLBACK_MODEL,
            messages    = toMessages(messages, systemPrompt),
            maxTokens   = maxTokens,
            temperature = temperature,
            stream      = true
        )
        val response = api.chatStream("Bearer $key", request)
        if (!response.isSuccessful) { emit("[OpenRouter error: ${response.code()}]"); return@flow }
        val body = response.body() ?: return@flow
        sseParser.parseOpenAiStream(body).collect { emit(it) }
    }

    override suspend fun isAvailable(): Boolean = true // free tier always available

    private fun toMessages(messages: List<Message>, systemPrompt: String) = buildList {
        add(OpenAiMessage("system", systemPrompt))
        messages.takeLast(AppConstants.MAX_CONTEXT_MESSAGES).forEach { msg ->
            add(OpenAiMessage(
                role    = if (msg.role == MessageRole.USER) "user" else "assistant",
                content = msg.content
            ))
        }
    }
}
