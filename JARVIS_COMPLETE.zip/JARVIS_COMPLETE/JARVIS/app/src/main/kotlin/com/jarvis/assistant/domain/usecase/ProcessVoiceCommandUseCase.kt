package com.jarvis.assistant.domain.usecase

import com.jarvis.assistant.core.utils.*
import com.jarvis.assistant.domain.entities.*
import com.jarvis.assistant.domain.repository.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject

/**
 * ProcessVoiceCommandUseCase — handles the full voice interaction pipeline.
 *
 * Voice Input → Classify → Device Control OR AI Brain → TTS Output
 *
 * This is the central orchestrator for JARVIS voice mode.
 */
class ProcessVoiceCommandUseCase @Inject constructor(
    private val sendMessageUseCase: SendMessageUseCase,
    private val commandClassifier: CommandClassifier,
    private val intentRouter: IntentRouter,
    private val chatRepository: ChatRepository
) {

    sealed class VoiceResult {
        data class DeviceAction(val description: String, val success: Boolean) : VoiceResult()
        data class AiResponse(val text: String, val isStreaming: Boolean) : VoiceResult()
        data class StreamToken(val token: String) : VoiceResult()
        data class Error(val message: String) : VoiceResult()
        object Processing : VoiceResult()
    }

    operator fun invoke(
        transcript: String,
        conversationId: String
    ): Flow<VoiceResult> = flow {

        emit(VoiceResult.Processing)

        val classified = commandClassifier.classify(transcript)

        // ── Device control branch ─────────────────────────────────────────────
        if (classified.isDeviceControl) {
            val routed = intentRouter.route(transcript)
            when (routed) {
                is IntentRouter.RoutedIntent.Resolved -> {
                    try {
                        intentRouter.launchIntent(routed.intent)
                        emit(VoiceResult.DeviceAction(routed.description, true))
                        // Save to chat history
                        chatRepository.insertMessage(Message(
                            role    = MessageRole.USER,
                            content = transcript
                        ))
                        chatRepository.insertMessage(Message(
                            role    = MessageRole.ASSISTANT,
                            content = routed.description,
                            provider = "device"
                        ))
                    } catch (e: Exception) {
                        emit(VoiceResult.DeviceAction("Failed: ${e.message}", false))
                    }
                }
                is IntentRouter.RoutedIntent.NotFound -> {
                    // Fall through to AI for help
                    emitAll(streamAiResponse(transcript, conversationId))
                }
            }
            return@flow
        }

        // ── AI brain branch ───────────────────────────────────────────────────
        emitAll(streamAiResponse(transcript, conversationId))

    }.catch { e ->
        emit(VoiceResult.Error(e.message ?: "Voice processing failed"))
    }

    private fun streamAiResponse(
        text: String,
        conversationId: String
    ): Flow<VoiceResult> = sendMessageUseCase(text, conversationId)
        .map { result ->
            when (result) {
                is SendMessageUseCase.StreamResult.Token    ->
                    VoiceResult.StreamToken(result.text)
                is SendMessageUseCase.StreamResult.Complete ->
                    VoiceResult.AiResponse(result.fullText, false)
                is SendMessageUseCase.StreamResult.Error    ->
                    VoiceResult.Error(result.message)
                is SendMessageUseCase.StreamResult.Loading  ->
                    VoiceResult.Processing
            }
        }
}
