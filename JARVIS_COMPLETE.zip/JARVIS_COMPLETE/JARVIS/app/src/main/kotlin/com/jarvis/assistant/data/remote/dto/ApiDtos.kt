package com.jarvis.assistant.data.remote.dto

import com.google.gson.annotations.SerializedName

// ══════════════════════════════════════════════════════════════════════════════
// OpenAI / Groq / OpenRouter DTOs  (compatible API shape)
// ══════════════════════════════════════════════════════════════════════════════

data class OpenAiRequest(
    @SerializedName("model")       val model: String,
    @SerializedName("messages")    val messages: List<OpenAiMessage>,
    @SerializedName("max_tokens")  val maxTokens: Int    = 1024,
    @SerializedName("temperature") val temperature: Float = 0.7f,
    @SerializedName("stream")      val stream: Boolean   = false
)

data class OpenAiMessage(
    @SerializedName("role")    val role: String,
    @SerializedName("content") val content: String
)

data class OpenAiResponse(
    @SerializedName("id")      val id: String = "",
    @SerializedName("choices") val choices: List<OpenAiChoice> = emptyList(),
    @SerializedName("usage")   val usage: OpenAiUsage? = null,
    @SerializedName("error")   val error: OpenAiError? = null
)

data class OpenAiChoice(
    @SerializedName("index")         val index: Int = 0,
    @SerializedName("message")       val message: OpenAiMessage? = null,
    @SerializedName("delta")         val delta: OpenAiDelta? = null,
    @SerializedName("finish_reason") val finishReason: String? = null
)

data class OpenAiDelta(
    @SerializedName("role")    val role: String?    = null,
    @SerializedName("content") val content: String? = null
)

data class OpenAiUsage(
    @SerializedName("prompt_tokens")     val promptTokens: Int     = 0,
    @SerializedName("completion_tokens") val completionTokens: Int = 0,
    @SerializedName("total_tokens")      val totalTokens: Int      = 0
)

data class OpenAiError(
    @SerializedName("message") val message: String = "",
    @SerializedName("type")    val type: String    = "",
    @SerializedName("code")    val code: String?   = null
)

// SSE streaming chunk
data class OpenAiStreamChunk(
    @SerializedName("choices") val choices: List<OpenAiChoice> = emptyList()
)

// ══════════════════════════════════════════════════════════════════════════════
// Gemini DTOs
// ══════════════════════════════════════════════════════════════════════════════

data class GeminiRequest(
    @SerializedName("contents")          val contents: List<GeminiContent>,
    @SerializedName("systemInstruction") val systemInstruction: GeminiContent? = null,
    @SerializedName("generationConfig")  val generationConfig: GeminiGenerationConfig? = null
)

data class GeminiContent(
    @SerializedName("role")  val role: String,
    @SerializedName("parts") val parts: List<GeminiPart>
)

data class GeminiPart(
    @SerializedName("text") val text: String
)

data class GeminiGenerationConfig(
    @SerializedName("maxOutputTokens") val maxOutputTokens: Int   = 1024,
    @SerializedName("temperature")     val temperature: Float     = 0.7f,
    @SerializedName("topP")            val topP: Float            = 0.95f
)

data class GeminiResponse(
    @SerializedName("candidates")     val candidates: List<GeminiCandidate> = emptyList(),
    @SerializedName("usageMetadata")  val usageMetadata: GeminiUsage?       = null,
    @SerializedName("error")          val error: GeminiError?               = null
)

data class GeminiCandidate(
    @SerializedName("content")      val content: GeminiContent,
    @SerializedName("finishReason") val finishReason: String? = null
)

data class GeminiUsage(
    @SerializedName("promptTokenCount")     val promptTokens: Int     = 0,
    @SerializedName("candidatesTokenCount") val completionTokens: Int = 0
)

data class GeminiError(
    @SerializedName("code")    val code: Int    = 0,
    @SerializedName("message") val message: String = "",
    @SerializedName("status")  val status: String  = ""
)

// ══════════════════════════════════════════════════════════════════════════════
// ElevenLabs TTS DTOs
// ══════════════════════════════════════════════════════════════════════════════

data class ElevenLabsTtsRequest(
    @SerializedName("text")            val text: String,
    @SerializedName("model_id")        val modelId: String          = "eleven_turbo_v2",
    @SerializedName("voice_settings")  val voiceSettings: ElevenLabsVoiceSettings = ElevenLabsVoiceSettings()
)

data class ElevenLabsVoiceSettings(
    @SerializedName("stability")        val stability: Float       = 0.5f,
    @SerializedName("similarity_boost") val similarityBoost: Float = 0.75f,
    @SerializedName("style")            val style: Float           = 0.0f,
    @SerializedName("use_speaker_boost") val useSpeakerBoost: Boolean = true
)

data class ElevenLabsVoice(
    @SerializedName("voice_id")    val voiceId: String,
    @SerializedName("name")        val name: String,
    @SerializedName("category")    val category: String = "",
    @SerializedName("description") val description: String = ""
)

data class ElevenLabsVoicesResponse(
    @SerializedName("voices") val voices: List<ElevenLabsVoice> = emptyList()
)

// ══════════════════════════════════════════════════════════════════════════════
// Whisper STT DTOs
// ══════════════════════════════════════════════════════════════════════════════

data class WhisperResponse(
    @SerializedName("text")     val text: String     = "",
    @SerializedName("language") val language: String = "",
    @SerializedName("duration") val duration: Float  = 0f
)
