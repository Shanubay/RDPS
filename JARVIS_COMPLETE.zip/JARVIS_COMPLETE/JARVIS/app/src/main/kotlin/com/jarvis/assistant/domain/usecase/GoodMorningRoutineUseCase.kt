package com.jarvis.assistant.domain.usecase

import com.jarvis.assistant.core.utils.AppPreferences
import com.jarvis.assistant.core.utils.TimeUtils
import com.jarvis.assistant.domain.entities.Message
import com.jarvis.assistant.domain.entities.MessageRole
import com.jarvis.assistant.domain.repository.AIRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import javax.inject.Inject

/**
 * GoodMorningRoutineUseCase — generates an Iron Man–style morning briefing.
 *
 * Spoken on wake word if it's morning and user hasn't been briefed today.
 * Includes: greeting, date/time, weather (if available), and a daily summary.
 */
class GoodMorningRoutineUseCase @Inject constructor(
    private val aiRepository: AIRepository,
    private val appPreferences: AppPreferences,
    private val timeUtils: TimeUtils
) {

    fun execute(): Flow<String> = flow {
        val userName = appPreferences.userName.first()
        val timeStr  = timeUtils.formatCurrentTime()
        val dateStr  = timeUtils.formatCurrentDate()

        // Build the morning briefing prompt
        val prompt = """
Generate a brief, natural JARVIS-style morning greeting for $userName.
Include:
1. Time-aware greeting (it's $timeStr on $dateStr)
2. One short motivational or witty remark in JARVIS's style
3. An offer to help — keep it under 3 sentences total.
Do NOT include weather (no data available). 
Sound like Tony Stark's JARVIS — confident, precise, slightly witty.
        """.trimIndent()

        val messages = listOf(Message(role = MessageRole.USER, content = prompt))

        aiRepository.stream(
            messages     = messages,
            systemPrompt = "You are JARVIS, Iron Man's AI assistant. Be brief and natural.",
            provider     = appPreferences.aiProvider.first(),
            maxTokens    = 150
        ).collect { token -> emit(token) }
    }

    fun getInstantGreeting(): String {
        val userName = "Sir"  // sync fallback
        return when (timeUtils.currentTimeOfDay) {
            TimeUtils.TimeOfDay.MORNING       -> "Good morning, $userName. All systems are online and ready."
            TimeUtils.TimeOfDay.EARLY_MORNING -> "You're up early. Systems are at your disposal, $userName."
            TimeUtils.TimeOfDay.AFTERNOON     -> "Good afternoon, $userName. How can I assist?"
            TimeUtils.TimeOfDay.EVENING       -> "Good evening, $userName. Ready when you are."
            TimeUtils.TimeOfDay.NIGHT         -> "Working late again, $userName? I'm here."
        }
    }
}
