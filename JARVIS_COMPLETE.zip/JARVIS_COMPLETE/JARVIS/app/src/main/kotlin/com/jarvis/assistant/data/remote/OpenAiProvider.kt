package com.jarvis.assistant.data.remote

import com.google.gson.Gson
import com.jarvis.assistant.core.constants.AppConstants
import com.jarvis.assistant.core.utils.AppPreferences
import com.jarvis.assistant.data.remote.api.OpenAiApi
import com.jarvis.assistant.data.remote.api.SseParser
import com.jarvis.assistant.data.remote.dto.*
import com.jarvis.assistant.domain.entities.Message
import com.jarvis.assistant.domain.entities.MessageRole
import com.jarvis.assistant.domain.usecase.AIProvider
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class OpenAiProvider @Inject constructor(
    private val prefs: AppPreferences,
    private val gson: Gson,
    private val sseParser: SseParser,
    private val okHttpClient: okhttp3.OkHttpClient
) : AIProvider {

    override val id   = AppConstants.AIProvider.OPENAI
    override val name = "OpenAI GPT-4o"
    override val requiresInternet = true

    private fun buildApi(baseUrl: String = AppConstants.ApiUrl.OPENAI): OpenAiApi =
        Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()
            .create(OpenAiApi::class.java)

    private suspend fun getKey(): String = prefs.openAiKey.first()
    private fun authHeader(key: String) = "Bearer $key"

    override suspend fun complete(
        messages: List<Message>,
        systemPrompt: String,
        maxTokens: Int,
        temperature: Float
    ): String {
        val key = getKey()
        if (key.isBlank()) return "[OpenAI key not set]"

        val apiMessages = buildMessages(messages, systemPrompt)
        val request = OpenAiRequest(
            model       = "gpt-4o",
            messages    = apiMessages,
            maxTokens   = maxTokens,
            temperature = temperature,
            stream      = false
        )

        val response = buildApi().chatComplete(authHeader(key), request)
        if (!response.isSuccessful) {
            throw Exception("OpenAI HTTP ${response.code()}: ${response.errorBody()?.string()}")
        }
        return response.body()?.choices?.firstOrNull()?.message?.content
            ?: throw Exception("Empty response from OpenAI")
    }

    override fun stream(
        messages: List<Message>,
        systemPrompt: String,
        maxTokens: Int,
        temperature: Float
    ): Flow<String> = flow {
        val key = getKey()
        if (key.isBlank()) { emit("[OpenAI key not set — go to Settings]"); return@flow }

        val apiMessages = buildMessages(messages, systemPrompt)
        val request = OpenAiRequest(
            model       = "gpt-4o",
            messages    = apiMessages,
            maxTokens   = maxTokens,
            temperature = temperature,
            stream      = true
        )

        val response = buildApi().chatStream(authHeader(key), request)
        if (!response.isSuccessful) {
            emit("[OpenAI error: ${response.code()}]")
            return@flow
        }

        val body = response.body() ?: run { emit("[Empty stream body]"); return@flow }
        sseParser.parseOpenAiStream(body).collect { token -> emit(token) }
    }

    override suspend fun isAvailable(): Boolean {
        val key = getKey()
        return key.isNotBlank()
    }

    suspend fun validateKey(key: String): Boolean {
        return try {
            val request = OpenAiRequest(
                model    = "gpt-4o-mini",
                messages = listOf(OpenAiMessage("user", "hi")),
                maxTokens = 1,
                stream   = false
            )
            val response = buildApi().chatComplete("Bearer $key", request)
            response.isSuccessful || response.code() == 400  // 400 = valid key, bad request
        } catch (e: Exception) { false }
    }

    private fun buildMessages(
        messages: List<Message>,
        systemPrompt: String
    ): List<OpenAiMessage> = buildList {
        add(OpenAiMessage("system", systemPrompt))
        messages.takeLast(AppConstants.MAX_CONTEXT_MESSAGES).forEach { msg ->
            val role = when (msg.role) {
                MessageRole.USER      -> "user"
                MessageRole.ASSISTANT -> "assistant"
                MessageRole.SYSTEM    -> "system"
            }
            add(OpenAiMessage(role, msg.content))
        }
    }
}
