package com.jarvis.assistant.domain.entities

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

// ══════════════════════════════════════════════════════════════════════════════
// JARVIS Domain Entities
// Pure Kotlin data classes — no Android framework dependencies
// ══════════════════════════════════════════════════════════════════════════════

// ── Message ───────────────────────────────────────────────────────────────────

enum class MessageRole { USER, ASSISTANT, SYSTEM }
enum class MessageStatus { SENDING, SENT, STREAMING, ERROR }

@Parcelize
data class Message(
    val id: String = java.util.UUID.randomUUID().toString(),
    val role: MessageRole,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: MessageStatus = MessageStatus.SENT,
    val provider: String = "",          // which AI model produced this
    val tokenCount: Int = 0,
    val durationMs: Long = 0,           // inference time
    val isVoice: Boolean = false,       // was this spoken aloud?
    val audioPath: String? = null       // path to TTS audio file
) : Parcelable

// ── Conversation ──────────────────────────────────────────────────────────────

@Parcelize
data class Conversation(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String = "New Conversation",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val messageCount: Int = 0,
    val summary: String = "",
    val tags: List<String> = emptyList()
) : Parcelable

// ── Memory ────────────────────────────────────────────────────────────────────

enum class MemoryType {
    FACT,           // "My name is Karan"
    PREFERENCE,     // "I prefer dark mode"
    HABIT,          // "I wake up at 6am"
    RELATIONSHIP,   // "My boss is called Rahul"
    EVENT,          // "I have a meeting on Friday"
    EMOTION,        // "User seemed stressed today"
    GENERAL         // catch-all
}

data class Memory(
    val id: String = java.util.UUID.randomUUID().toString(),
    val content: String,
    val type: MemoryType = MemoryType.GENERAL,
    val embedding: FloatArray? = null,
    val embeddingStr: String = "",       // Base64 for Room
    val conversationId: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val accessCount: Int = 0,
    val lastAccessedAt: Long = System.currentTimeMillis(),
    val importance: Float = 0.5f,        // 0.0 – 1.0
    val source: String = "conversation"  // "conversation" | "manual" | "inferred"
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is Memory) return false
        return id == other.id
    }
    override fun hashCode(): Int = id.hashCode()
}

// ── AI Model ──────────────────────────────────────────────────────────────────

enum class ModelProvider { LOCAL_LLAMA, OPENAI, GEMINI, GROQ, OPENROUTER }
enum class ModelStatus { NOT_DOWNLOADED, DOWNLOADING, READY, LOADING, LOADED, ERROR }

data class AIModel(
    val id: String,
    val name: String,
    val description: String,
    val provider: ModelProvider,
    val downloadUrl: String = "",
    val sizeBytes: Long = 0,
    val ramRequired: String = "",
    val filePath: String = "",
    val status: ModelStatus = ModelStatus.NOT_DOWNLOADED,
    val downloadProgress: Int = 0,      // 0–100
    val contextLength: Int = 4096,
    val quantization: String = "Q4_K_M",
    val isDefault: Boolean = false
)

// ── Voice Session ─────────────────────────────────────────────────────────────

enum class VoiceState {
    IDLE,
    WAKE_WORD_LISTENING,
    LISTENING,           // STT active
    PROCESSING,          // AI thinking
    SPEAKING,            // TTS playing
    ERROR
}

data class VoiceSession(
    val id: String = java.util.UUID.randomUUID().toString(),
    val state: VoiceState = VoiceState.IDLE,
    val transcript: String = "",
    val partialTranscript: String = "",
    val amplitude: Float = 0f,
    val waveform: List<Float> = emptyList(),
    val isWakeWordDetected: Boolean = false,
    val error: String? = null,
    val sttProvider: String = "",
    val ttsProvider: String = ""
)

// ── User Profile ──────────────────────────────────────────────────────────────

data class UserProfile(
    val name: String = "Sir",
    val preferredLanguage: String = "en",
    val voiceGender: String = "male",
    val ttsStyle: TtsStyle = TtsStyle.NATURAL,
    val aiPersonality: AIPersonality = AIPersonality.BALANCED,
    val timezone: String = java.util.TimeZone.getDefault().id,
    val wakeWordEnabled: Boolean = true,
    val overlayEnabled: Boolean = false,
    val backgroundListening: Boolean = true
)

enum class TtsStyle { NATURAL, SERIOUS, FRIENDLY, WHISPER }
enum class AIPersonality { BALANCED, FORMAL, CASUAL, MINIMAL }

// ── Device State ──────────────────────────────────────────────────────────────

data class DeviceState(
    val isWifiEnabled: Boolean = false,
    val isBluetoothEnabled: Boolean = false,
    val isFlashlightOn: Boolean = false,
    val volumeLevel: Int = 0,
    val maxVolume: Int = 15,
    val batteryLevel: Int = 100,
    val isCharging: Boolean = false,
    val isDoNotDisturb: Boolean = false,
    val brightnessLevel: Int = 128,
    val currentApp: String = ""
)

// ── Notification ──────────────────────────────────────────────────────────────

data class AppNotification(
    val id: String,
    val packageName: String,
    val appName: String,
    val title: String,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)

// ── Automation Routine ────────────────────────────────────────────────────────

data class Routine(
    val id: String = java.util.UUID.randomUUID().toString(),
    val name: String,
    val trigger: RoutineTrigger,
    val actions: List<RoutineAction>,
    val isEnabled: Boolean = true,
    val lastRun: Long = 0L
)

sealed class RoutineTrigger {
    data class TimeOfDay(val hour: Int, val minute: Int) : RoutineTrigger()
    data class WakeWord(val phrase: String) : RoutineTrigger()
    object ChargingConnected : RoutineTrigger()
    object ChargingDisconnected : RoutineTrigger()
    data class AppOpened(val packageName: String) : RoutineTrigger()
}

sealed class RoutineAction {
    data class SpeakText(val text: String) : RoutineAction()
    data class LaunchApp(val packageName: String) : RoutineAction()
    data class SetVolume(val level: Int) : RoutineAction()
    data class ToggleWifi(val enable: Boolean) : RoutineAction()
    data class ToggleBluetooth(val enable: Boolean) : RoutineAction()
    data class SendAiQuery(val query: String) : RoutineAction()
}

// ── Chat UI State (presentation-friendly aggregate) ──────────────────────────

data class ChatUiState(
    val messages: List<Message> = emptyList(),
    val voiceState: VoiceState = VoiceState.IDLE,
    val isLoading: Boolean = false,
    val streamingText: String = "",
    val error: String? = null,
    val inputText: String = "",
    val amplitude: Float = 0f,
    val waveform: List<Float> = List(20) { 0f },
    val activeProvider: String = "",
    val isTtsSpeaking: Boolean = false
)

// ── Settings UI State ─────────────────────────────────────────────────────────

data class SettingsState(
    val aiProvider: String = "openai",
    val openAiKey: String = "",
    val geminiKey: String = "",
    val groqKey: String = "",
    val elevenLabsKey: String = "",
    val ttsProvider: String = "android_tts",
    val voiceEnabled: Boolean = true,
    val overlayEnabled: Boolean = false,
    val offlineMode: Boolean = false,
    val activeModelName: String? = null,
    val userName: String = "Sir"
)
