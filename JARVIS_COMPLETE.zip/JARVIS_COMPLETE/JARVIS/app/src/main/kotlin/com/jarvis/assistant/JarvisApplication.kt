package com.jarvis.assistant

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import dagger.hilt.android.HiltAndroidApp
import timber.log.Timber

/**
 * JARVIS Application
 *
 * Entry point — bootstraps Hilt DI and initializes
 * all app-wide systems: notification channels, Timber logging,
 * and core service bindings.
 */
@HiltAndroidApp
class JarvisApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        // ── Logging ───────────────────────────────────────────────────────────
        // (Timber is a popular logger; add it as a dependency or replace with Log)
        // Timber.plant(Timber.DebugTree())

        // ── Notification Channels ─────────────────────────────────────────────
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)

            val channels = listOf(
                NotificationChannel(
                    CHANNEL_VOICE,
                    getString(R.string.notification_channel_voice),
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "JARVIS wake word and voice recognition service"
                    setShowBadge(false)
                    enableVibration(false)
                    setSound(null, null)
                },

                NotificationChannel(
                    CHANNEL_OVERLAY,
                    getString(R.string.notification_channel_overlay),
                    NotificationManager.IMPORTANCE_MIN
                ).apply {
                    description = "JARVIS floating assistant overlay"
                    setShowBadge(false)
                    enableVibration(false)
                    setSound(null, null)
                },

                NotificationChannel(
                    CHANNEL_AI,
                    getString(R.string.notification_channel_ai),
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "JARVIS AI processing notifications"
                    setShowBadge(false)
                },

                NotificationChannel(
                    CHANNEL_DEVICE,
                    getString(R.string.notification_channel_device),
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "JARVIS device control service"
                    setShowBadge(false)
                    enableVibration(false)
                    setSound(null, null)
                }
            )

            channels.forEach { manager.createNotificationChannel(it) }
        }
    }

    companion object {
        const val CHANNEL_VOICE   = "jarvis_voice"
        const val CHANNEL_OVERLAY = "jarvis_overlay"
        const val CHANNEL_AI      = "jarvis_ai"
        const val CHANNEL_DEVICE  = "jarvis_device"

        const val NOTIFICATION_ID_VOICE   = 1001
        const val NOTIFICATION_ID_OVERLAY = 1002
        const val NOTIFICATION_ID_AI      = 1003
        const val NOTIFICATION_ID_DEVICE  = 1004
    }
}
