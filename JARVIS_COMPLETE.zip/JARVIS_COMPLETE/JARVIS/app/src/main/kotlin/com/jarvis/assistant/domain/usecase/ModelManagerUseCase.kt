package com.jarvis.assistant.domain.usecase

import com.jarvis.assistant.core.constants.AppConstants
import com.jarvis.assistant.core.utils.FileManager
import com.jarvis.assistant.domain.entities.AIModel
import com.jarvis.assistant.domain.entities.ModelStatus
import com.jarvis.assistant.domain.repository.ModelRepository
import kotlinx.coroutines.flow.*
import javax.inject.Inject

/**
 * ModelManagerUseCase — full lifecycle management of local GGUF models.
 *
 * Handles: download, progress, integrity check, load/unload, switch, delete.
 */
class ModelManagerUseCase @Inject constructor(
    private val modelRepository: ModelRepository,
    private val fileManager: FileManager
) {

    sealed class ModelEvent {
        data class DownloadProgress(val modelId: String, val percent: Int, val bytesLoaded: Long, val totalBytes: Long) : ModelEvent()
        data class DownloadComplete(val modelId: String, val filePath: String) : ModelEvent()
        data class DownloadError(val modelId: String, val message: String) : ModelEvent()
        data class LoadProgress(val modelId: String, val status: String) : ModelEvent()
        data class LoadComplete(val modelId: String) : ModelEvent()
        data class LoadError(val modelId: String, val message: String) : ModelEvent()
        data class DeleteComplete(val modelId: String) : ModelEvent()
        object Cancelled : ModelEvent()
    }

    // ── Get all models ────────────────────────────────────────────────────────

    fun getAllModels(): Flow<List<AIModel>> = modelRepository.getAllModels()

    // ── Download ──────────────────────────────────────────────────────────────

    fun downloadModel(model: AIModel): Flow<ModelEvent> =
        modelRepository.downloadModel(model)
            .map { updatedModel ->
                when (updatedModel.status) {
                    ModelStatus.DOWNLOADING ->
                        ModelEvent.DownloadProgress(
                            modelId      = model.id,
                            percent      = updatedModel.downloadProgress,
                            bytesLoaded  = (updatedModel.sizeBytes * updatedModel.downloadProgress / 100),
                            totalBytes   = updatedModel.sizeBytes
                        )
                    ModelStatus.READY ->
                        ModelEvent.DownloadComplete(model.id, updatedModel.filePath)
                    ModelStatus.ERROR ->
                        ModelEvent.DownloadError(model.id, "Download failed")
                    else ->
                        ModelEvent.DownloadProgress(model.id, 0, 0, model.sizeBytes)
                }
            }
            .catch { e ->
                emit(ModelEvent.DownloadError(model.id, e.message ?: "Unknown error"))
            }

    fun cancelDownload(modelId: String) {
        fileManager.cancelDownload(modelId)
    }

    // ── Load / Unload ─────────────────────────────────────────────────────────

    suspend fun loadModel(modelId: String): ModelEvent {
        return try {
            val success = modelRepository.loadModel(modelId)
            if (success) ModelEvent.LoadComplete(modelId)
            else ModelEvent.LoadError(modelId, "Failed to load model")
        } catch (e: Exception) {
            ModelEvent.LoadError(modelId, e.message ?: "Load error")
        }
    }

    suspend fun unloadModel() = modelRepository.unloadModel()

    fun isModelLoaded() = modelRepository.isModelLoaded()

    // ── Switch active model ───────────────────────────────────────────────────

    suspend fun setActiveModel(modelId: String) = modelRepository.setActiveModel(modelId)

    suspend fun getActiveModel() = modelRepository.getActiveModel()

    // ── Delete ────────────────────────────────────────────────────────────────

    suspend fun deleteModel(modelId: String): ModelEvent {
        return try {
            val success = modelRepository.deleteModel(modelId)
            if (success) ModelEvent.DeleteComplete(modelId)
            else ModelEvent.DownloadError(modelId, "Delete failed")
        } catch (e: Exception) {
            ModelEvent.DownloadError(modelId, e.message ?: "Delete error")
        }
    }

    // ── Storage info ──────────────────────────────────────────────────────────

    data class StorageInfo(
        val availableGB: Float,
        val usedByModelsGB: Float,
        val totalGB: Float
    )

    fun getStorageInfo(): StorageInfo {
        val available = fileManager.getAvailableStorageBytes()
        val used      = fileManager.getUsedModelsStorageBytes()
        val total     = fileManager.getTotalStorageBytes()
        return StorageInfo(
            availableGB    = available / 1_073_741_824f,
            usedByModelsGB = used / 1_073_741_824f,
            totalGB        = total / 1_073_741_824f
        )
    }

    // ── Catalog ───────────────────────────────────────────────────────────────

    fun getCatalogModels(): List<AIModel> =
        AppConstants.ModelCatalog.ALL.map { info ->
            AIModel(
                id          = info.id,
                name        = info.name,
                description = info.description,
                provider    = com.jarvis.assistant.domain.entities.ModelProvider.LOCAL_LLAMA,
                downloadUrl = info.url,
                sizeBytes   = info.sizeBytes,
                ramRequired = info.ramRequired,
                status      = if (fileManager.isModelDownloaded(info.id))
                    ModelStatus.READY else ModelStatus.NOT_DOWNLOADED
            )
        }
}
