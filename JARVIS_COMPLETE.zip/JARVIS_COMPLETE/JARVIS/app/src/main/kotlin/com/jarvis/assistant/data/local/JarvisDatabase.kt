package com.jarvis.assistant.data.local

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import android.content.Context
import com.jarvis.assistant.data.local.dao.*
import com.jarvis.assistant.data.local.entities.*

// ══════════════════════════════════════════════════════════════════════════════
// JarvisDatabase — Single Room database for all JARVIS persistence
// ══════════════════════════════════════════════════════════════════════════════

@Database(
    entities = [
        ConversationEntity::class,
        MessageEntity::class,
        MemoryEntity::class,
        LocalModelEntity::class,
        NotificationEntity::class,
        RoutineEntity::class
    ],
    version = 1,
    exportSchema = true
)
@TypeConverters(JarvisTypeConverters::class)
abstract class JarvisDatabase : RoomDatabase() {

    abstract fun conversationDao(): ConversationDao
    abstract fun memoryDao(): MemoryDao
    abstract fun modelDao(): ModelDao
    abstract fun notificationDao(): NotificationDao
    abstract fun routineDao(): RoutineDao

    companion object {
        const val DATABASE_NAME = "jarvis_memory.db"

        // ── Migration 1 → 2 template (add as needed) ─────────────────────────
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                // Example: ALTER TABLE memories ADD COLUMN emotion TEXT DEFAULT ''
            }
        }

        fun buildDatabase(context: Context): JarvisDatabase =
            Room.databaseBuilder(
                context.applicationContext,
                JarvisDatabase::class.java,
                DATABASE_NAME
            )
                .addMigrations(MIGRATION_1_2)
                .fallbackToDestructiveMigration()   // dev only — remove for prod
                .build()
    }
}
