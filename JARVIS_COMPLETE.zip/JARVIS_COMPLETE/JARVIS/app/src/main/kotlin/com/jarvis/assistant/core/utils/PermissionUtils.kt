package com.jarvis.assistant.core.utils

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * PermissionUtils — Centralized permission checking and navigation helper.
 */
@Singleton
class PermissionUtils @Inject constructor(
    @ApplicationContext private val context: Context
) {

    fun hasPermission(permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) ==
                PackageManager.PERMISSION_GRANTED

    val hasMicrophonePermission: Boolean
        get() = hasPermission(Manifest.permission.RECORD_AUDIO)

    val hasCameraPermission: Boolean
        get() = hasPermission(Manifest.permission.CAMERA)

    val hasCallPermission: Boolean
        get() = hasPermission(Manifest.permission.CALL_PHONE)

    val hasContactsPermission: Boolean
        get() = hasPermission(Manifest.permission.READ_CONTACTS)

    val hasNotificationPermission: Boolean
        get() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            hasPermission(Manifest.permission.POST_NOTIFICATIONS)
        } else true

    val hasOverlayPermission: Boolean
        get() = Settings.canDrawOverlays(context)

    val hasAccessibilityPermission: Boolean
        get() {
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            return enabledServices.contains(context.packageName)
        }

    val hasNotificationListenerPermission: Boolean
        get() {
            val notificationManager =
                context.getSystemService(NotificationManager::class.java)
            return notificationManager?.isNotificationListenerAccessGranted(
                android.content.ComponentName(
                    context,
                    "com.jarvis.assistant.service.device.JarvisNotificationListener"
                )
            ) ?: false
        }

    val hasUsageStatsPermission: Boolean
        get() {
            return try {
                val usageStatsManager = context.getSystemService(
                    android.app.usage.UsageStatsManager::class.java
                )
                val stats = usageStatsManager?.queryUsageStats(
                    android.app.usage.UsageStatsManager.INTERVAL_DAILY,
                    System.currentTimeMillis() - 1000,
                    System.currentTimeMillis()
                )
                !stats.isNullOrEmpty()
            } catch (e: Exception) {
                false
            }
        }

    // ── Intent helpers to open system settings ────────────────────────────────

    fun overlaySettingsIntent(): Intent = Intent(
        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
        Uri.parse("package:${context.packageName}")
    )

    fun accessibilitySettingsIntent(): Intent =
        Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)

    fun notificationListenerSettingsIntent(): Intent =
        Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)

    fun usageStatsSettingsIntent(): Intent =
        Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)

    fun appSettingsIntent(): Intent = Intent(
        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
        Uri.parse("package:${context.packageName}")
    )

    // ── All required permissions list ─────────────────────────────────────────

    val requiredRuntimePermissions: List<String>
        get() = buildList {
            add(Manifest.permission.RECORD_AUDIO)
            add(Manifest.permission.CAMERA)
            add(Manifest.permission.CALL_PHONE)
            add(Manifest.permission.READ_CONTACTS)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.POST_NOTIFICATIONS)
                add(Manifest.permission.READ_MEDIA_IMAGES)
                add(Manifest.permission.READ_MEDIA_VIDEO)
            }
        }

    val allPermissionsGranted: Boolean
        get() = hasMicrophonePermission &&
                hasNotificationPermission &&
                hasOverlayPermission

    data class PermissionStatus(
        val microphone: Boolean,
        val camera: Boolean,
        val overlay: Boolean,
        val accessibility: Boolean,
        val notifications: Boolean,
        val notificationListener: Boolean,
        val usageStats: Boolean
    )

    fun getPermissionStatus(): PermissionStatus = PermissionStatus(
        microphone           = hasMicrophonePermission,
        camera               = hasCameraPermission,
        overlay              = hasOverlayPermission,
        accessibility        = hasAccessibilityPermission,
        notifications        = hasNotificationPermission,
        notificationListener = hasNotificationListenerPermission,
        usageStats           = hasUsageStatsPermission
    )
}
