package com.jarvis.assistant.core.utils

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * DeviceInfoUtils — Detects device hardware tier for AI router decisions.
 *
 * HIGH tier   → flagship (8GB+ RAM, Snapdragon 8xx / Dimensity 9xxx)
 * MEDIUM tier → mid-range (4-6GB RAM)
 * LOW tier    → budget / older (≤3GB RAM)
 */
@Singleton
class DeviceInfoUtils @Inject constructor(
    @ApplicationContext private val context: Context
) {

    enum class DeviceTier { HIGH, MEDIUM, LOW }

    private val activityManager: ActivityManager
        get() = context.getSystemService(ActivityManager::class.java)

    val totalRamBytes: Long
        get() {
            val info = ActivityManager.MemoryInfo()
            activityManager.getMemoryInfo(info)
            return info.totalMem
        }

    val availableRamBytes: Long
        get() {
            val info = ActivityManager.MemoryInfo()
            activityManager.getMemoryInfo(info)
            return info.availMem
        }

    val totalRamGB: Float
        get() = totalRamBytes / (1024f * 1024f * 1024f)

    val availableRamGB: Float
        get() = availableRamBytes / (1024f * 1024f * 1024f)

    val cpuCoreCount: Int
        get() = Runtime.getRuntime().availableProcessors()

    val deviceTier: DeviceTier
        get() = when {
            totalRamGB >= 7f && cpuCoreCount >= 8 -> DeviceTier.HIGH
            totalRamGB >= 4f -> DeviceTier.MEDIUM
            else -> DeviceTier.LOW
        }

    val recommendedLlmThreads: Int
        get() = when (deviceTier) {
            DeviceTier.HIGH   -> (cpuCoreCount / 2).coerceIn(4, 8)
            DeviceTier.MEDIUM -> (cpuCoreCount / 2).coerceIn(2, 4)
            DeviceTier.LOW    -> 2
        }

    val canRunLocalLlm: Boolean
        get() = availableRamGB >= 1.5f

    val deviceModel: String
        get() = "${Build.MANUFACTURER} ${Build.MODEL}"

    val androidVersion: Int
        get() = Build.VERSION.SDK_INT

    val isLowMemoryDevice: Boolean
        get() = activityManager.isLowRamDevice

    data class DeviceInfo(
        val model: String,
        val androidVersion: Int,
        val totalRamGB: Float,
        val availableRamGB: Float,
        val cpuCores: Int,
        val tier: DeviceTier,
        val canRunLocalLlm: Boolean
    )

    fun getDeviceInfo(): DeviceInfo = DeviceInfo(
        model           = deviceModel,
        androidVersion  = androidVersion,
        totalRamGB      = totalRamGB,
        availableRamGB  = availableRamGB,
        cpuCores        = cpuCoreCount,
        tier            = deviceTier,
        canRunLocalLlm  = canRunLocalLlm
    )
}
