package com.jarvis.assistant.core.utils

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import dagger.hilt.android.qualifiers.ApplicationContext
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.inject.Inject
import javax.inject.Singleton

/**
 * EncryptionManager — AES-256-GCM encryption using Android Keystore.
 *
 * All API keys and sensitive user data are encrypted at rest.
 * Keys never leave the hardware-backed Keystore.
 */
@Singleton
class EncryptionManager @Inject constructor(
    @ApplicationContext private val context: Context
) {

    companion object {
        private const val KEYSTORE_PROVIDER    = "AndroidKeyStore"
        private const val KEY_ALIAS            = "JarvisEncryptionKey"
        private const val ALGORITHM            = "AES/GCM/NoPadding"
        private const val KEY_SIZE             = 256
        private const val GCM_IV_LENGTH        = 12
        private const val GCM_TAG_LENGTH       = 128
        private const val SEPARATOR            = ":"
    }

    init {
        ensureKeyExists()
    }

    // ── Key Management ────────────────────────────────────────────────────────

    private fun ensureKeyExists() {
        val keyStore = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
        if (!keyStore.containsAlias(KEY_ALIAS)) {
            generateKey()
        }
    }

    private fun generateKey() {
        val keyGenerator = KeyGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_AES,
            KEYSTORE_PROVIDER
        )
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setKeySize(KEY_SIZE)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build()
        keyGenerator.init(spec)
        keyGenerator.generateKey()
    }

    private fun getSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
        return (keyStore.getEntry(KEY_ALIAS, null) as KeyStore.SecretKeyEntry).secretKey
    }

    // ── Encrypt ───────────────────────────────────────────────────────────────

    fun encrypt(plainText: String): String {
        if (plainText.isBlank()) return ""
        return try {
            val cipher = Cipher.getInstance(ALGORITHM)
            cipher.init(Cipher.ENCRYPT_MODE, getSecretKey())
            val iv = cipher.iv
            val encrypted = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
            val ivBase64  = Base64.encodeToString(iv, Base64.NO_WRAP)
            val encBase64 = Base64.encodeToString(encrypted, Base64.NO_WRAP)
            "$ivBase64$SEPARATOR$encBase64"
        } catch (e: Exception) {
            android.util.Log.e("EncryptionManager", "Encryption failed", e)
            plainText  // fallback: store unencrypted (log error)
        }
    }

    // ── Decrypt ───────────────────────────────────────────────────────────────

    fun decrypt(cipherText: String): String {
        if (cipherText.isBlank()) return ""
        return try {
            val parts = cipherText.split(SEPARATOR)
            if (parts.size != 2) return cipherText  // not encrypted

            val iv       = Base64.decode(parts[0], Base64.NO_WRAP)
            val encrypted = Base64.decode(parts[1], Base64.NO_WRAP)

            val cipher = Cipher.getInstance(ALGORITHM)
            val spec   = GCMParameterSpec(GCM_TAG_LENGTH, iv)
            cipher.init(Cipher.DECRYPT_MODE, getSecretKey(), spec)
            String(cipher.doFinal(encrypted), Charsets.UTF_8)
        } catch (e: Exception) {
            android.util.Log.e("EncryptionManager", "Decryption failed", e)
            cipherText  // return as-is on failure
        }
    }

    // ── Convenience ───────────────────────────────────────────────────────────

    fun encryptApiKey(key: String): String = if (key.isEmpty()) "" else encrypt(key)
    fun decryptApiKey(encrypted: String): String = if (encrypted.isEmpty()) "" else decrypt(encrypted)

    fun isEncrypted(value: String): Boolean =
        value.contains(SEPARATOR) && value.split(SEPARATOR).size == 2
}
