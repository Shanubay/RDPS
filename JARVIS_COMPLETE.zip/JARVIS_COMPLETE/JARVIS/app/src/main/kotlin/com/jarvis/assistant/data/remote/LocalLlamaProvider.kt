package com.jarvis.assistant.data.remote

import com.jarvis.assistant.core.constants.AppConstants
import com.jarvis.assistant.core.llm.LlamaEngine
import com.jarvis.assistant.domain.entities.Message
import com.jarvis.assistant.domain.usecase.AIProvider
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.onEmpty
import javax.inject.Inject
import javax.inject.Singleton

/**
 * LocalLlamaProvider — wraps LlamaEngine as a full AIProvider.
 *
 * Used when:
 * • Device is offline
 * • User forced offline mode
 * • Battery is critically low
 */
@Singleton
class LocalLlamaProvider @Inject constructor(
    private val llamaEngine: LlamaEngine
) : AIProvider {

    override val id   = AppConstants.AIProvider.LOCAL_LLAMA
    override val name = "Local AI (Offline)"
    override val requiresInternet = false

    override suspend fun complete(
        messages: List<Message>,
        systemPrompt: String,
        maxTokens: Int,
        temperature: Float
    ): String {
        if (!llamaEngine.isModelLoaded()) {
            return "No local model loaded. Please download one from the Model Manager."
        }

        val prompt = llamaEngine.formatPrompt(systemPrompt, messages)
        val result = StringBuilder()
        llamaEngine.streamGenerate(prompt, maxTokens, temperature)
            .collect { token -> result.append(token) }
        return result.toString()
    }

    override fun stream(
        messages: List<Message>,
        systemPrompt: String,
        maxTokens: Int,
        temperature: Float
    ): Flow<String> {
        if (!llamaEngine.isModelLoaded()) {
            return kotlinx.coroutines.flow.flow {
                emit("No local model loaded. Please go to Model Manager to download one.")
            }
        }

        val prompt = llamaEngine.formatPrompt(systemPrompt, messages)
        return llamaEngine.streamGenerate(prompt, maxTokens, temperature)
            .onEmpty {
                emit("No response generated. Try reloading the model.")
            }
    }

    override suspend fun isAvailable(): Boolean = llamaEngine.isModelLoaded()
}
