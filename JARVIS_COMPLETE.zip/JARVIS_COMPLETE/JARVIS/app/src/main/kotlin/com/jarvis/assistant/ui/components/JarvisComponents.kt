package com.jarvis.assistant.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.jarvis.assistant.domain.entities.VoiceState
import com.jarvis.assistant.ui.theme.JarvisColors
import com.jarvis.assistant.ui.theme.JarvisSpacing
import kotlin.math.*

// ══════════════════════════════════════════════════════════════════════════════
// JARVIS Design System Components
// Iron Man HUD aesthetic — all dark, cyan glows, angular geometry
// ══════════════════════════════════════════════════════════════════════════════

// ── HUD Border Container ──────────────────────────────────────────────────────

@Composable
fun HudCard(
    modifier: Modifier = Modifier,
    glowColor: Color   = JarvisColors.CyanCore,
    glowAlpha: Float   = 0.35f,
    cornerSize: Dp     = 6.dp,
    borderWidth: Dp    = 0.5.dp,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(cornerSize))
            .background(JarvisColors.CardNavy)
            .border(
                BorderStroke(borderWidth, glowColor.copy(alpha = glowAlpha)),
                RoundedCornerShape(cornerSize)
            )
            .shadow(
                elevation     = 4.dp,
                shape         = RoundedCornerShape(cornerSize),
                ambientColor  = glowColor.copy(alpha = 0.08f),
                spotColor     = glowColor.copy(alpha = 0.12f)
            ),
        content = content
    )
}

// ── Corner-Cut HUD Frame ──────────────────────────────────────────────────────

@Composable
fun HudFrame(
    modifier: Modifier = Modifier,
    accentColor: Color = JarvisColors.CyanCore,
    cornerCut: Float   = 16f,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .drawBehind {
                val path = Path().apply {
                    moveTo(cornerCut, 0f)
                    lineTo(size.width, 0f)
                    lineTo(size.width, size.height - cornerCut)
                    lineTo(size.width - cornerCut, size.height)
                    lineTo(0f, size.height)
                    lineTo(0f, cornerCut)
                    close()
                }
                drawPath(path, color = JarvisColors.SurfaceNavy)
                drawPath(
                    path,
                    color = accentColor.copy(alpha = 0.4f),
                    style = Stroke(width = 1f)
                )
                // Corner accent dots
                drawCircle(accentColor.copy(alpha = 0.6f), 3f, Offset(0f, cornerCut))
                drawCircle(accentColor.copy(alpha = 0.6f), 3f, Offset(size.width, size.height - cornerCut))
            },
        content = content
    )
}

// ── Pulsing Arc Reactor Orb ───────────────────────────────────────────────────

@Composable
fun ArcReactorOrb(
    modifier: Modifier    = Modifier,
    size: Dp              = 72.dp,
    voiceState: VoiceState = VoiceState.IDLE,
    onClick: () -> Unit   = {}
) {
    val isActive = voiceState != VoiceState.IDLE && voiceState != VoiceState.WAKE_WORD_LISTENING

    val pulseAnim by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue   = 0.6f,
        targetValue    = 1f,
        animationSpec  = infiniteRepeatable(
            animation  = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    val rotateAnim by rememberInfiniteTransition(label = "rotate").animateFloat(
        initialValue  = 0f,
        targetValue   = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing)
        ),
        label = "rotation"
    )

    val coreColor = when (voiceState) {
        VoiceState.LISTENING   -> JarvisColors.CyanBright
        VoiceState.PROCESSING  -> JarvisColors.GoldAlert
        VoiceState.SPEAKING    -> JarvisColors.GreenOnline
        VoiceState.ERROR       -> JarvisColors.CrimsonAlert
        else                   -> JarvisColors.CyanCore
    }

    Box(
        modifier       = modifier
            .size(size)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val center = Offset(this.size.width / 2, this.size.height / 2)
            val radius = this.size.width / 2 * 0.9f

            // Outer glow ring
            drawCircle(
                color  = coreColor.copy(alpha = 0.08f * pulseAnim),
                radius = radius * 1.3f,
                center = center
            )

            // Rotating segments
            rotate(rotateAnim, center) {
                for (i in 0..5) {
                    val angle  = i * 60f - 10f
                    val arcRad = radius * 0.82f
                    drawArc(
                        color      = coreColor.copy(alpha = if (isActive) 0.6f else 0.25f),
                        startAngle = angle,
                        sweepAngle = 16f,
                        useCenter  = false,
                        topLeft    = Offset(center.x - arcRad, center.y - arcRad),
                        size       = androidx.compose.ui.geometry.Size(arcRad * 2, arcRad * 2),
                        style      = Stroke(width = 1.5f)
                    )
                }
            }

            // Mid ring
            drawCircle(
                color  = coreColor.copy(alpha = 0.3f),
                radius = radius * 0.65f,
                center = center,
                style  = Stroke(width = 1f)
            )

            // Core fill
            drawCircle(
                brush = Brush.radialGradient(
                    colors  = listOf(
                        coreColor.copy(alpha = if (isActive) pulseAnim else 0.5f),
                        coreColor.copy(alpha = 0.1f),
                        Color.Transparent
                    ),
                    center  = center,
                    radius  = radius * 0.55f
                ),
                radius = radius * 0.55f,
                center = center
            )

            // Center dot
            drawCircle(coreColor, 4f, center)
        }
    }
}

// ── Voice Waveform ────────────────────────────────────────────────────────────

@Composable
fun VoiceWaveform(
    waveform: List<Float>,
    modifier: Modifier   = Modifier,
    color: Color         = JarvisColors.CyanCore,
    isActive: Boolean    = false
) {
    val animAlpha by rememberInfiniteTransition(label = "wave").animateFloat(
        initialValue  = 0.7f,
        targetValue   = 1f,
        animationSpec = infiniteRepeatable(
            animation  = tween(600),
            repeatMode = RepeatMode.Reverse
        ),
        label = "waveAlpha"
    )

    Canvas(modifier = modifier.height(48.dp)) {
        if (waveform.isEmpty()) return@Canvas

        val barWidth  = (size.width / waveform.size) * 0.6f
        val gap       = (size.width / waveform.size) * 0.4f
        val maxHeight = size.height * 0.9f
        val centerY   = size.height / 2

        waveform.forEachIndexed { i, amplitude ->
            val barHeight = maxOf(4f, amplitude * maxHeight)
            val x         = i * (barWidth + gap) + barWidth / 2
            val alpha     = if (isActive) animAlpha else 0.3f

            // Gradient bar
            drawLine(
                brush       = Brush.verticalGradient(
                    colors  = listOf(
                        color.copy(alpha = alpha * 0.3f),
                        color.copy(alpha = alpha),
                        color.copy(alpha = alpha * 0.3f)
                    ),
                    startY  = centerY - barHeight / 2,
                    endY    = centerY + barHeight / 2
                ),
                start       = Offset(x, centerY - barHeight / 2),
                end         = Offset(x, centerY + barHeight / 2),
                strokeWidth = barWidth,
                cap         = StrokeCap.Round
            )
        }
    }
}

// ── Status Label ──────────────────────────────────────────────────────────────

@Composable
fun JarvisStatusLabel(
    text: String,
    modifier: Modifier = Modifier,
    color: Color       = JarvisColors.CyanCore
) {
    Row(
        modifier      = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // Blinking indicator
        val alpha by rememberInfiniteTransition(label = "blink").animateFloat(
            initialValue  = 0.3f,
            targetValue   = 1f,
            animationSpec = infiniteRepeatable(
                animation  = tween(800),
                repeatMode = RepeatMode.Reverse
            ),
            label = "indicatorAlpha"
        )
        Canvas(Modifier.size(6.dp)) {
            drawCircle(color = color.copy(alpha = alpha), radius = 3f)
        }
        Text(
            text     = text.uppercase(),
            style    = MaterialTheme.typography.labelSmall,
            color    = color,
            fontWeight = FontWeight.W700,
            letterSpacing = 2.sp
        )
    }
}

// ── Scan Line overlay ─────────────────────────────────────────────────────────

@Composable
fun ScanlineOverlay(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val lineSpacing = 4f
        var y = 0f
        while (y < size.height) {
            drawLine(
                color       = Color(0x08000000),
                start       = Offset(0f, y),
                end         = Offset(size.width, y),
                strokeWidth = 1f
            )
            y += lineSpacing
        }
    }
}

// ── HUD Divider ───────────────────────────────────────────────────────────────

@Composable
fun HudDivider(
    modifier: Modifier = Modifier,
    color: Color       = JarvisColors.CyanCore.copy(alpha = 0.2f)
) {
    Box(modifier = modifier
        .fillMaxWidth()
        .height(0.5.dp)
        .background(
            Brush.horizontalGradient(
                listOf(Color.Transparent, color, color, Color.Transparent)
            )
        )
    )
}

// ── Primary Action Button ─────────────────────────────────────────────────────

@Composable
fun JarvisButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier   = Modifier,
    enabled: Boolean     = true,
    color: Color         = JarvisColors.CyanCore,
    isDestructive: Boolean = false
) {
    val finalColor = if (isDestructive) JarvisColors.CrimsonAlert else color

    Button(
        onClick  = onClick,
        enabled  = enabled,
        colors   = ButtonDefaults.buttonColors(
            containerColor         = finalColor.copy(alpha = 0.12f),
            contentColor           = finalColor,
            disabledContainerColor = JarvisColors.TextDisabled.copy(alpha = 0.08f),
            disabledContentColor   = JarvisColors.TextDisabled
        ),
        border   = BorderStroke(
            0.5.dp,
            if (enabled) finalColor.copy(alpha = 0.5f) else JarvisColors.TextDisabled.copy(0.2f)
        ),
        shape    = RoundedCornerShape(4.dp),
        modifier = modifier
    ) {
        Text(
            text          = text.uppercase(),
            style         = MaterialTheme.typography.labelLarge,
            letterSpacing = 2.sp
        )
    }
}

// ── Chip Tag ──────────────────────────────────────────────────────────────────

@Composable
fun JarvisChip(
    text: String,
    modifier: Modifier = Modifier,
    color: Color       = JarvisColors.CyanCore,
    onClick: (() -> Unit)? = null
) {
    val mod = if (onClick != null) modifier.clickable(onClick = onClick) else modifier
    Box(
        modifier = mod
            .clip(RoundedCornerShape(3.dp))
            .background(color.copy(alpha = 0.1f))
            .border(BorderStroke(0.5.dp, color.copy(alpha = 0.4f)), RoundedCornerShape(3.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text          = text.uppercase(),
            style         = MaterialTheme.typography.labelSmall,
            color         = color,
            letterSpacing = 1.5.sp
        )
    }
}

// ── Progress Bar ──────────────────────────────────────────────────────────────

@Composable
fun HudProgressBar(
    progress: Float,
    modifier: Modifier = Modifier,
    color: Color       = JarvisColors.CyanCore,
    label: String      = ""
) {
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        if (label.isNotBlank()) {
            Row(
                modifier              = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text  = label.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = JarvisColors.TextSecondary,
                    letterSpacing = 1.5.sp
                )
                Text(
                    text  = "${(progress * 100).toInt()}%",
                    style = MaterialTheme.typography.labelSmall,
                    color = color
                )
            }
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(color.copy(alpha = 0.15f))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(progress.coerceIn(0f, 1f))
                    .fillMaxHeight()
                    .background(
                        Brush.horizontalGradient(
                            listOf(color.copy(alpha = 0.7f), color)
                        )
                    )
            )
        }
    }
}

// ── Section Header ────────────────────────────────────────────────────────────

@Composable
fun HudSectionHeader(
    title: String,
    modifier: Modifier  = Modifier,
    subtitle: String    = "",
    accentColor: Color  = JarvisColors.CyanCore,
    action: (@Composable () -> Unit)? = null
) {
    Row(
        modifier              = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment     = Alignment.CenterVertically
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .width(2.dp)
                        .height(16.dp)
                        .background(accentColor, RoundedCornerShape(1.dp))
                )
                Text(
                    text          = title.uppercase(),
                    style         = MaterialTheme.typography.titleSmall,
                    color         = JarvisColors.TextPrimary,
                    letterSpacing = 3.sp
                )
            }
            if (subtitle.isNotBlank()) {
                Text(
                    text          = subtitle,
                    style         = MaterialTheme.typography.bodySmall,
                    color         = JarvisColors.TextMuted,
                    modifier      = Modifier.padding(start = 10.dp, top = 2.dp)
                )
            }
        }
        action?.invoke()
    }
}

// ── Loading Indicator ─────────────────────────────────────────────────────────

@Composable
fun JarvisLoader(
    modifier: Modifier = Modifier,
    color: Color       = JarvisColors.CyanCore,
    size: Dp           = 24.dp
) {
    val rotation by rememberInfiniteTransition(label = "loader").animateFloat(
        initialValue  = 0f,
        targetValue   = 360f,
        animationSpec = infiniteRepeatable(tween(1000, easing = LinearEasing)),
        label         = "loaderRotation"
    )
    Canvas(modifier.size(size)) {
        val r = this.size.width / 2 * 0.85f
        rotate(rotation) {
            drawArc(
                color      = color,
                startAngle = 0f,
                sweepAngle = 260f,
                useCenter  = false,
                style      = Stroke(width = 2f, cap = StrokeCap.Round),
                topLeft    = Offset(center.x - r, center.y - r),
                size       = androidx.compose.ui.geometry.Size(r * 2, r * 2)
            )
        }
    }
}

// ── Thinking Indicator (multi-dot) ────────────────────────────────────────────

@Composable
fun ThinkingIndicator(
    modifier: Modifier = Modifier,
    color: Color       = JarvisColors.GoldAlert
) {
    val transition = rememberInfiniteTransition(label = "thinking")
    val delays     = listOf(0, 200, 400)

    Row(
        modifier              = modifier.padding(vertical = 8.dp, horizontal = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp),
        verticalAlignment     = Alignment.CenterVertically
    ) {
        Text(
            text          = "PROCESSING",
            style         = MaterialTheme.typography.labelSmall,
            color         = color,
            letterSpacing = 3.sp
        )
        Spacer(Modifier.width(4.dp))
        delays.forEach { delayMs ->
            val alpha by transition.animateFloat(
                initialValue  = 0.2f,
                targetValue   = 1f,
                animationSpec = infiniteRepeatable(
                    animation  = tween(600, delayMillis = delayMs),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "dotAlpha$delayMs"
            )
            Canvas(Modifier.size(5.dp)) {
                drawCircle(color.copy(alpha = alpha), 2.5f)
            }
        }
    }
}

// ── Tool Action Badge ─────────────────────────────────────────────────────────

@Composable
fun ToolBadge(
    toolName: String,
    modifier: Modifier = Modifier,
    success: Boolean?  = null
) {
    val color = when (success) {
        true  -> JarvisColors.GreenOnline
        false -> JarvisColors.CrimsonAlert
        null  -> JarvisColors.GoldAlert
    }
    Row(
        modifier          = modifier
            .clip(RoundedCornerShape(3.dp))
            .background(color.copy(0.08f))
            .border(BorderStroke(0.5.dp, color.copy(0.3f)), RoundedCornerShape(3.dp))
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Canvas(Modifier.size(5.dp)) { drawCircle(color, 2.5f) }
        Text(
            text          = "⚡ ${toolName.uppercase()}",
            style         = MaterialTheme.typography.labelSmall,
            color         = color,
            letterSpacing = 1.sp
        )
    }
}
