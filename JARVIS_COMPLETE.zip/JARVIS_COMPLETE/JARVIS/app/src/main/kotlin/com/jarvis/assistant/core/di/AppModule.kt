package com.jarvis.assistant.core.di

import android.content.Context
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.jarvis.assistant.BuildConfig
import com.jarvis.assistant.core.utils.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import java.util.concurrent.TimeUnit
import javax.inject.Qualifier
import javax.inject.Singleton

// ── Dispatcher qualifiers ──────────────────────────────────────────────────────
@Qualifier @Retention(AnnotationRetention.BINARY) annotation class IoDispatcher
@Qualifier @Retention(AnnotationRetention.BINARY) annotation class MainDispatcher
@Qualifier @Retention(AnnotationRetention.BINARY) annotation class DefaultDispatcher

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    // ── Coroutine dispatchers ─────────────────────────────────────────────────
    @Provides @IoDispatcher
    fun provideIoDispatcher(): CoroutineDispatcher = Dispatchers.IO

    @Provides @MainDispatcher
    fun provideMainDispatcher(): CoroutineDispatcher = Dispatchers.Main

    @Provides @DefaultDispatcher
    fun provideDefaultDispatcher(): CoroutineDispatcher = Dispatchers.Default

    // ── Gson ──────────────────────────────────────────────────────────────────
    @Provides @Singleton
    fun provideGson(): Gson = GsonBuilder()
        .setLenient()
        .setPrettyPrinting()
        .create()

    // ── OkHttpClient ──────────────────────────────────────────────────────────
    @Provides @Singleton
    fun provideOkHttpClient(): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)   // LLM responses can be slow
            .writeTimeout(30, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)

        if (BuildConfig.DEBUG) {
            val logging = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY
            }
            builder.addInterceptor(logging)
        }

        return builder.build()
    }

    // ── Utilities ─────────────────────────────────────────────────────────────
    @Provides @Singleton
    fun provideAppPreferences(@ApplicationContext ctx: Context) = AppPreferences(ctx)

    @Provides @Singleton
    fun provideNetworkUtils(@ApplicationContext ctx: Context) = NetworkUtils(ctx)

    @Provides @Singleton
    fun provideBatteryUtils(@ApplicationContext ctx: Context) = BatteryUtils(ctx)

    @Provides @Singleton
    fun providePermissionUtils(@ApplicationContext ctx: Context) = PermissionUtils(ctx)

    @Provides @Singleton
    fun provideEncryptionManager(@ApplicationContext ctx: Context) = EncryptionManager(ctx)

    @Provides @Singleton
    fun provideFileManager(
        @ApplicationContext ctx: Context,
        okHttpClient: OkHttpClient,
        @IoDispatcher dispatcher: CoroutineDispatcher
    ) = FileManager(ctx, okHttpClient, dispatcher)

    @Provides @Singleton
    fun provideDeviceInfoUtils(@ApplicationContext ctx: Context) = DeviceInfoUtils(ctx)

    @Provides @Singleton
    fun provideEmbeddingUtils(@DefaultDispatcher dispatcher: CoroutineDispatcher) =
        EmbeddingUtils(dispatcher)

    @Provides @Singleton
    fun provideAudioUtils(
        @ApplicationContext ctx: Context,
        @IoDispatcher dispatcher: CoroutineDispatcher
    ) = AudioUtils(ctx, dispatcher)

    @Provides @Singleton
    fun provideIntentRouter(@ApplicationContext ctx: Context) = IntentRouter(ctx)

    @Provides @Singleton
    fun provideCommandClassifier() = CommandClassifier()

    @Provides @Singleton
    fun provideTimeUtils() = TimeUtils()
}
