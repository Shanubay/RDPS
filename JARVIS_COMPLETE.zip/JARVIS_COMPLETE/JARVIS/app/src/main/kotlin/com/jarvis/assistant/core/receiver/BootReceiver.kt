package com.jarvis.assistant.core.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.jarvis.assistant.service.voice.WakeWordService
import com.jarvis.assistant.service.overlay.OverlayService

/**
 * BootReceiver — Starts JARVIS services after device reboot.
 * Requires RECEIVE_BOOT_COMPLETED permission.
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED &&
            intent.action != "android.intent.action.QUICKBOOT_POWERON" &&
            intent.action != "com.htc.intent.action.QUICKBOOT_POWERON"
        ) return

        // Start wake word service after boot
        val wakeWordIntent = Intent(context, WakeWordService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(wakeWordIntent)
        } else {
            context.startService(wakeWordIntent)
        }
    }
}
