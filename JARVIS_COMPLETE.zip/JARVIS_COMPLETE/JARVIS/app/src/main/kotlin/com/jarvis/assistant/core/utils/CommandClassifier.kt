package com.jarvis.assistant.core.utils

import javax.inject.Inject
import javax.inject.Singleton

/**
 * CommandClassifier — Classifies raw user text into structured intent categories.
 *
 * Used by the Device Agent and AI Router to decide:
 * • Should this be handled locally (device control)?
 * • Should this go to the AI brain (conversation)?
 * • What type of action is being requested?
 */
@Singleton
class CommandClassifier @Inject constructor() {

    enum class CommandType {
        // Device Control
        APP_LAUNCH,
        PHONE_CALL,
        SET_ALARM,
        SET_TIMER,
        SEND_MESSAGE,
        VOLUME_CONTROL,
        FLASHLIGHT,
        WIFI_TOGGLE,
        BLUETOOTH_TOGGLE,
        SCREENSHOT,
        READ_NOTIFICATIONS,
        OPEN_SETTINGS,

        // Information
        WEATHER,
        TIME_DATE,
        CALENDAR,
        NEWS,

        // Navigation
        NAVIGATE_TO,
        WEB_SEARCH,
        PLAY_MEDIA,

        // Conversation
        GREETING,
        QUESTION,
        GENERAL_CHAT,
        COMMAND_MEMORY,    // "remember that..."
        COMMAND_RECALL,    // "what did I say about..."
        SYSTEM_CONTROL,    // "stop jarvis", "sleep", etc.
        UNKNOWN
    }

    data class ClassifiedCommand(
        val raw: String,
        val type: CommandType,
        val confidence: Float,
        val isDeviceControl: Boolean,
        val requiresInternet: Boolean,
        val estimatedComplexity: Complexity
    )

    enum class Complexity { LOW, MEDIUM, HIGH }

    fun classify(input: String): ClassifiedCommand {
        val lower = input.lowercase().trim()

        val (type, confidence) = detectType(lower)
        val isDeviceControl = isDeviceControlType(type)
        val requiresInternet = requiresInternetForType(type, lower)
        val complexity = estimateComplexity(lower, type)

        return ClassifiedCommand(
            raw                  = input,
            type                 = type,
            confidence           = confidence,
            isDeviceControl      = isDeviceControl,
            requiresInternet     = requiresInternet,
            estimatedComplexity  = complexity
        )
    }

    private fun detectType(lower: String): Pair<CommandType, Float> {
        // System control
        if (lower.matches(Regex(".*(stop|quit|exit|sleep|goodbye|shut down).*jarvis.*|jarvis.*(stop|quit|exit|sleep).*")))
            return CommandType.SYSTEM_CONTROL to 0.95f

        // Greetings
        if (lower.matches(Regex("^(hi|hello|hey|good morning|good evening|good afternoon|what's up|howdy).*")))
            return CommandType.GREETING to 0.9f

        // App launch
        if (lower.matches(Regex("(open|launch|start|run) .+")))
            return CommandType.APP_LAUNCH to 0.92f

        // Phone call
        if (lower.matches(Regex("call .+|ring .+|phone .+")))
            return CommandType.PHONE_CALL to 0.95f

        // Alarm
        if (lower.contains("alarm") || lower.matches(Regex("wake me (up )?(at|in) .+")))
            return CommandType.SET_ALARM to 0.9f

        // Timer
        if (lower.contains("timer") || lower.matches(Regex(".*(set|start) a?.*(minute|second|hour).*timer.*")))
            return CommandType.SET_TIMER to 0.9f

        // Volume
        if (lower.matches(Regex(".*(volume|sound).*(up|down|louder|quieter|increase|decrease|max|mute|unmute).*")))
            return CommandType.VOLUME_CONTROL to 0.92f

        // Flashlight
        if (lower.matches(Regex(".*(flashlight|torch).*(on|off).*|turn (on|off).*(flashlight|torch).*")))
            return CommandType.FLASHLIGHT to 0.96f

        // WiFi
        if (lower.matches(Regex(".*(wifi|wi-fi).*(on|off|enable|disable|toggle).*")))
            return CommandType.WIFI_TOGGLE to 0.92f

        // Bluetooth
        if (lower.matches(Regex(".*(bluetooth|bt).*(on|off|enable|disable|toggle).*")))
            return CommandType.BLUETOOTH_TOGGLE to 0.92f

        // Screenshot
        if (lower.contains("screenshot") || lower.contains("screen capture"))
            return CommandType.SCREENSHOT to 0.95f

        // Notifications
        if (lower.matches(Regex(".*(read|show|tell me|check).*(notification|alert|message).*")))
            return CommandType.READ_NOTIFICATIONS to 0.88f

        // Weather
        if (lower.matches(Regex(".*(weather|temperature|forecast|rain|sunny|cloudy|hot|cold today).*")))
            return CommandType.WEATHER to 0.88f

        // Time / Date
        if (lower.matches(Regex(".*(time|date|day|what day|what time).*")))
            return CommandType.TIME_DATE to 0.85f

        // Calendar
        if (lower.matches(Regex(".*(calendar|schedule|appointment|meeting|event|agenda).*")))
            return CommandType.CALENDAR to 0.85f

        // Navigate
        if (lower.matches(Regex(".*(navigate|directions|take me|how to get|route).*(to )?.+")))
            return CommandType.NAVIGATE_TO to 0.9f

        // Web search
        if (lower.matches(Regex("(search (for )?|google |look up ).+")))
            return CommandType.WEB_SEARCH to 0.9f

        // Media play
        if (lower.matches(Regex("(play |stream ).+")))
            return CommandType.PLAY_MEDIA to 0.85f

        // Message
        if (lower.matches(Regex(".*(send|message|text|whatsapp).+(message|to).+|message .+")))
            return CommandType.SEND_MESSAGE to 0.85f

        // Memory commands
        if (lower.matches(Regex(".*(remember|don'?t forget|note that|store that|save that).*")))
            return CommandType.COMMAND_MEMORY to 0.9f

        if (lower.matches(Regex(".*(what did i|recall|do you remember|look up in memory|what do you know about).*")))
            return CommandType.COMMAND_RECALL to 0.85f

        // Settings
        if (lower.contains("settings") || lower.contains("preferences"))
            return CommandType.OPEN_SETTINGS to 0.8f

        // Question
        if (lower.isQuestion())
            return CommandType.QUESTION to 0.75f

        // Default: general chat
        return CommandType.GENERAL_CHAT to 0.6f
    }

    private fun isDeviceControlType(type: CommandType): Boolean = type in setOf(
        CommandType.APP_LAUNCH, CommandType.PHONE_CALL, CommandType.SET_ALARM,
        CommandType.SET_TIMER, CommandType.SEND_MESSAGE, CommandType.VOLUME_CONTROL,
        CommandType.FLASHLIGHT, CommandType.WIFI_TOGGLE, CommandType.BLUETOOTH_TOGGLE,
        CommandType.SCREENSHOT, CommandType.READ_NOTIFICATIONS, CommandType.OPEN_SETTINGS,
        CommandType.SYSTEM_CONTROL
    )

    private fun requiresInternetForType(type: CommandType, lower: String): Boolean = type in setOf(
        CommandType.WEATHER, CommandType.NEWS, CommandType.WEB_SEARCH,
        CommandType.NAVIGATE_TO, CommandType.PLAY_MEDIA
    ) || (type == CommandType.QUESTION && lower.isComplexQuery())

    private fun estimateComplexity(lower: String, type: CommandType): Complexity {
        if (isDeviceControlType(type)) return Complexity.LOW
        val tokens = lower.estimateTokenCount()
        return when {
            tokens < 20 && !lower.isComplexQuery() -> Complexity.LOW
            tokens < 60 -> Complexity.MEDIUM
            else -> Complexity.HIGH
        }
    }
}
