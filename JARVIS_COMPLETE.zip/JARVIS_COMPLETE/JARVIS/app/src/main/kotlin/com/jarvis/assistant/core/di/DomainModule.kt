package com.jarvis.assistant.core.di

import com.jarvis.assistant.domain.usecase.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * DomainModule — provides all use case instances.
 *
 * Use cases are scoped to SingletonComponent because they hold no mutable
 * UI state — they're pure coordinators between repos.
 */
@Module
@InstallIn(SingletonComponent::class)
object DomainModule {

    @Provides @Singleton
    fun provideGetConversationUseCase(
        chatRepo: com.jarvis.assistant.domain.repository.ChatRepository
    ) = GetConversationUseCase(chatRepo)

    @Provides @Singleton
    fun provideSearchMemoryUseCase(
        manageMemory: ManageMemoryUseCase
    ) = SearchMemoryUseCase(manageMemory)

    @Provides @Singleton
    fun provideValidateApiKeyUseCase(
        aiRepo: com.jarvis.assistant.domain.repository.AIRepository
    ) = ValidateApiKeyUseCase(aiRepo)

    @Provides @Singleton
    fun provideTranscribeAudioUseCase(
        aiRepo: com.jarvis.assistant.domain.repository.AIRepository
    ) = TranscribeAudioUseCase(aiRepo)

    @Provides @Singleton
    fun provideGenerateSpeechUseCase(
        aiRepo: com.jarvis.assistant.domain.repository.AIRepository
    ) = GenerateSpeechUseCase(aiRepo)

    @Provides @Singleton
    fun provideClearConversationUseCase(
        chatRepo: com.jarvis.assistant.domain.repository.ChatRepository
    ) = ClearConversationUseCase(chatRepo)
}
