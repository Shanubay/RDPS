package com.jarvis.assistant.ui.navigation

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.jarvis.assistant.presentation.viewmodel.*
import com.jarvis.assistant.ui.screens.*

object Routes {
    const val CHAT           = "chat"
    const val SETTINGS       = "settings"
    const val MEMORY         = "memory"
    const val MODELS         = "models"
    const val DEVICE_CONTROL = "device_control"
    const val ONBOARDING     = "onboarding"
}

@Composable
fun JarvisNavGraph(
    navController: NavHostController = rememberNavController(),
    startDestination: String         = Routes.CHAT
) {
    NavHost(
        navController    = navController,
        startDestination = startDestination,
        enterTransition  = {
            slideInHorizontally(
                initialOffsetX = { it },
                animationSpec  = tween(280)
            ) + fadeIn(tween(280))
        },
        exitTransition   = {
            slideOutHorizontally(
                targetOffsetX = { -it / 3 },
                animationSpec = tween(280)
            ) + fadeOut(tween(280))
        },
        popEnterTransition = {
            slideInHorizontally(
                initialOffsetX = { -it / 3 },
                animationSpec  = tween(280)
            ) + fadeIn(tween(280))
        },
        popExitTransition  = {
            slideOutHorizontally(
                targetOffsetX = { it },
                animationSpec = tween(280)
            ) + fadeOut(tween(280))
        }
    ) {
        composable(Routes.CHAT) {
            val viewModel: BrainViewModel = hiltViewModel()
            ChatScreen(
                viewModel            = viewModel,
                onNavigateToSettings = { navController.navigate(Routes.SETTINGS) },
                onNavigateToMemory   = { navController.navigate(Routes.MEMORY) },
                onNavigateToModels   = { navController.navigate(Routes.MODELS) }
            )
        }

        composable(Routes.SETTINGS) {
            val viewModel: SettingsViewModel = hiltViewModel()
            SettingsScreen(
                viewModel = viewModel,
                onBack    = { navController.popBackStack() }
            )
        }

        composable(Routes.MEMORY) {
            val viewModel: MemoryViewModel = hiltViewModel()
            MemoryScreen(
                viewModel = viewModel,
                onBack    = { navController.popBackStack() }
            )
        }

        composable(Routes.MODELS) {
            val viewModel: ModelManagerViewModel = hiltViewModel()
            ModelManagerScreen(
                viewModel = viewModel,
                onBack    = { navController.popBackStack() }
            )
        }

        composable(Routes.DEVICE_CONTROL) {
            val viewModel: DeviceControlViewModel = hiltViewModel()
            DeviceControlScreen(
                viewModel = viewModel,
                onBack    = { navController.popBackStack() }
            )
        }

        composable(Routes.ONBOARDING) {
            OnboardingScreen(
                onComplete = {
                    navController.navigate(Routes.CHAT) {
                        popUpTo(Routes.ONBOARDING) { inclusive = true }
                    }
                }
            )
        }
    }
}
