package com.jarvis.assistant.core.utils

import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.Toast
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.onEach
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs
import kotlin.math.roundToInt

// ── String Extensions ─────────────────────────────────────────────────────────

fun String.containsWakeWord(wakeWord: String): Boolean {
    val normalized = this.lowercase().trim()
    val wake = wakeWord.lowercase().trim()
    return normalized.contains(wake) ||
           normalized.contains("hey jarvis") ||
           normalized.contains("jarvis") ||
           levenshteinDistance(normalized, wake) <= 2
}

fun String.estimateTokenCount(): Int =
    (this.split("\\s+".toRegex()).size * 1.3).roundToInt()

fun String.truncateToTokens(maxTokens: Int): String {
    val words = this.split("\\s+".toRegex())
    val maxWords = (maxTokens / 1.3).toInt()
    return if (words.size <= maxWords) this
    else words.take(maxWords).joinToString(" ") + "…"
}

fun String.toTitleCase(): String =
    split(" ").joinToString(" ") { word ->
        word.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
    }

fun String.sanitizeForTts(): String =
    this.replace(Regex("[*_~`#]"), "")        // Remove markdown
        .replace(Regex("```[\\s\\S]*?```"), "Code block omitted.")
        .replace(Regex("`[^`]+`"), "")
        .replace(Regex("\\[([^]]+)\\]\\([^)]+\\)"), "$1")
        .replace(Regex("https?://\\S+"), "link")
        .trim()

fun String.isQuestion(): Boolean =
    this.trimEnd().endsWith("?") ||
    this.lowercase().startsWith("what") ||
    this.lowercase().startsWith("how") ||
    this.lowercase().startsWith("why") ||
    this.lowercase().startsWith("when") ||
    this.lowercase().startsWith("where") ||
    this.lowercase().startsWith("who") ||
    this.lowercase().startsWith("is ") ||
    this.lowercase().startsWith("can ") ||
    this.lowercase().startsWith("does ")

fun String.isComplexQuery(): Boolean {
    val tokenCount = estimateTokenCount()
    val hasCodeRequest = contains(Regex("code|program|script|function|implement", RegexOption.IGNORE_CASE))
    val hasAnalysis = contains(Regex("analyze|compare|explain|difference|pros.*cons", RegexOption.IGNORE_CASE))
    return tokenCount > 50 || hasCodeRequest || hasAnalysis
}

fun String.extractAppName(): String? {
    val patterns = listOf(
        Regex("open\\s+([a-zA-Z]+(?:\\s+[a-zA-Z]+)?)", RegexOption.IGNORE_CASE),
        Regex("launch\\s+([a-zA-Z]+(?:\\s+[a-zA-Z]+)?)", RegexOption.IGNORE_CASE),
        Regex("start\\s+([a-zA-Z]+(?:\\s+[a-zA-Z]+)?)", RegexOption.IGNORE_CASE),
    )
    for (pattern in patterns) {
        val match = pattern.find(this)
        if (match != null) return match.groupValues[1].trim()
    }
    return null
}

fun String.extractContactName(): String? {
    val pattern = Regex("call\\s+(.+?)(?:\\s+on|\\s+at|$)", RegexOption.IGNORE_CASE)
    return pattern.find(this)?.groupValues?.get(1)?.trim()
}

fun String.extractTime(): String? {
    val pattern = Regex("(\\d{1,2}(?::\\d{2})?\\s*(?:am|pm)?)", RegexOption.IGNORE_CASE)
    return pattern.find(this)?.value?.trim()
}

fun levenshteinDistance(s1: String, s2: String): Int {
    val m = s1.length; val n = s2.length
    val dp = Array(m + 1) { IntArray(n + 1) }
    for (i in 0..m) dp[i][0] = i
    for (j in 0..n) dp[0][j] = j
    for (i in 1..m) for (j in 1..n) {
        dp[i][j] = if (s1[i - 1] == s2[j - 1]) dp[i - 1][j - 1]
        else 1 + minOf(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1])
    }
    return dp[m][n]
}

// ── Long / Date Extensions ────────────────────────────────────────────────────

fun Long.toFormattedDate(): String {
    val sdf = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())
    return sdf.format(Date(this))
}

fun Long.toFormattedTime(): String {
    val sdf = SimpleDateFormat("h:mm a", Locale.getDefault())
    return sdf.format(Date(this))
}

fun Long.toFormattedDateTime(): String {
    val now = System.currentTimeMillis()
    val diff = now - this
    return when {
        diff < 60_000       -> "just now"
        diff < 3_600_000    -> "${diff / 60_000}m ago"
        diff < 86_400_000   -> "${diff / 3_600_000}h ago"
        diff < 604_800_000  -> "${diff / 86_400_000}d ago"
        else                -> toFormattedDate()
    }
}

fun Long.toFileSizeString(): String = when {
    this < 1024           -> "${this}B"
    this < 1_048_576      -> "${"%.1f".format(this / 1024.0)}KB"
    this < 1_073_741_824  -> "${"%.1f".format(this / 1_048_576.0)}MB"
    else                  -> "${"%.2f".format(this / 1_073_741_824.0)}GB"
}

// ── Float Extensions ──────────────────────────────────────────────────────────

fun Float.cosineSimilarity(other: FloatArray, thisArray: FloatArray): Float {
    var dot = 0f; var normA = 0f; var normB = 0f
    for (i in thisArray.indices) {
        dot   += thisArray[i] * other[i]
        normA += thisArray[i] * thisArray[i]
        normB += other[i] * other[i]
    }
    return if (normA == 0f || normB == 0f) 0f
    else dot / (Math.sqrt(normA.toDouble()) * Math.sqrt(normB.toDouble())).toFloat()
}

fun FloatArray.cosineSimilarity(other: FloatArray): Float {
    require(this.size == other.size) { "Vectors must be same dimension" }
    var dot = 0f; var normA = 0f; var normB = 0f
    for (i in indices) {
        dot   += this[i] * other[i]
        normA += this[i] * this[i]
        normB += other[i] * other[i]
    }
    return if (normA == 0f || normB == 0f) 0f
    else (dot / (Math.sqrt(normA.toDouble()) * Math.sqrt(normB.toDouble()))).toFloat()
}

// ── Context Extensions ────────────────────────────────────────────────────────

fun Context.showToast(message: String, long: Boolean = false) {
    Toast.makeText(
        this, message,
        if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT
    ).show()
}

fun Context.startServiceCompat(intent: Intent) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        startForegroundService(intent)
    } else {
        startService(intent)
    }
}

// ── Color Extensions ──────────────────────────────────────────────────────────

fun Color.withAlpha(alpha: Float): Color = copy(alpha = alpha)

// ── Flow Extensions ───────────────────────────────────────────────────────────

fun <T> Flow<T>.onEachLog(tag: String): Flow<T> =
    onEach { android.util.Log.d(tag, "Flow emit: $it") }

fun <T> Flow<T>.catchAndLog(tag: String, fallback: T? = null): Flow<T> =
    catch { e ->
        android.util.Log.e(tag, "Flow error", e)
        if (fallback != null) emit(fallback)
    }

// ── IntArray / List extensions ────────────────────────────────────────────────

fun <T> List<T>.takeLast(n: Int): List<T> =
    if (size <= n) this else subList(size - n, size)
