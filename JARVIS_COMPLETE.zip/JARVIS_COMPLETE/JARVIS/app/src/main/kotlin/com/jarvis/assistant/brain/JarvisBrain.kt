package com.jarvis.assistant.brain

import com.jarvis.assistant.brain.agent.AgentTool
import com.jarvis.assistant.brain.agent.ToolExecutor
import com.jarvis.assistant.brain.agent.ToolParser
import com.jarvis.assistant.core.constants.AppConstants
import com.jarvis.assistant.core.utils.AppPreferences
import com.jarvis.assistant.data.remote.AIRouter
import com.jarvis.assistant.domain.entities.Message
import com.jarvis.assistant.domain.entities.MessageRole
import com.jarvis.assistant.domain.usecase.ManageMemoryUseCase
import com.jarvis.assistant.service.accessibility.JarvisAccessibilityService
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

/**
 * JarvisBrain — multi-turn agentic reasoning engine.
 *
 * Implements a ReAct-style (Reason + Act) loop:
 *
 *  1. THINK   → AI reasons about the request
 *  2. TOOL    → AI emits a <tool> JSON block
 *  3. EXECUTE → ToolExecutor runs the tool
 *  4. OBSERVE → Tool result injected back into context
 *  5. REPEAT  → Up to MAX_AGENT_STEPS iterations
 *  6. RESPOND → Final natural-language answer
 *
 * This enables JARVIS to handle complex multi-step requests:
 * "Turn off wifi, set a timer for 10 minutes, then play my study playlist on YouTube"
 */
@Singleton
class JarvisBrain @Inject constructor(
    private val aiRouter: AIRouter,
    private val toolParser: ToolParser,
    private val toolExecutor: ToolExecutor,
    private val manageMemory: ManageMemoryUseCase,
    private val appPreferences: AppPreferences
) {

    companion object {
        private const val TAG            = "JarvisBrain"
        private const val MAX_AGENT_STEPS = 6
        private const val MAX_TOKENS_STEP = 512
    }

    // ── Agent Step Events ─────────────────────────────────────────────────────

    sealed class BrainEvent {
        data class Thinking(val step: Int)                          : BrainEvent()
        data class ToolCalling(val tool: AgentTool, val step: Int)  : BrainEvent()
        data class ToolResult(val result: AgentTool.ToolResult)     : BrainEvent()
        data class StreamToken(val token: String)                   : BrainEvent()
        data class FinalResponse(val text: String, val steps: Int)  : BrainEvent()
        data class Error(val message: String)                       : BrainEvent()
    }

    // ── Entry Point ───────────────────────────────────────────────────────────

    fun process(
        userQuery: String,
        conversationHistory: List<Message>,
        conversationId: String
    ): Flow<BrainEvent> = flow {

        val userName = appPreferences.userName.first()

        // Build rich system prompt with tool manifest + memory context
        val memoryContext  = manageMemory.buildMemoryContext(userQuery)
        val screenContext  = buildScreenContext()
        val systemPrompt   = buildAgentSystemPrompt(userName, memoryContext, screenContext)

        // Working context — grows as agent takes steps
        val workingMessages = conversationHistory.toMutableList()
        workingMessages.add(Message(role = MessageRole.USER, content = userQuery))

        var step              = 0
        var continueLoop      = true
        val fullResponse      = StringBuilder()
        val toolLog           = StringBuilder()

        // ── ReAct Loop ────────────────────────────────────────────────────────

        while (continueLoop && step < MAX_AGENT_STEPS) {
            step++
            emit(BrainEvent.Thinking(step))

            val routing  = aiRouter.selectProvider(userQuery)
            val provider = routing.provider

            // Collect AI response for this step
            val stepResponse = StringBuilder()

            provider.stream(
                messages     = workingMessages,
                systemPrompt = systemPrompt,
                maxTokens    = MAX_TOKENS_STEP
            ).collect { token ->
                stepResponse.append(token)
                // Only emit visible text tokens (not tool JSON blocks)
                if (!token.contains("<tool>") && !token.contains("</tool>")) {
                    emit(BrainEvent.StreamToken(token))
                }
            }

            val responseText = stepResponse.toString()

            // ── Check for tool calls ──────────────────────────────────────────
            if (toolParser.hasToolCall(responseText)) {
                val toolCalls   = toolParser.extractToolCalls(responseText)
                val visibleText = toolParser.stripToolTags(responseText)

                if (visibleText.isNotBlank()) fullResponse.append(visibleText).append(" ")

                // Execute each tool call in sequence
                for (parsed in toolCalls) {
                    val tool = parsed.tool ?: continue

                    emit(BrainEvent.ToolCalling(tool, step))

                    // Handle sub-agent delegation
                    val result = if (tool is AgentTool.AiSubtaskTool) {
                        executeSubAgent(tool, workingMessages, systemPrompt)
                    } else {
                        toolExecutor.execute(tool)
                    }

                    emit(BrainEvent.ToolResult(result))
                    toolLog.appendLine("Tool: ${tool.name} → ${result.output}")

                    // Inject tool result into working context for next iteration
                    workingMessages.add(Message(
                        role    = MessageRole.ASSISTANT,
                        content = "[Tool: ${tool.name}]\n${result.output}"
                    ))
                }

                // Continue loop — AI will use tool results in next step
                continueLoop = step < MAX_AGENT_STEPS

            } else {
                // No tool call — this is the final answer
                fullResponse.append(toolParser.stripToolTags(responseText))
                continueLoop = false
            }
        }

        val finalText = fullResponse.toString().trim()

        // Save to memory in background
        if (finalText.isNotBlank()) {
            manageMemory.extractAndSave(userQuery, finalText)
        }

        emit(BrainEvent.FinalResponse(finalText, step))

    }.catch { e ->
        android.util.Log.e(TAG, "Brain error", e)
        emit(BrainEvent.Error(e.message ?: "Unknown brain error"))
    }

    // ── Sub-Agent Delegation ──────────────────────────────────────────────────

    private suspend fun executeSubAgent(
        tool: AgentTool.AiSubtaskTool,
        parentMessages: List<Message>,
        systemPrompt: String
    ): AgentTool.ToolResult {
        val subMessages = listOf(
            Message(
                role    = MessageRole.USER,
                content = "${tool.subtask}\n\nContext: ${tool.context}"
            )
        )
        val routing   = aiRouter.selectProvider(tool.subtask)
        val result    = StringBuilder()
        routing.provider.stream(subMessages, systemPrompt, MAX_TOKENS_STEP)
            .collect { token -> result.append(token) }

        return AgentTool.ToolResult(
            tool    = tool,
            success = true,
            output  = result.toString().trim()
        )
    }

    // ── System Prompt ─────────────────────────────────────────────────────────

    private fun buildAgentSystemPrompt(
        userName: String,
        memoryContext: String,
        screenContext: String
    ): String {
        val tools = toolParser.buildToolManifest()
        val time  = java.text.SimpleDateFormat(
            "HH:mm, EEE d MMM yyyy", java.util.Locale.ENGLISH
        ).format(java.util.Date())

        return """
You are JARVIS, an advanced AI assistant modeled after Iron Man's JARVIS.
You are intelligent, efficient, and action-oriented. You address the user as "$userName" occasionally.
Current time: $time

━━ TOOLS ━━
You can control the device and take actions by emitting tool calls in this exact format:
<tool>{"tool": "tool_name", "parameters": {...}}</tool>

Available tools:
$tools

━━ RULES ━━
• Use tools when the user's request requires a real action
• You may chain multiple tools in a single response
• After a tool result is returned, reason about the outcome and either call more tools or give a final answer
• Never emit raw JSON outside of <tool> tags
• For simple questions requiring only knowledge, answer directly without tools
• Be concise. JARVIS doesn't pad responses.
• When uncertain about a contact or app name, ask for clarification.

${if (memoryContext.isNotBlank()) "━━ WHAT YOU KNOW ABOUT $userName ━━\n$memoryContext\n" else ""}
${if (screenContext.isNotBlank()) "━━ CURRENT SCREEN ━━\n$screenContext\n" else ""}
        """.trimIndent()
    }

    // ── Context Helpers ───────────────────────────────────────────────────────

    private fun buildScreenContext(): String {
        return JarvisAccessibilityService.instance
            ?.extractScreenText()
            ?.take(300)
            ?: ""
    }
}
