package com.jarvis.assistant.brain

import com.jarvis.assistant.core.constants.AppConstants
import com.jarvis.assistant.data.remote.AIRouter
import com.jarvis.assistant.domain.entities.Message
import com.jarvis.assistant.domain.entities.MessageRole
import com.jarvis.assistant.domain.repository.ChatRepository
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

/**
 * ConversationSummarizer — condenses long conversation history to stay within token limits.
 *
 * Strategy:
 * • Keep the last N messages verbatim (recent context)
 * • Summarize earlier messages into a compact paragraph
 * • Inject summary as a SYSTEM message at the start of context
 *
 * Triggered automatically when conversation exceeds MAX_CONTEXT_MESSAGES.
 */
@Singleton
class ConversationSummarizer @Inject constructor(
    private val aiRouter: AIRouter,
    private val chatRepository: ChatRepository
) {

    data class SummarizedContext(
        val summary: String,
        val recentMessages: List<Message>,
        val totalMessages: Int
    )

    /**
     * Build an optimized context window for AI inference.
     * Returns summary + recent messages combined for prompt construction.
     */
    suspend fun buildOptimizedContext(
        conversationId: String,
        keepRecent: Int = AppConstants.MAX_CONTEXT_MESSAGES
    ): SummarizedContext {
        val allMessages = chatRepository.getMessages(conversationId).first()

        if (allMessages.size <= keepRecent) {
            return SummarizedContext(
                summary        = "",
                recentMessages = allMessages,
                totalMessages  = allMessages.size
            )
        }

        val toSummarize = allMessages.dropLast(keepRecent)
        val recent      = allMessages.takeLast(keepRecent)

        // Check if we already have a cached summary
        val conversation = chatRepository.getAllConversations().first()
            .find { it.id == conversationId }

        val existingSummary = conversation?.summary ?: ""
        val summary = if (existingSummary.isNotBlank() &&
                          toSummarize.size <= AppConstants.MAX_CONTEXT_MESSAGES) {
            // Use cached — messages haven't grown significantly
            existingSummary
        } else {
            // Generate new summary
            val generated = generateSummary(toSummarize)
            // Cache it
            chatRepository.updateConversation(
                conversation!!.copy(summary = generated)
            )
            generated
        }

        return SummarizedContext(
            summary        = summary,
            recentMessages = recent,
            totalMessages  = allMessages.size
        )
    }

    /**
     * Summarize a list of messages into a compact paragraph.
     */
    suspend fun generateSummary(messages: List<Message>): String {
        if (messages.isEmpty()) return ""

        val transcript = messages.joinToString("\n") { msg ->
            val role = if (msg.role == MessageRole.USER) "User" else "JARVIS"
            "$role: ${msg.content.take(200)}"
        }

        val prompt = """
Summarize this conversation segment in 2-3 concise sentences.
Capture key facts, decisions, and important context. Be factual, no padding.

Conversation:
$transcript

Summary:
        """.trimIndent()

        val routing  = aiRouter.selectProvider(prompt)
        val result   = StringBuilder()
        routing.provider.stream(
            messages     = listOf(Message(role = MessageRole.USER, content = prompt)),
            systemPrompt = "You are a concise summarizer. Output only the summary.",
            maxTokens    = 200
        ).collect { token -> result.append(token) }

        return result.toString().trim()
    }

    /**
     * Auto-generate a conversation title from the first user message.
     */
    suspend fun generateTitle(firstUserMessage: String): String {
        val prompt = "Generate a short (3-5 word) title for a conversation that starts with: " +
                     "\"${firstUserMessage.take(100)}\". Output ONLY the title, no quotes."

        val routing = aiRouter.selectProvider(prompt)
        val result  = StringBuilder()
        routing.provider.stream(
            messages     = listOf(Message(role = MessageRole.USER, content = prompt)),
            systemPrompt = "Output only the title text, nothing else.",
            maxTokens    = 20
        ).collect { token -> result.append(token) }

        return result.toString().trim()
            .replace("\"", "")
            .take(50)
    }
}
