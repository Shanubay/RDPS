package com.jarvis.assistant.data.remote

import com.google.gson.Gson
import com.jarvis.assistant.core.constants.AppConstants
import com.jarvis.assistant.core.utils.AppPreferences
import com.jarvis.assistant.data.remote.api.GeminiApi
import com.jarvis.assistant.data.remote.api.SseParser
import com.jarvis.assistant.data.remote.dto.*
import com.jarvis.assistant.domain.entities.Message
import com.jarvis.assistant.domain.entities.MessageRole
import com.jarvis.assistant.domain.usecase.AIProvider
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GeminiProvider @Inject constructor(
    private val prefs: AppPreferences,
    private val gson: Gson,
    private val sseParser: SseParser,
    private val okHttpClient: okhttp3.OkHttpClient
) : AIProvider {

    override val id   = AppConstants.AIProvider.GEMINI
    override val name = "Google Gemini 1.5 Flash"
    override val requiresInternet = true

    companion object {
        private const val MODEL_FLASH = "gemini-1.5-flash"
        private const val MODEL_PRO   = "gemini-1.5-pro"
    }

    private val api: GeminiApi by lazy {
        Retrofit.Builder()
            .baseUrl(AppConstants.ApiUrl.GEMINI)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()
            .create(GeminiApi::class.java)
    }

    private suspend fun getKey() = prefs.geminiKey.first()

    override suspend fun complete(
        messages: List<Message>,
        systemPrompt: String,
        maxTokens: Int,
        temperature: Float
    ): String {
        val key = getKey()
        if (key.isBlank()) return "[Gemini key not set]"

        val request = buildRequest(messages, systemPrompt, maxTokens, temperature)
        val response = api.generateContent(MODEL_FLASH, key, request)

        if (!response.isSuccessful) {
            throw Exception("Gemini HTTP ${response.code()}: ${response.errorBody()?.string()}")
        }

        val geminiResponse = response.body()
        geminiResponse?.error?.let { throw Exception("Gemini error: ${it.message}") }

        return geminiResponse?.candidates?.firstOrNull()
            ?.content?.parts?.firstOrNull()?.text
            ?: throw Exception("Empty Gemini response")
    }

    override fun stream(
        messages: List<Message>,
        systemPrompt: String,
        maxTokens: Int,
        temperature: Float
    ): Flow<String> = flow {
        val key = getKey()
        if (key.isBlank()) { emit("[Gemini key not set — go to Settings]"); return@flow }

        val request = buildRequest(messages, systemPrompt, maxTokens, temperature)

        try {
            val response = api.streamContent(MODEL_FLASH, key, "sse", request)
            if (!response.isSuccessful) {
                emit("[Gemini error: ${response.code()}]")
                return@flow
            }
            val body = response.body() ?: run { emit("[Empty Gemini stream]"); return@flow }
            sseParser.parseGeminiStream(body).collect { token -> emit(token) }
        } catch (e: Exception) {
            // Fallback to non-streaming
            try {
                val text = complete(messages, systemPrompt, maxTokens, temperature)
                emit(text)
            } catch (fallbackEx: Exception) {
                emit("[Gemini unavailable: ${fallbackEx.message}]")
            }
        }
    }

    override suspend fun isAvailable(): Boolean = getKey().isNotBlank()

    private fun buildRequest(
        messages: List<Message>,
        systemPrompt: String,
        maxTokens: Int,
        temperature: Float
    ): GeminiRequest {
        val contents = messages
            .takeLast(AppConstants.MAX_CONTEXT_MESSAGES)
            .map { msg ->
                GeminiContent(
                    role  = if (msg.role == MessageRole.USER) "user" else "model",
                    parts = listOf(GeminiPart(msg.content))
                )
            }

        return GeminiRequest(
            contents           = contents,
            systemInstruction  = GeminiContent(
                role  = "user",
                parts = listOf(GeminiPart(systemPrompt))
            ),
            generationConfig   = GeminiGenerationConfig(
                maxOutputTokens = maxTokens,
                temperature     = temperature
            )
        )
    }
}
