package com.jarvis.assistant.service.device

import android.app.Notification
import android.content.pm.PackageManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.jarvis.assistant.data.local.JarvisDatabase
import com.jarvis.assistant.data.local.entities.NotificationEntity
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import java.util.UUID
import javax.inject.Inject

/**
 * JarvisNotificationListener — captures all device notifications.
 *
 * Stores them in Room so JARVIS can:
 * • "What notifications do I have?"
 * • "Did I get any messages from Sarah?"
 * • "Read my WhatsApp messages"
 * • Context-aware AI responses referencing real device state
 */
@AndroidEntryPoint
class JarvisNotificationListener : NotificationListenerService() {

    @Inject lateinit var db: JarvisDatabase

    private val listenerScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    companion object {
        private val _newNotification = MutableSharedFlow<NotificationEntity>(
            replay        = 0,
            extraBufferCapacity = 10
        )
        val newNotification: SharedFlow<NotificationEntity> = _newNotification.asSharedFlow()

        // Packages to ignore (system noise)
        private val IGNORED_PACKAGES = setOf(
            "android",
            "com.android.systemui",
            "com.android.settings",
            "com.google.android.gms",
            "com.jarvis.assistant"    // don't capture our own notifs
        )
    }

    // ── Notification Posted ───────────────────────────────────────────────────

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        if (sbn.packageName in IGNORED_PACKAGES) return
        if (sbn.isOngoing) return   // skip persistent (music, navigation, etc.)

        val extras = sbn.notification.extras
        val title  = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim()
        val text   = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
                   ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString()?.trim()

        if (title.isNullOrBlank() && text.isNullOrBlank()) return

        val appName = getAppName(sbn.packageName)
        val entity  = NotificationEntity(
            id          = UUID.randomUUID().toString(),
            packageName = sbn.packageName,
            appName     = appName,
            title       = title ?: appName,
            text        = text ?: "",
            timestamp   = sbn.postTime,
            isRead      = false
        )

        listenerScope.launch {
            // Persist to Room
            db.notificationDao().insertNotification(entity)
            // Emit to live observers
            _newNotification.emit(entity)
            // Keep table clean — only last 200
            pruneOldNotifications()
        }
    }

    // ── Notification Removed ──────────────────────────────────────────────────

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        // Optionally mark as read or remove from Room
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun getAppName(packageName: String): String = try {
        packageManager
            .getApplicationLabel(
                packageManager.getApplicationInfo(packageName, PackageManager.GET_META_DATA)
            ).toString()
    } catch (e: Exception) {
        packageName.substringAfterLast(".")
            .replaceFirstChar { it.uppercase() }
    }

    private suspend fun pruneOldNotifications() {
        val cutoff = System.currentTimeMillis() - (7 * 24 * 60 * 60 * 1000L) // 7 days
        db.notificationDao().deleteOldNotifications(cutoff)
    }

    override fun onDestroy() {
        listenerScope.cancel()
        super.onDestroy()
    }
}
