package com.jarvis.assistant.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.domain.entities.Memory
import com.jarvis.assistant.domain.entities.MemoryType
import com.jarvis.assistant.domain.usecase.ManageMemoryUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class MemoryUiState(
    val memories: List<Memory>           = emptyList(),
    val searchResults: List<Pair<Memory, Float>> = emptyList(),
    val searchQuery: String              = "",
    val isSearching: Boolean             = false,
    val selectedType: MemoryType?        = null,
    val isLoading: Boolean               = false,
    val error: String?                   = null
)

@HiltViewModel
class MemoryViewModel @Inject constructor(
    private val manageMemory: ManageMemoryUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(MemoryUiState())
    val uiState: StateFlow<MemoryUiState> = _uiState.asStateFlow()

    init { loadMemories() }

    private fun loadMemories() {
        viewModelScope.launch {
            manageMemory.getAllMemories().collect { memories ->
                _uiState.update { it.copy(memories = memories, isLoading = false) }
            }
        }
    }

    fun searchMemories(query: String) {
        _uiState.update { it.copy(searchQuery = query, isSearching = query.isNotBlank()) }
        if (query.isBlank()) {
            _uiState.update { it.copy(searchResults = emptyList(), isSearching = false) }
            return
        }
        viewModelScope.launch {
            val results = manageMemory.semanticSearch(query)
            _uiState.update { it.copy(searchResults = results, isSearching = false) }
        }
    }

    fun deleteMemory(id: String) {
        viewModelScope.launch { manageMemory.deleteMemory(id) }
    }

    fun clearAllMemories() {
        viewModelScope.launch { manageMemory.clearAll() }
    }

    fun saveMemory(content: String, type: MemoryType = MemoryType.GENERAL) {
        viewModelScope.launch { manageMemory.saveManualMemory(content, type) }
    }

    fun filterByType(type: MemoryType?) {
        _uiState.update { it.copy(selectedType = type) }
    }
}
