package com.jarvis.assistant.core.utils

import java.util.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * TimeUtils — time-aware context for JARVIS personality responses.
 */
@Singleton
class TimeUtils @Inject constructor() {

    enum class TimeOfDay { EARLY_MORNING, MORNING, AFTERNOON, EVENING, NIGHT }

    val currentTimeOfDay: TimeOfDay
        get() {
            val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            return when (hour) {
                in 4..6   -> TimeOfDay.EARLY_MORNING
                in 7..11  -> TimeOfDay.MORNING
                in 12..17 -> TimeOfDay.AFTERNOON
                in 18..21 -> TimeOfDay.EVENING
                else      -> TimeOfDay.NIGHT
            }
        }

    val greeting: String
        get() = when (currentTimeOfDay) {
            TimeOfDay.EARLY_MORNING -> "Good early morning"
            TimeOfDay.MORNING       -> "Good morning"
            TimeOfDay.AFTERNOON     -> "Good afternoon"
            TimeOfDay.EVENING       -> "Good evening"
            TimeOfDay.NIGHT         -> "Good night"
        }

    val greetingWithPersonality: String
        get() = when (currentTimeOfDay) {
            TimeOfDay.EARLY_MORNING -> "Good early morning. You're up early — systems are at your disposal."
            TimeOfDay.MORNING       -> "Good morning. All systems are online and ready."
            TimeOfDay.AFTERNOON     -> "Good afternoon. How can I assist you?"
            TimeOfDay.EVENING       -> "Good evening. What do you need?"
            TimeOfDay.NIGHT         -> "Working late again? I'm here."
        }

    val isBusinessHours: Boolean
        get() {
            val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            val dayOfWeek = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)
            return dayOfWeek in Calendar.MONDAY..Calendar.FRIDAY && hour in 9..17
        }

    val isNightTime: Boolean
        get() = currentTimeOfDay == TimeOfDay.NIGHT || currentTimeOfDay == TimeOfDay.EARLY_MORNING

    fun formatCurrentTime(): String {
        val cal = Calendar.getInstance()
        val hour = cal.get(Calendar.HOUR_OF_DAY)
        val min  = cal.get(Calendar.MINUTE)
        val amPm = if (hour >= 12) "PM" else "AM"
        val h12  = if (hour == 0) 12 else if (hour > 12) hour - 12 else hour
        return "%d:%02d %s".format(h12, min, amPm)
    }

    fun formatCurrentDate(): String {
        val cal = Calendar.getInstance()
        val days   = arrayOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
        val months = arrayOf("January","February","March","April","May","June",
                             "July","August","September","October","November","December")
        val dayName  = days[cal.get(Calendar.DAY_OF_WEEK) - 1]
        val month    = months[cal.get(Calendar.MONTH)]
        val day      = cal.get(Calendar.DAY_OF_MONTH)
        val year     = cal.get(Calendar.YEAR)
        return "$dayName, $month $day, $year"
    }
}
