package com.jarvis.assistant.data.local.dao

import androidx.room.*
import com.jarvis.assistant.data.local.entities.LocalModelEntity
import com.jarvis.assistant.data.local.entities.NotificationEntity
import com.jarvis.assistant.data.local.entities.RoutineEntity
import kotlinx.coroutines.flow.Flow

// ══════════════════════════════════════════════════════════════════════════════
// ModelDao — local AI model management
// ══════════════════════════════════════════════════════════════════════════════

@Dao
interface ModelDao {

    @Query("SELECT * FROM local_models ORDER BY created_at DESC")
    fun getAllModels(): Flow<List<LocalModelEntity>>

    @Query("SELECT * FROM local_models ORDER BY created_at DESC")
    suspend fun getAllModelsOnce(): List<LocalModelEntity>

    @Query("SELECT * FROM local_models WHERE id = :id LIMIT 1")
    suspend fun getModelById(id: String): LocalModelEntity?

    @Query("SELECT * FROM local_models WHERE is_active = 1 LIMIT 1")
    suspend fun getActiveModel(): LocalModelEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertModel(model: LocalModelEntity)

    @Update
    suspend fun updateModel(model: LocalModelEntity)

    @Query("DELETE FROM local_models WHERE id = :id")
    suspend fun deleteModel(id: String)

    @Query("UPDATE local_models SET is_active = 0")
    suspend fun clearActiveModel()

    @Query("UPDATE local_models SET is_active = 1 WHERE id = :id")
    suspend fun setActiveModel(id: String)

    @Query("UPDATE local_models SET status = :status, download_progress = :progress WHERE id = :id")
    suspend fun updateDownloadProgress(id: String, status: String, progress: Int)

    @Query("UPDATE local_models SET file_path = :path, status = 'READY', download_progress = 100 WHERE id = :id")
    suspend fun markDownloadComplete(id: String, path: String)

    @Query("UPDATE local_models SET status = 'ERROR' WHERE id = :id")
    suspend fun markError(id: String)
}

// ══════════════════════════════════════════════════════════════════════════════
// NotificationDao — captured device notifications
// ══════════════════════════════════════════════════════════════════════════════

@Dao
interface NotificationDao {

    @Query("""
        SELECT * FROM notifications 
        ORDER BY timestamp DESC 
        LIMIT 100
    """)
    fun getAllNotifications(): Flow<List<NotificationEntity>>

    @Query("""
        SELECT * FROM notifications 
        WHERE is_read = 0 
        ORDER BY timestamp DESC
    """)
    fun getUnreadNotifications(): Flow<List<NotificationEntity>>

    @Query("""
        SELECT * FROM notifications 
        ORDER BY timestamp DESC 
        LIMIT :limit
    """)
    suspend fun getRecentNotificationsOnce(limit: Int): List<NotificationEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity)

    @Query("UPDATE notifications SET is_read = 1 WHERE id = :id")
    suspend fun markAsRead(id: String)

    @Query("UPDATE notifications SET is_read = 1")
    suspend fun markAllAsRead()

    @Query("DELETE FROM notifications WHERE timestamp < :before")
    suspend fun deleteOldNotifications(before: Long)

    @Query("DELETE FROM notifications")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM notifications WHERE is_read = 0")
    fun getUnreadCount(): Flow<Int>
}

// ══════════════════════════════════════════════════════════════════════════════
// RoutineDao — JARVIS automation routines
// ══════════════════════════════════════════════════════════════════════════════

@Dao
interface RoutineDao {

    @Query("SELECT * FROM routines ORDER BY name ASC")
    fun getAllRoutines(): Flow<List<RoutineEntity>>

    @Query("SELECT * FROM routines WHERE id = :id LIMIT 1")
    suspend fun getRoutineById(id: String): RoutineEntity?

    @Query("SELECT * FROM routines WHERE is_enabled = 1")
    suspend fun getEnabledRoutines(): List<RoutineEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoutine(routine: RoutineEntity)

    @Update
    suspend fun updateRoutine(routine: RoutineEntity)

    @Query("DELETE FROM routines WHERE id = :id")
    suspend fun deleteRoutine(id: String)

    @Query("UPDATE routines SET last_run = :timestamp WHERE id = :id")
    suspend fun updateLastRun(id: String, timestamp: Long)

    @Query("UPDATE routines SET is_enabled = :enabled WHERE id = :id")
    suspend fun setEnabled(id: String, enabled: Boolean)
}
