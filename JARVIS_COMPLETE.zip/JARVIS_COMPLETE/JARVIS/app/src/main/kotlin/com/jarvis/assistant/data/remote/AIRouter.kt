package com.jarvis.assistant.data.remote

import com.jarvis.assistant.core.constants.AppConstants
import com.jarvis.assistant.core.utils.*
import com.jarvis.assistant.domain.usecase.AIProvider
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

/**
 * AIRouter — selects the best AIProvider for any given query context.
 *
 * Decision matrix:
 *
 * ┌─────────────────────────────┬──────────────────┐
 * │ Condition                   │ Provider         │
 * ├─────────────────────────────┼──────────────────┤
 * │ Offline mode / no internet  │ LocalLlama       │
 * │ Battery critical            │ LocalLlama       │
 * │ Simple query (<100 tokens)  │ Groq             │
 * │ Complex / code query        │ OpenAI           │
 * │ Battery saving mode         │ Gemini           │
 * │ User override               │ User's choice    │
 * │ All else                    │ Gemini           │
 * │ Fallback if chosen fails    │ OpenRouter       │
 * └─────────────────────────────┴──────────────────┘
 */
@Singleton
class AIRouter @Inject constructor(
    private val openAiProvider: OpenAiProvider,
    private val geminiProvider: GeminiProvider,
    private val groqProvider: GroqProvider,
    private val openRouterProvider: OpenRouterProvider,
    private val localLlamaProvider: LocalLlamaProvider,
    private val networkUtils: NetworkUtils,
    private val batteryUtils: BatteryUtils,
    private val deviceInfoUtils: DeviceInfoUtils,
    private val appPreferences: AppPreferences
) {

    data class RoutingDecision(
        val provider: AIProvider,
        val reason: String
    )

    suspend fun selectProvider(
        queryText: String,
        forceProvider: String? = null
    ): RoutingDecision {

        val isOffline    = appPreferences.offlineMode.first()
        val hasInternet  = networkUtils.isConnected
        val batteryMode  = batteryUtils.powerMode
        val userPref     = appPreferences.aiProvider.first()
        val tokenEst     = queryText.estimateTokenCount()
        val isComplex    = queryText.isComplexQuery()

        // 1. Always local if offline or no internet
        if (isOffline || !hasInternet) {
            return RoutingDecision(localLlamaProvider, "Offline mode")
        }

        // 2. Critical battery → local to preserve battery
        if (batteryMode == BatteryUtils.PowerMode.LOW && localLlamaProvider.isAvailable()) {
            return RoutingDecision(localLlamaProvider, "Critical battery")
        }

        // 3. Force-provider override (e.g. from UI)
        if (!forceProvider.isNullOrBlank()) {
            return RoutingDecision(providerById(forceProvider), "User forced: $forceProvider")
        }

        // 4. User preference set to local
        if (userPref == AppConstants.AIProvider.LOCAL_LLAMA) {
            return RoutingDecision(localLlamaProvider, "User preference: local")
        }

        // 5. Device tier — low-end devices get Groq (lighter network load)
        if (deviceInfoUtils.deviceTier == DeviceInfoUtils.DeviceTier.LOW && tokenEst < 200) {
            if (groqProvider.isAvailable()) {
                return RoutingDecision(groqProvider, "Low-end device + simple query")
            }
        }

        // 6. Fast small queries → Groq
        if (tokenEst < AppConstants.TOKEN_THRESHOLD_FAST && !isComplex) {
            if (groqProvider.isAvailable()) {
                return RoutingDecision(groqProvider, "Fast query → Groq")
            }
        }

        // 7. Heavy complex queries → OpenAI
        if (isComplex || tokenEst > AppConstants.TOKEN_THRESHOLD_COMPLEX) {
            if (openAiProvider.isAvailable()) {
                return RoutingDecision(openAiProvider, "Complex query → OpenAI GPT-4o")
            }
        }

        // 8. Battery saving → Gemini Flash (cost/token efficient)
        if (batteryMode == BatteryUtils.PowerMode.SAVING) {
            if (geminiProvider.isAvailable()) {
                return RoutingDecision(geminiProvider, "Battery saving → Gemini Flash")
            }
        }

        // 9. Respect user's explicit provider choice
        val userProvider = providerById(userPref)
        if (userProvider.isAvailable()) {
            return RoutingDecision(userProvider, "User preference: $userPref")
        }

        // 10. Try each provider in order of preference
        listOf(geminiProvider, groqProvider, openAiProvider).forEach { p ->
            if (p.isAvailable()) return RoutingDecision(p, "Auto-selected: ${p.name}")
        }

        // 11. Final fallback — OpenRouter (free tier always available)
        return RoutingDecision(openRouterProvider, "Fallback: OpenRouter")
    }

    fun providerById(id: String): AIProvider = when (id) {
        AppConstants.AIProvider.OPENAI      -> openAiProvider
        AppConstants.AIProvider.GEMINI      -> geminiProvider
        AppConstants.AIProvider.GROQ        -> groqProvider
        AppConstants.AIProvider.OPENROUTER  -> openRouterProvider
        AppConstants.AIProvider.LOCAL_LLAMA -> localLlamaProvider
        else                                -> geminiProvider
    }

    fun allProviders(): List<AIProvider> = listOf(
        localLlamaProvider,
        groqProvider,
        geminiProvider,
        openAiProvider,
        openRouterProvider
    )
}
