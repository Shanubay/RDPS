package com.jarvis.assistant.core.di

import com.jarvis.assistant.core.utils.AppPreferences
import com.jarvis.assistant.core.utils.TimeUtils
import com.jarvis.assistant.domain.usecase.ProcessVoiceCommandUseCase
import com.jarvis.assistant.service.voice.VoiceOrchestrator
import android.content.Context
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object VoiceModule {

    @Provides @Singleton
    fun provideVoiceOrchestrator(
        @ApplicationContext context: Context,
        processVoiceCommand: ProcessVoiceCommandUseCase,
        prefs: AppPreferences,
        timeUtils: TimeUtils
    ): VoiceOrchestrator = VoiceOrchestrator(context, processVoiceCommand, prefs, timeUtils)
}
