package com.jarvis.assistant.domain.usecase

import com.jarvis.assistant.domain.entities.Conversation
import com.jarvis.assistant.domain.entities.Message
import com.jarvis.assistant.domain.repository.AIRepository
import com.jarvis.assistant.domain.repository.ChatRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import javax.inject.Inject

// ══════════════════════════════════════════════════════════════════════════════
// Supporting use cases
// ══════════════════════════════════════════════════════════════════════════════

// ── GetConversationUseCase ────────────────────────────────────────────────────

class GetConversationUseCase @Inject constructor(
    private val chatRepository: ChatRepository
) {
    fun getMessages(conversationId: String): Flow<List<Message>> =
        chatRepository.getMessages(conversationId)

    fun getAllConversations(): Flow<List<Conversation>> =
        chatRepository.getAllConversations()

    suspend fun createConversation(title: String): Conversation =
        chatRepository.createConversation(title)

    suspend fun deleteConversation(id: String) =
        chatRepository.deleteConversation(id)

    suspend fun getOrCreateActiveConversation(): Conversation {
        val activeId = chatRepository.getActiveConversationId()
        if (activeId != null) {
            val existing = chatRepository.getAllConversations().first()
                .find { it.id == activeId }
            if (existing != null) return existing
        }
        val new = chatRepository.createConversation("Conversation")
        chatRepository.setActiveConversationId(new.id)
        return new
    }

    fun searchMessages(query: String): Flow<List<Message>> =
        chatRepository.searchMessages(query)
}

// ── SearchMemoryUseCase ───────────────────────────────────────────────────────

class SearchMemoryUseCase @Inject constructor(
    private val manageMemoryUseCase: ManageMemoryUseCase
) {
    suspend fun search(query: String): List<Pair<com.jarvis.assistant.domain.entities.Memory, Float>> =
        manageMemoryUseCase.semanticSearch(query)

    suspend fun saveMemory(content: String) =
        manageMemoryUseCase.saveManualMemory(content)
}

// ── ValidateApiKeyUseCase ─────────────────────────────────────────────────────

class ValidateApiKeyUseCase @Inject constructor(
    private val aiRepository: AIRepository
) {
    sealed class ValidationResult {
        object Valid : ValidationResult()
        data class Invalid(val reason: String) : ValidationResult()
        object Checking : ValidationResult()
    }

    suspend operator fun invoke(provider: String, key: String): ValidationResult {
        if (key.isBlank()) return ValidationResult.Invalid("API key cannot be empty")
        return try {
            val isValid = aiRepository.validateApiKey(provider, key)
            if (isValid) ValidationResult.Valid
            else ValidationResult.Invalid("Invalid API key for $provider")
        } catch (e: Exception) {
            ValidationResult.Invalid(e.message ?: "Validation failed")
        }
    }
}

// ── TranscribeAudioUseCase ────────────────────────────────────────────────────

class TranscribeAudioUseCase @Inject constructor(
    private val aiRepository: AIRepository
) {
    suspend operator fun invoke(audioBytes: ByteArray): Result<String> =
        aiRepository.transcribeAudio(audioBytes)
}

// ── GenerateSpeechUseCase ─────────────────────────────────────────────────────

class GenerateSpeechUseCase @Inject constructor(
    private val aiRepository: AIRepository
) {
    suspend operator fun invoke(
        text: String,
        provider: String,
        voiceId: String,
        speed: Float = 1.0f,
        pitch: Float = 1.0f
    ): Result<ByteArray> = aiRepository.generateSpeech(text, provider, voiceId, speed, pitch)
}

// ── ClearConversationUseCase ──────────────────────────────────────────────────

class ClearConversationUseCase @Inject constructor(
    private val chatRepository: ChatRepository
) {
    suspend operator fun invoke(conversationId: String) {
        chatRepository.deleteConversation(conversationId)
    }
}
