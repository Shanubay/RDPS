package com.jarvis.assistant.core.llm

import com.jarvis.assistant.core.constants.AppConstants
import com.jarvis.assistant.core.di.IoDispatcher
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * LlamaEngine — Kotlin wrapper around the llama.cpp JNI bridge.
 *
 * Handles:
 * • Native library loading
 * • Model load/unload lifecycle
 * • Streaming token generation via callbackFlow
 * • Thread safety — all native calls on IO dispatcher
 */
@Singleton
class LlamaEngine @Inject constructor(
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) {

    companion object {
        private const val TAG = "LlamaEngine"
        private var nativeLibLoaded = false

        init {
            try {
                System.loadLibrary("jarvis_llm_bridge")
                nativeLibLoaded = true
                android.util.Log.i(TAG, "llama.cpp JNI bridge loaded successfully")
            } catch (e: UnsatisfiedLinkError) {
                android.util.Log.w(TAG, "llama.cpp native library not found — running in stub mode")
                nativeLibLoaded = false
            }
        }
    }

    // ── Native method declarations ────────────────────────────────────────────

    private external fun loadModel(modelPath: String, nCtx: Int, nThreads: Int): Boolean
    private external fun isModelLoaded(): Boolean
    private external fun generate(
        prompt: String,
        maxTokens: Int,
        temperature: Float,
        callback: TokenCallback
    ): String
    private external fun stopGeneration()
    private external fun unloadModel()
    private external fun getContextSize(): Int
    private external fun getVocabSize(): Int

    // ── Token callback interface (called from C++ via JNI) ────────────────────

    interface TokenCallback {
        fun onToken(token: String)
    }

    // ── Public API ────────────────────────────────────────────────────────────

    suspend fun loadModel(
        modelPath: String,
        contextSize: Int = AppConstants.MODEL_CONTEXT_SIZE,
        threads: Int = AppConstants.MODEL_THREADS_DEFAULT
    ): Boolean = withContext(ioDispatcher) {
        if (!nativeLibLoaded) {
            android.util.Log.w(TAG, "loadModel called but native lib not loaded (stub mode)")
            return@withContext false
        }
        try {
            loadModel(modelPath, contextSize, threads)
        } catch (e: Exception) {
            android.util.Log.e(TAG, "loadModel failed", e)
            false
        }
    }

    fun isModelLoaded(): Boolean {
        if (!nativeLibLoaded) return false
        return try { isModelLoaded() } catch (e: Exception) { false }
    }

    /**
     * Stream tokens from native llama.cpp via a callbackFlow.
     * Each token is emitted as soon as it's generated.
     */
    fun streamGenerate(
        prompt: String,
        maxTokens: Int = AppConstants.DEFAULT_MAX_TOKENS,
        temperature: Float = AppConstants.DEFAULT_TEMPERATURE
    ): Flow<String> = callbackFlow {
        if (!nativeLibLoaded || !isModelLoaded()) {
            // Stub mode: emit a sensible fallback
            send("I'm running in offline stub mode. Please download and load a model from the Model Manager.")
            close()
            return@callbackFlow
        }

        val callback = object : TokenCallback {
            override fun onToken(token: String) {
                trySend(token)
            }
        }

        try {
            // generate() is blocking — runs on IO dispatcher
            withContext(ioDispatcher) {
                generate(prompt, maxTokens, temperature, callback)
            }
        } catch (e: Exception) {
            android.util.Log.e(TAG, "Generation error", e)
        } finally {
            close()
        }

        awaitClose { stopGenerationNative() }
    }.flowOn(ioDispatcher)

    private fun stopGenerationNative() {
        if (!nativeLibLoaded) return
        try { stopGeneration() } catch (e: Exception) { }
    }

    suspend fun unloadModel() = withContext(ioDispatcher) {
        if (!nativeLibLoaded) return@withContext
        try { unloadModel() } catch (e: Exception) { }
    }

    fun getContextSize(): Int {
        if (!nativeLibLoaded) return 0
        return try { getContextSize() } catch (e: Exception) { 0 }
    }

    fun getVocabSize(): Int {
        if (!nativeLibLoaded) return 0
        return try { getVocabSize() } catch (e: Exception) { 0 }
    }

    /**
     * Format messages into a llama.cpp compatible prompt string.
     * Uses ChatML format which most instruction-tuned GGUF models understand.
     */
    fun formatPrompt(
        systemPrompt: String,
        messages: List<com.jarvis.assistant.domain.entities.Message>
    ): String {
        val sb = StringBuilder()

        // System prompt
        sb.append("<|im_start|>system\n")
        sb.append(systemPrompt)
        sb.append("\n<|im_end|>\n")

        // Conversation history (last N messages)
        val recent = messages.takeLast(10)
        for (msg in recent) {
            val role = when (msg.role) {
                com.jarvis.assistant.domain.entities.MessageRole.USER      -> "user"
                com.jarvis.assistant.domain.entities.MessageRole.ASSISTANT -> "assistant"
                com.jarvis.assistant.domain.entities.MessageRole.SYSTEM    -> "system"
            }
            sb.append("<|im_start|>$role\n")
            sb.append(msg.content)
            sb.append("\n<|im_end|>\n")
        }

        // Trigger assistant response
        sb.append("<|im_start|>assistant\n")

        return sb.toString()
    }
}
