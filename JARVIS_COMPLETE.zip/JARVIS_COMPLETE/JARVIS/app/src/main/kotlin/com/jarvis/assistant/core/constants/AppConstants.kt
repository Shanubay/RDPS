package com.jarvis.assistant.core.constants

/**
 * JARVIS — App-wide constants
 */
object AppConstants {

    // ── AI ────────────────────────────────────────────────────────────────────
    const val MAX_CONTEXT_MESSAGES = 20
    const val MAX_LONG_TERM_MEMORIES = 500
    const val DEFAULT_MAX_TOKENS = 1024
    const val DEFAULT_TEMPERATURE = 0.7f
    const val TOKEN_THRESHOLD_FAST = 100       // tokens below this → use Groq
    const val TOKEN_THRESHOLD_COMPLEX = 800    // tokens above this → use OpenAI

    // ── Models ────────────────────────────────────────────────────────────────
    const val MODELS_DIR = "models"
    const val MODEL_CHUNK_SIZE = 8 * 1024 * 1024  // 8MB download chunks
    const val MODEL_CONTEXT_SIZE = 4096
    const val MODEL_THREADS_DEFAULT = 4

    // ── Voice ─────────────────────────────────────────────────────────────────
    const val WAKE_WORD = "hey jarvis"
    const val WAKE_WORD_ALTERNATE = "jarvis"
    const val STT_SILENCE_THRESHOLD_MS = 1500L
    const val TTS_DEFAULT_SPEED = 1.0f
    const val TTS_DEFAULT_PITCH = 1.0f
    const val TTS_WHISPER_SPEED = 0.85f
    const val TTS_WHISPER_PITCH = 0.9f

    // ── Memory ────────────────────────────────────────────────────────────────
    const val SHORT_TERM_MEMORY_LIMIT = 20
    const val VECTOR_DIMENSION = 384  // MiniLM-L6 embedding size
    const val MEMORY_SIMILARITY_THRESHOLD = 0.75f

    // ── Overlay ───────────────────────────────────────────────────────────────
    const val OVERLAY_DEFAULT_SIZE_DP = 64
    const val OVERLAY_EXPANDED_SIZE_DP = 320

    // ── DataStore keys ────────────────────────────────────────────────────────
    object Prefs {
        const val AI_PROVIDER       = "ai_provider"
        const val ACTIVE_MODEL_PATH = "active_model_path"
        const val ACTIVE_MODEL_NAME = "active_model_name"
        const val VOICE_ENABLED     = "voice_enabled"
        const val TTS_PROVIDER      = "tts_provider"
        const val TTS_VOICE_ID      = "tts_voice_id"
        const val TTS_SPEED         = "tts_speed"
        const val TTS_PITCH         = "tts_pitch"
        const val OVERLAY_ENABLED   = "overlay_enabled"
        const val FIRST_LAUNCH      = "first_launch"
        const val USER_NAME         = "user_name"
        const val THEME_MODE        = "theme_mode"
        const val LANGUAGE          = "language"
        const val OFFLINE_MODE      = "offline_mode"
        const val LOW_POWER_MODE    = "low_power_mode"
        const val OPENAI_KEY        = "openai_key"
        const val GEMINI_KEY        = "gemini_key"
        const val GROQ_KEY          = "groq_key"
        const val ELEVENLABS_KEY    = "elevenlabs_key"
        const val ELEVENLABS_VOICE_ID = "elevenlabs_voice_id"
    }

    // ── Intent actions ────────────────────────────────────────────────────────
    object Actions {
        const val START_WAKE_WORD   = "com.jarvis.action.START_WAKE_WORD"
        const val STOP_WAKE_WORD    = "com.jarvis.action.STOP_WAKE_WORD"
        const val WAKE_WORD_DETECTED = "com.jarvis.action.WAKE_WORD_DETECTED"
        const val START_LISTENING   = "com.jarvis.action.START_LISTENING"
        const val STOP_LISTENING    = "com.jarvis.action.STOP_LISTENING"
        const val SHOW_OVERLAY      = "com.jarvis.action.SHOW_OVERLAY"
        const val HIDE_OVERLAY      = "com.jarvis.action.HIDE_OVERLAY"
        const val OPEN_MAIN         = "com.jarvis.action.OPEN_MAIN"
    }

    // ── AI Provider names ─────────────────────────────────────────────────────
    object AIProvider {
        const val LOCAL_LLAMA = "local_llama"
        const val OPENAI      = "openai"
        const val GEMINI      = "gemini"
        const val GROQ        = "groq"
        const val OPENROUTER  = "openrouter"
    }

    // ── TTS Provider names ────────────────────────────────────────────────────
    object TTSProvider {
        const val ANDROID     = "android_tts"
        const val ELEVENLABS  = "elevenlabs"
        const val EDGE_TTS    = "edge_tts"
    }

    // ── API base URLs ─────────────────────────────────────────────────────────
    object ApiUrl {
        const val OPENAI       = "https://api.openai.com/v1/"
        const val GEMINI       = "https://generativelanguage.googleapis.com/v1beta/"
        const val GROQ         = "https://api.groq.com/openai/v1/"
        const val OPENROUTER   = "https://openrouter.ai/api/v1/"
        const val ELEVENLABS   = "https://api.elevenlabs.io/v1/"
        const val WHISPER      = "https://api.openai.com/v1/audio/"
    }

    // ── ElevenLabs default voice ──────────────────────────────────────────────
    const val ELEVENLABS_DEFAULT_VOICE = "nPczCjzI2devNBz1zQrb"  // "Brian" voice

    // ── Model download sources ────────────────────────────────────────────────
    object ModelCatalog {
        val PHI3_MINI = ModelInfo(
            id = "phi3-mini-4k-instruct-q4",
            name = "Phi-3 Mini (4K)",
            description = "Microsoft Phi-3 Mini — fast reasoning, 4K context",
            url = "https://huggingface.co/microsoft/Phi-3-mini-4k-instruct-gguf/resolve/main/Phi-3-mini-4k-instruct-q4.gguf",
            sizeBytes = 2_200_000_000L,
            ramRequired = "3GB"
        )
        val TINYLLAMA = ModelInfo(
            id = "tinyllama-1.1b-chat-q4",
            name = "TinyLlama 1.1B",
            description = "Ultra-light model for fast responses",
            url = "https://huggingface.co/TheBloke/TinyLlama-1.1B-Chat-v1.0-GGUF/resolve/main/tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf",
            sizeBytes = 669_000_000L,
            ramRequired = "1GB"
        )
        val GEMMA2B = ModelInfo(
            id = "gemma-2b-it-q4",
            name = "Gemma 2B IT",
            description = "Google Gemma — balanced quality & speed",
            url = "https://huggingface.co/google/gemma-2b-it-GGUF/resolve/main/gemma-2b-it.gguf",
            sizeBytes = 1_500_000_000L,
            ramRequired = "2GB"
        )
        val ALL = listOf(TINYLLAMA, GEMMA2B, PHI3_MINI)
    }
}

data class ModelInfo(
    val id: String,
    val name: String,
    val description: String,
    val url: String,
    val sizeBytes: Long,
    val ramRequired: String
)
