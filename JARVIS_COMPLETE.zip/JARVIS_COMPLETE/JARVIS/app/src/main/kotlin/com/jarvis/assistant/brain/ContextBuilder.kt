package com.jarvis.assistant.brain

import com.jarvis.assistant.core.constants.AppConstants
import com.jarvis.assistant.core.utils.AppPreferences
import com.jarvis.assistant.core.utils.BatteryUtils
import com.jarvis.assistant.core.utils.TimeUtils
import com.jarvis.assistant.data.local.JarvisDatabase
import com.jarvis.assistant.domain.entities.Message
import com.jarvis.assistant.domain.entities.MessageRole
import com.jarvis.assistant.domain.usecase.ManageMemoryUseCase
import com.jarvis.assistant.service.accessibility.JarvisAccessibilityService
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

/**
 * ContextBuilder — assembles the richest possible AI context for each request.
 *
 * Sources woven together:
 * • User profile + preferences
 * • Long-term memory (semantic search)
 * • Recent notifications
 * • Device state (battery, wifi, BT)
 * • Current screen text (if accessibility enabled)
 * • Current time + calendar context
 * • Conversation summary (compressed history)
 */
@Singleton
class ContextBuilder @Inject constructor(
    private val manageMemory: ManageMemoryUseCase,
    private val summarizer: ConversationSummarizer,
    private val db: JarvisDatabase,
    private val prefs: AppPreferences,
    private val batteryUtils: BatteryUtils,
    private val timeUtils: TimeUtils
) {

    data class BuiltContext(
        val systemPrompt: String,
        val messages: List<Message>,
        val memorySnippet: String,
        val deviceSnippet: String
    )

    suspend fun build(
        userQuery: String,
        conversationId: String,
        includeScreenText: Boolean = false
    ): BuiltContext {

        // ── Parallel context gathering ─────────────────────────────────────────
        val userName       = prefs.userName.first()
        val memoryContext  = manageMemory.buildMemoryContext(userQuery)
        val deviceContext  = buildDeviceContext()
        val notifContext   = buildNotificationContext()
        val screenContext  = if (includeScreenText) buildScreenContext() else ""

        // ── Conversation history ───────────────────────────────────────────────
        val summarized = summarizer.buildOptimizedContext(conversationId)
        val messages   = buildMessageList(summarized.summary, summarized.recentMessages)

        // ── System Prompt ──────────────────────────────────────────────────────
        val systemPrompt = buildSystemPrompt(
            userName      = userName,
            memoryContext = memoryContext,
            deviceContext = deviceContext,
            notifContext  = notifContext,
            screenContext = screenContext
        )

        return BuiltContext(
            systemPrompt  = systemPrompt,
            messages      = messages,
            memorySnippet = memoryContext,
            deviceSnippet = deviceContext
        )
    }

    // ── System Prompt Assembly ────────────────────────────────────────────────

    private fun buildSystemPrompt(
        userName: String,
        memoryContext: String,
        deviceContext: String,
        notifContext: String,
        screenContext: String
    ): String = buildString {

        append("""
You are JARVIS, an advanced AI assistant modeled after Iron Man's JARVIS.
You are intelligent, witty, calm, and deeply loyal. You address the user as "$userName" occasionally.
You speak precisely — never verbose without reason. You have dry confidence, not arrogance.
When uncertain, you say so rather than fabricate.
Current time: ${timeUtils.fullDateTimeString}
        """.trimIndent())

        if (memoryContext.isNotBlank()) {
            append("\n\n[WHAT YOU KNOW ABOUT $userName]\n$memoryContext")
        }

        if (deviceContext.isNotBlank()) {
            append("\n\n[DEVICE STATE]\n$deviceContext")
        }

        if (notifContext.isNotBlank()) {
            append("\n\n[RECENT NOTIFICATIONS]\n$notifContext")
        }

        if (screenContext.isNotBlank()) {
            append("\n\n[CURRENT SCREEN]\n$screenContext")
        }
    }

    // ── Message List (with optional summary prefix) ───────────────────────────

    private fun buildMessageList(
        summary: String,
        recentMessages: List<Message>
    ): List<Message> {
        if (summary.isBlank()) return recentMessages

        val summaryMessage = Message(
            role    = MessageRole.SYSTEM,
            content = "[Earlier conversation summary]\n$summary"
        )
        return listOf(summaryMessage) + recentMessages
    }

    // ── Device Context ────────────────────────────────────────────────────────

    private fun buildDeviceContext(): String {
        val battery = batteryUtils.batteryLevel
        val power   = batteryUtils.powerMode.name
        val pkg     = JarvisAccessibilityService.foregroundPackage.value
        return buildString {
            append("Battery: $battery% ($power)")
            if (pkg.isNotBlank()) append(" | Active app: $pkg")
        }
    }

    // ── Notification Context ──────────────────────────────────────────────────

    private suspend fun buildNotificationContext(): String {
        val recent = db.notificationDao().getRecentNotificationsOnce(5)
        if (recent.isEmpty()) return ""
        return recent.joinToString("\n") { notif ->
            "• [${notif.appName}] ${notif.title}: ${notif.text.take(80)}"
        }
    }

    // ── Screen Context ────────────────────────────────────────────────────────

    private fun buildScreenContext(): String =
        JarvisAccessibilityService.instance
            ?.extractScreenText()
            ?.take(400)
            ?: ""
}
