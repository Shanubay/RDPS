package com.jarvis.assistant

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.lifecycleScope
import com.jarvis.assistant.core.constants.AppConstants
import com.jarvis.assistant.core.utils.AppPreferences
import com.jarvis.assistant.service.accessibility.JarvisAccessibilityService
import com.jarvis.assistant.service.device.DeviceControlService
import com.jarvis.assistant.service.overlay.OverlayService
import com.jarvis.assistant.service.voice.SpeechRecognitionService
import com.jarvis.assistant.service.voice.TtsService
import com.jarvis.assistant.service.voice.VoiceOrchestrator
import com.jarvis.assistant.service.voice.WakeWordService
import com.jarvis.assistant.brain.agent.ToolExecutor
import com.jarvis.assistant.ui.navigation.JarvisNavGraph
import com.jarvis.assistant.ui.navigation.Routes
import com.jarvis.assistant.ui.theme.JarvisTheme
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var voiceOrchestrator: VoiceOrchestrator
    @Inject lateinit var appPreferences: AppPreferences
    @Inject lateinit var toolExecutor: ToolExecutor

    // ── Bound Services ────────────────────────────────────────────────────────

    private var sttService: SpeechRecognitionService? = null
    private var ttsService: TtsService? = null
    private var deviceService: DeviceControlService? = null

    private val sttConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            sttService = (binder as SpeechRecognitionService.SttBinder).getService()
            voiceOrchestrator.sttService = sttService
        }
        override fun onServiceDisconnected(name: ComponentName) {
            sttService = null
            voiceOrchestrator.sttService = null
        }
    }

    private val ttsConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            ttsService = (binder as TtsService.TtsBinder).getService()
            voiceOrchestrator.ttsService = ttsService
        }
        override fun onServiceDisconnected(name: ComponentName) {
            ttsService = null
            voiceOrchestrator.ttsService = null
        }
    }

    private val deviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            deviceService = (binder as DeviceControlService.DeviceControlBinder).getService()
            toolExecutor.deviceService = deviceService
        }
        override fun onServiceDisconnected(name: ComponentName) {
            deviceService = null
            toolExecutor.deviceService = null
        }
    }

    // ── Permissions ───────────────────────────────────────────────────────────

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.values.all { it }
        if (allGranted) startCoreServices()
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestPermissions()

        setContent {
            JarvisTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val startDest = remember { getStartDestination() }
                    JarvisNavGraph(startDestination = startDest)
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        bindServices()
        voiceOrchestrator.registerWakeWordReceiver()
    }

    override fun onStop() {
        super.onStop()
        voiceOrchestrator.unregisterWakeWordReceiver()
        unbindServices()
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    // ── Start Destination ─────────────────────────────────────────────────────

    private fun getStartDestination(): String {
        // Check synchronously if onboarding has been completed
        // Default to onboarding on first launch
        var start = Routes.CHAT
        lifecycleScope.launch {
            val name = appPreferences.userName.first()
            if (name.isBlank()) start = Routes.ONBOARDING
        }
        return start
    }

    // ── Permissions ───────────────────────────────────────────────────────────

    private fun requestPermissions() {
        val permissions = mutableListOf(
            android.Manifest.permission.RECORD_AUDIO,
            android.Manifest.permission.CAMERA,
            android.Manifest.permission.READ_CONTACTS,
            android.Manifest.permission.SEND_SMS,
            android.Manifest.permission.CALL_PHONE,
            android.Manifest.permission.POST_NOTIFICATIONS
        )
        // Add READ_MEDIA_AUDIO for API 33+
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            permissions.add(android.Manifest.permission.READ_MEDIA_AUDIO)
        }
        permissionLauncher.launch(permissions.toTypedArray())
    }

    // ── Service Management ────────────────────────────────────────────────────

    private fun startCoreServices() {
        // Start wake word service
        val wakeIntent = Intent(this, WakeWordService::class.java)
        startForegroundService(wakeIntent)

        // Start device control
        val deviceIntent = Intent(this, DeviceControlService::class.java)
        startForegroundService(deviceIntent)
    }

    private fun bindServices() {
        // Bind STT
        val sttIntent = Intent(this, SpeechRecognitionService::class.java)
        startForegroundService(sttIntent)
        bindService(sttIntent, sttConnection, Context.BIND_AUTO_CREATE)

        // Bind TTS
        val ttsIntent = Intent(this, TtsService::class.java)
        startService(ttsIntent)
        bindService(ttsIntent, ttsConnection, Context.BIND_AUTO_CREATE)

        // Bind Device
        val deviceIntent = Intent(this, DeviceControlService::class.java)
        startForegroundService(deviceIntent)
        bindService(deviceIntent, deviceConnection, Context.BIND_AUTO_CREATE)
    }

    private fun unbindServices() {
        try { unbindService(sttConnection) }    catch (e: Exception) {}
        try { unbindService(ttsConnection) }    catch (e: Exception) {}
        try { unbindService(deviceConnection) } catch (e: Exception) {}
    }

    // ── Overlay (called from OverlayViewModel) ────────────────────────────────

    fun showOverlay() {
        startService(
            Intent(this, OverlayService::class.java).apply {
                action = AppConstants.Actions.SHOW_OVERLAY
            }
        )
    }

    fun hideOverlay() {
        startService(
            Intent(this, OverlayService::class.java).apply {
                action = AppConstants.Actions.HIDE_OVERLAY
            }
        )
    }
}
