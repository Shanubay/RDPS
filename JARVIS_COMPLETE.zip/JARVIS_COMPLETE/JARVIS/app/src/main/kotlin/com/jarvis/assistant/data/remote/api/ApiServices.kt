package com.jarvis.assistant.data.remote.api

import com.jarvis.assistant.data.remote.dto.*
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.*

// ══════════════════════════════════════════════════════════════════════════════
// OpenAI API  (also used for Groq and OpenRouter — same shape)
// ══════════════════════════════════════════════════════════════════════════════

interface OpenAiApi {

    @POST("chat/completions")
    suspend fun chatComplete(
        @Header("Authorization") authHeader: String,
        @Body request: OpenAiRequest
    ): Response<OpenAiResponse>

    @Streaming
    @POST("chat/completions")
    suspend fun chatStream(
        @Header("Authorization") authHeader: String,
        @Body request: OpenAiRequest
    ): Response<ResponseBody>

    @Multipart
    @POST("audio/transcriptions")
    suspend fun transcribeAudio(
        @Header("Authorization") authHeader: String,
        @Part file: MultipartBody.Part,
        @Part("model") model: RequestBody,
        @Part("language") language: RequestBody
    ): Response<WhisperResponse>
}

// ══════════════════════════════════════════════════════════════════════════════
// Google Gemini API
// ══════════════════════════════════════════════════════════════════════════════

interface GeminiApi {

    @POST("models/{model}:generateContent")
    suspend fun generateContent(
        @Path("model") model: String,
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): Response<GeminiResponse>

    @Streaming
    @POST("models/{model}:streamGenerateContent")
    suspend fun streamContent(
        @Path("model") model: String,
        @Query("key") apiKey: String,
        @Query("alt") alt: String = "sse",
        @Body request: GeminiRequest
    ): Response<ResponseBody>
}

// ══════════════════════════════════════════════════════════════════════════════
// ElevenLabs TTS API
// ══════════════════════════════════════════════════════════════════════════════

interface ElevenLabsApi {

    @POST("text-to-speech/{voice_id}")
    suspend fun textToSpeech(
        @Header("xi-api-key") apiKey: String,
        @Path("voice_id") voiceId: String,
        @Query("output_format") outputFormat: String = "mp3_44100_128",
        @Body request: ElevenLabsTtsRequest
    ): Response<ResponseBody>

    @GET("voices")
    suspend fun getVoices(
        @Header("xi-api-key") apiKey: String
    ): Response<ElevenLabsVoicesResponse>

    @GET("user")
    suspend fun validateKey(
        @Header("xi-api-key") apiKey: String
    ): Response<ResponseBody>
}
