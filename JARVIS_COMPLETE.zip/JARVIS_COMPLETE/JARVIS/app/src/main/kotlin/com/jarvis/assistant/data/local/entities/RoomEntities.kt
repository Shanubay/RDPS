package com.jarvis.assistant.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.jarvis.assistant.domain.entities.MemoryType
import com.jarvis.assistant.domain.entities.MessageRole
import com.jarvis.assistant.domain.entities.MessageStatus

// ══════════════════════════════════════════════════════════════════════════════
// Room Database Entities — JARVIS Memory System
// ══════════════════════════════════════════════════════════════════════════════

// ── Type Converters ───────────────────────────────────────────────────────────

class JarvisTypeConverters {
    @TypeConverter fun fromMessageRole(role: MessageRole): String = role.name
    @TypeConverter fun toMessageRole(name: String): MessageRole =
        MessageRole.valueOf(name)

    @TypeConverter fun fromMessageStatus(s: MessageStatus): String = s.name
    @TypeConverter fun toMessageStatus(name: String): MessageStatus =
        MessageStatus.valueOf(name)

    @TypeConverter fun fromMemoryType(t: MemoryType): String = t.name
    @TypeConverter fun toMemoryType(name: String): MemoryType =
        MemoryType.valueOf(name)

    @TypeConverter fun fromStringList(list: List<String>): String =
        list.joinToString("|||")
    @TypeConverter fun toStringList(s: String): List<String> =
        if (s.isBlank()) emptyList() else s.split("|||")
}

// ── ConversationEntity ────────────────────────────────────────────────────────

@Entity(tableName = "conversations")
@TypeConverters(JarvisTypeConverters::class)
data class ConversationEntity(
    @PrimaryKey
    @ColumnInfo(name = "id")
    val id: String,

    @ColumnInfo(name = "title")
    val title: String = "New Conversation",

    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis(),

    @ColumnInfo(name = "updated_at")
    val updatedAt: Long = System.currentTimeMillis(),

    @ColumnInfo(name = "message_count")
    val messageCount: Int = 0,

    @ColumnInfo(name = "summary")
    val summary: String = "",

    @ColumnInfo(name = "tags")
    val tags: List<String> = emptyList()
)

// ── MessageEntity ─────────────────────────────────────────────────────────────

@Entity(
    tableName = "messages",
    foreignKeys = [
        ForeignKey(
            entity        = ConversationEntity::class,
            parentColumns = ["id"],
            childColumns  = ["conversation_id"],
            onDelete      = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index("conversation_id"),
        Index("timestamp"),
        Index("role")
    ]
)
@TypeConverters(JarvisTypeConverters::class)
data class MessageEntity(
    @PrimaryKey
    @ColumnInfo(name = "id")
    val id: String,

    @ColumnInfo(name = "conversation_id")
    val conversationId: String,

    @ColumnInfo(name = "role")
    val role: MessageRole,

    @ColumnInfo(name = "content")
    val content: String,

    @ColumnInfo(name = "timestamp")
    val timestamp: Long = System.currentTimeMillis(),

    @ColumnInfo(name = "status")
    val status: MessageStatus = MessageStatus.SENT,

    @ColumnInfo(name = "provider")
    val provider: String = "",

    @ColumnInfo(name = "token_count")
    val tokenCount: Int = 0,

    @ColumnInfo(name = "duration_ms")
    val durationMs: Long = 0,

    @ColumnInfo(name = "is_voice")
    val isVoice: Boolean = false,

    @ColumnInfo(name = "audio_path")
    val audioPath: String? = null
)

// ── MemoryEntity ──────────────────────────────────────────────────────────────

@Entity(
    tableName = "memories",
    indices = [
        Index("type"),
        Index("importance"),
        Index("created_at"),
        Index("last_accessed_at")
    ]
)
@TypeConverters(JarvisTypeConverters::class)
data class MemoryEntity(
    @PrimaryKey
    @ColumnInfo(name = "id")
    val id: String,

    @ColumnInfo(name = "content")
    val content: String,

    @ColumnInfo(name = "type")
    val type: MemoryType = MemoryType.GENERAL,

    // Base64-encoded FloatArray for vector similarity search
    @ColumnInfo(name = "embedding_str")
    val embeddingStr: String = "",

    @ColumnInfo(name = "conversation_id")
    val conversationId: String = "",

    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis(),

    @ColumnInfo(name = "access_count")
    val accessCount: Int = 0,

    @ColumnInfo(name = "last_accessed_at")
    val lastAccessedAt: Long = System.currentTimeMillis(),

    // 0.0 (ephemeral) – 1.0 (critical)
    @ColumnInfo(name = "importance")
    val importance: Float = 0.5f,

    // "conversation" | "manual" | "inferred"
    @ColumnInfo(name = "source")
    val source: String = "conversation"
)

// ── LocalModelEntity ──────────────────────────────────────────────────────────

@Entity(tableName = "local_models")
data class LocalModelEntity(
    @PrimaryKey
    @ColumnInfo(name = "id")
    val id: String,

    @ColumnInfo(name = "name")
    val name: String,

    @ColumnInfo(name = "description")
    val description: String = "",

    @ColumnInfo(name = "download_url")
    val downloadUrl: String = "",

    @ColumnInfo(name = "file_path")
    val filePath: String = "",

    @ColumnInfo(name = "size_bytes")
    val sizeBytes: Long = 0,

    @ColumnInfo(name = "ram_required")
    val ramRequired: String = "",

    @ColumnInfo(name = "status")
    val status: String = "NOT_DOWNLOADED",   // matches ModelStatus.name

    @ColumnInfo(name = "download_progress")
    val downloadProgress: Int = 0,

    @ColumnInfo(name = "context_length")
    val contextLength: Int = 4096,

    @ColumnInfo(name = "quantization")
    val quantization: String = "Q4_K_M",

    @ColumnInfo(name = "is_active")
    val isActive: Boolean = false,

    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis()
)

// ── NotificationEntity ────────────────────────────────────────────────────────

@Entity(
    tableName = "notifications",
    indices = [Index("timestamp"), Index("package_name"), Index("is_read")]
)
data class NotificationEntity(
    @PrimaryKey
    @ColumnInfo(name = "id")
    val id: String,

    @ColumnInfo(name = "package_name")
    val packageName: String,

    @ColumnInfo(name = "app_name")
    val appName: String,

    @ColumnInfo(name = "title")
    val title: String,

    @ColumnInfo(name = "text")
    val text: String,

    @ColumnInfo(name = "timestamp")
    val timestamp: Long = System.currentTimeMillis(),

    @ColumnInfo(name = "is_read")
    val isRead: Boolean = false
)

// ── RoutineEntity ─────────────────────────────────────────────────────────────

@Entity(tableName = "routines")
data class RoutineEntity(
    @PrimaryKey
    @ColumnInfo(name = "id")
    val id: String,

    @ColumnInfo(name = "name")
    val name: String,

    // Serialized as JSON string
    @ColumnInfo(name = "trigger_json")
    val triggerJson: String,

    // Serialized as JSON string
    @ColumnInfo(name = "actions_json")
    val actionsJson: String,

    @ColumnInfo(name = "is_enabled")
    val isEnabled: Boolean = true,

    @ColumnInfo(name = "last_run")
    val lastRun: Long = 0L
)
