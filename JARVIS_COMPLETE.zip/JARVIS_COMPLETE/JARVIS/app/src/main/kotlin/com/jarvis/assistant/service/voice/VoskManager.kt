package com.jarvis.assistant.service.voice

import android.content.Context
import com.jarvis.assistant.core.di.IoDispatcher
import com.jarvis.assistant.core.utils.AudioUtils
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import org.vosk.Model
import org.vosk.Recognizer
import org.json.JSONObject
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * VoskManager — fully offline speech-to-text using Vosk.
 *
 * Vosk runs entirely on-device with no internet needed.
 * Models must be downloaded to app's files directory.
 * Emits partial + final transcripts via Flow.
 *
 * Model download: https://alphacephei.com/vosk/models
 * Recommended: vosk-model-small-en-us-0.15 (~40MB)
 */
@Singleton
class VoskManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val audioUtils: AudioUtils,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) {

    companion object {
        private const val TAG          = "VoskManager"
        private const val VOSK_MODEL_DIR = "vosk-model"
        private const val SAMPLE_RATE  = AudioUtils.SAMPLE_RATE.toFloat()
    }

    private var model: Model? = null
    private var recognizer: Recognizer? = null
    private var recognitionJob: Job? = null

    sealed class VoskResult {
        data class Partial(val text: String) : VoskResult()
        data class Final(val text: String) : VoskResult()
        data class Error(val message: String) : VoskResult()
        object ModelNotFound : VoskResult()
    }

    // ── Model Management ──────────────────────────────────────────────────────

    val isModelAvailable: Boolean
        get() = getModelDir()?.exists() == true

    private fun getModelDir(): File? {
        val dir = File(context.filesDir, VOSK_MODEL_DIR)
        return if (dir.exists() && dir.isDirectory) dir else null
    }

    suspend fun loadModel(): Boolean = withContext(ioDispatcher) {
        if (model != null) return@withContext true
        val modelDir = getModelDir() ?: run {
            android.util.Log.w(TAG, "Vosk model not found at ${context.filesDir}/$VOSK_MODEL_DIR")
            return@withContext false
        }
        try {
            model = Model(modelDir.absolutePath)
            android.util.Log.i(TAG, "Vosk model loaded from: ${modelDir.absolutePath}")
            true
        } catch (e: Exception) {
            android.util.Log.e(TAG, "Failed to load Vosk model", e)
            false
        }
    }

    fun unloadModel() {
        stopRecognition()
        recognizer?.close(); recognizer = null
        model?.close();      model      = null
    }

    // ── Continuous Recognition ────────────────────────────────────────────────

    /**
     * Start continuous Vosk recognition.
     * Emits VoskResult.Partial for interim results, VoskResult.Final on silence.
     */
    fun startRecognition(): Flow<VoskResult> = flow {
        val m = model ?: run {
            val loaded = loadModel()
            if (!loaded) { emit(VoskResult.ModelNotFound); return@flow }
            model!!
        }

        val rec = Recognizer(m, SAMPLE_RATE)
        recognizer = rec

        audioUtils.pcmBufferFlow().collect { (buffer, count) ->
            val pcmBytes = audioUtils.shortsToBytesLittleEndian(buffer, count)

            if (rec.acceptWaveForm(pcmBytes, pcmBytes.size)) {
                // Final result
                val json = rec.result
                val text = parseVoskJson(json)
                if (text.isNotBlank()) emit(VoskResult.Final(text))
            } else {
                // Partial result
                val json = rec.partialResult
                val text = parsePartialVoskJson(json)
                if (text.isNotBlank()) emit(VoskResult.Partial(text))
            }
        }

        // Get final result on stop
        val finalJson = rec.finalResult
        val finalText = parseVoskJson(finalJson)
        if (finalText.isNotBlank()) emit(VoskResult.Final(finalText))

    }.catch { e ->
        android.util.Log.e(TAG, "Vosk recognition error", e)
        emit(VoskResult.Error(e.message ?: "Recognition error"))
    }.flowOn(ioDispatcher)

    fun stopRecognition() {
        recognitionJob?.cancel()
        recognitionJob = null
    }

    // ── JSON Parsing ──────────────────────────────────────────────────────────

    private fun parseVoskJson(json: String): String = try {
        JSONObject(json).optString("text", "").trim()
    } catch (e: Exception) { "" }

    private fun parsePartialVoskJson(json: String): String = try {
        JSONObject(json).optString("partial", "").trim()
    } catch (e: Exception) { "" }
}
