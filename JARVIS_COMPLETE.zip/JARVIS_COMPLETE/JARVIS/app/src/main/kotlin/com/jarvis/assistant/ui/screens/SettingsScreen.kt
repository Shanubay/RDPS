package com.jarvis.assistant.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.*
import com.jarvis.assistant.core.constants.AppConstants
import com.jarvis.assistant.domain.usecase.ValidateApiKeyUseCase
import com.jarvis.assistant.presentation.viewmodel.SettingsViewModel
import com.jarvis.assistant.ui.components.*
import com.jarvis.assistant.ui.theme.*

@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onBack: () -> Unit
) {
    val uiState        by viewModel.uiState.collectAsState()
    val validationState by viewModel.validationState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisColors.VoidBlack)
    ) {
        // Header
        Row(
            modifier              = Modifier
                .fillMaxWidth()
                .padding(JarvisSpacing.md),
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(JarvisSpacing.sm)
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, "Back", tint = JarvisColors.CyanCore)
            }
            Column {
                Text(
                    "SETTINGS",
                    style         = MaterialTheme.typography.headlineMedium,
                    color         = JarvisColors.TextPrimary,
                    letterSpacing = 4.sp
                )
                Text(
                    "SYSTEM CONFIGURATION",
                    style         = MaterialTheme.typography.labelSmall,
                    color         = JarvisColors.TextMuted,
                    letterSpacing = 2.sp
                )
            }
        }

        HudDivider()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(JarvisSpacing.md),
            verticalArrangement = Arrangement.spacedBy(JarvisSpacing.lg)
        ) {

            // ── Profile Section ───────────────────────────────────────────────
            HudSectionHeader("Profile", subtitle = "User identity")
            HudCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(JarvisSpacing.md),
                    verticalArrangement = Arrangement.spacedBy(JarvisSpacing.sm)
                ) {
                    SettingsTextField(
                        label    = "Your Name",
                        value    = uiState.userName,
                        onChange = { viewModel.setUserName(it) },
                        hint     = "How JARVIS addresses you"
                    )
                }
            }

            // ── AI Provider Section ───────────────────────────────────────────
            HudSectionHeader("AI Providers", subtitle = "Connect your AI backends")

            HudCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(JarvisSpacing.md),
                    verticalArrangement = Arrangement.spacedBy(JarvisSpacing.md)
                ) {
                    // Provider selector
                    Text(
                        "PRIMARY PROVIDER",
                        style         = MaterialTheme.typography.labelSmall,
                        color         = JarvisColors.TextMuted,
                        letterSpacing = 2.sp
                    )
                    ProviderSelector(
                        selected = uiState.aiProvider,
                        onSelect = { viewModel.setAiProvider(it) }
                    )

                    HudDivider()

                    // API Keys
                    ApiKeyField(
                        label      = "OpenAI API Key",
                        value      = uiState.openAiKey,
                        onChange   = { viewModel.saveOpenAiKey(it) },
                        onValidate = { viewModel.validateKey("openai", it) },
                        hint       = "sk-..."
                    )
                    ApiKeyField(
                        label      = "Google Gemini Key",
                        value      = uiState.geminiKey,
                        onChange   = { viewModel.saveGeminiKey(it) },
                        onValidate = { viewModel.validateKey("gemini", it) },
                        hint       = "AIza..."
                    )
                    ApiKeyField(
                        label      = "Groq API Key",
                        value      = uiState.groqKey,
                        onChange   = { viewModel.saveGroqKey(it) },
                        onValidate = { viewModel.validateKey("groq", it) },
                        hint       = "gsk_..."
                    )
                    ApiKeyField(
                        label      = "ElevenLabs Key",
                        value      = uiState.elevenLabsKey,
                        onChange   = { viewModel.saveElevenLabsKey(it) },
                        onValidate = { viewModel.validateKey("elevenlabs", it) },
                        hint       = "For AI voice synthesis"
                    )

                    // Validation status
                    validationState?.let { state ->
                        val (color, text) = when (state) {
                            is ValidateApiKeyUseCase.ValidationResult.Valid   ->
                                JarvisColors.GreenOnline to "✓ Key valid"
                            is ValidateApiKeyUseCase.ValidationResult.Invalid ->
                                JarvisColors.CrimsonAlert to "✗ ${state.reason}"
                            is ValidateApiKeyUseCase.ValidationResult.Checking ->
                                JarvisColors.GoldAlert to "Checking..."
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text, style = MaterialTheme.typography.bodySmall, color = color)
                        }
                    }
                }
            }

            // ── Voice Section ─────────────────────────────────────────────────
            HudSectionHeader("Voice & TTS", subtitle = "Speech synthesis settings")
            HudCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(JarvisSpacing.md),
                    verticalArrangement = Arrangement.spacedBy(JarvisSpacing.sm)
                ) {
                    SettingToggle(
                        label   = "Voice Mode",
                        sub     = "Enable wake word listening",
                        checked = uiState.voiceEnabled,
                        onToggle = { viewModel.setVoiceEnabled(it) }
                    )
                    HudDivider()
                    SettingToggle(
                        label   = "Overlay Bubble",
                        sub     = "Floating JARVIS over all apps",
                        checked = uiState.overlayEnabled,
                        onToggle = { viewModel.setOverlayEnabled(it) }
                    )
                    HudDivider()

                    Text(
                        "TTS PROVIDER",
                        style         = MaterialTheme.typography.labelSmall,
                        color         = JarvisColors.TextMuted,
                        letterSpacing = 2.sp
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(JarvisSpacing.sm)) {
                        listOf(
                            "android_tts" to "ANDROID",
                            "elevenlabs"  to "ELEVENLABS"
                        ).forEach { (id, label) ->
                            val selected = uiState.ttsProvider == id
                            JarvisChip(
                                text    = label,
                                color   = if (selected) JarvisColors.CyanCore else JarvisColors.TextMuted,
                                onClick = { viewModel.setTtsProvider(id) }
                            )
                        }
                    }
                }
            }

            // ── Advanced ──────────────────────────────────────────────────────
            HudSectionHeader("Advanced", subtitle = "Power settings")
            HudCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(JarvisSpacing.md),
                    verticalArrangement = Arrangement.spacedBy(JarvisSpacing.sm)
                ) {
                    SettingToggle(
                        label   = "Offline Mode",
                        sub     = "Force local AI, no internet calls",
                        checked = uiState.offlineMode,
                        onToggle = { viewModel.setOfflineMode(it) }
                    )
                }
            }

            Spacer(Modifier.height(JarvisSpacing.xxl))
        }
    }
}

// ── Provider Selector ─────────────────────────────────────────────────────────

@Composable
private fun ProviderSelector(selected: String, onSelect: (String) -> Unit) {
    val providers = listOf(
        AppConstants.AIProvider.OPENAI      to "GPT-4o",
        AppConstants.AIProvider.GEMINI      to "GEMINI",
        AppConstants.AIProvider.GROQ        to "GROQ",
        AppConstants.AIProvider.LOCAL_LLAMA to "LOCAL"
    )
    Row(
        modifier              = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(JarvisSpacing.sm)
    ) {
        providers.forEach { (id, label) ->
            val isSelected = selected == id
            JarvisChip(
                text    = label,
                color   = if (isSelected) JarvisColors.CyanCore else JarvisColors.TextSecondary,
                onClick = { onSelect(id) },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

// ── Shared Form Components ────────────────────────────────────────────────────

@Composable
private fun SettingsTextField(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    hint: String = ""
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label.uppercase(), style = MaterialTheme.typography.labelSmall,
            color = JarvisColors.TextMuted, letterSpacing = 2.sp)
        OutlinedTextField(
            value         = value,
            onValueChange = onChange,
            modifier      = Modifier.fillMaxWidth(),
            placeholder   = { Text(hint, color = JarvisColors.TextDisabled) },
            singleLine    = true,
            colors        = OutlinedTextFieldDefaults.colors(
                focusedBorderColor    = JarvisColors.CyanCore.copy(0.6f),
                unfocusedBorderColor  = JarvisColors.BorderNavy,
                cursorColor           = JarvisColors.CyanCore,
                focusedContainerColor = JarvisColors.ElevatedNavy,
                unfocusedContainerColor = JarvisColors.SurfaceNavy,
                focusedTextColor      = JarvisColors.TextPrimary,
                unfocusedTextColor    = JarvisColors.TextPrimary
            ),
            shape = RoundedCornerShape(4.dp)
        )
    }
}

@Composable
private fun ApiKeyField(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    onValidate: (String) -> Unit,
    hint: String = ""
) {
    var visible by remember { mutableStateOf(false) }
    var localKey by remember(value) { mutableStateOf(value) }

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label.uppercase(), style = MaterialTheme.typography.labelSmall,
            color = JarvisColors.TextMuted, letterSpacing = 2.sp)
        OutlinedTextField(
            value                  = localKey,
            onValueChange          = { localKey = it; onChange(it) },
            modifier               = Modifier.fillMaxWidth(),
            placeholder            = { Text(hint, color = JarvisColors.TextDisabled) },
            singleLine             = true,
            visualTransformation   = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon           = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { visible = !visible }) {
                        Icon(
                            if (visible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            null, tint = JarvisColors.TextMuted, modifier = Modifier.size(16.dp)
                        )
                    }
                    if (localKey.isNotBlank()) {
                        IconButton(onClick = { onValidate(localKey) }) {
                            Icon(
                                Icons.Default.CheckCircle, null,
                                tint = JarvisColors.CyanCore, modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor    = JarvisColors.CyanCore.copy(0.6f),
                unfocusedBorderColor  = JarvisColors.BorderNavy,
                cursorColor           = JarvisColors.CyanCore,
                focusedContainerColor = JarvisColors.ElevatedNavy,
                unfocusedContainerColor = JarvisColors.SurfaceNavy,
                focusedTextColor      = JarvisColors.TextPrimary,
                unfocusedTextColor    = JarvisColors.TextPrimary
            ),
            shape = RoundedCornerShape(4.dp)
        )
    }
}

@Composable
private fun SettingToggle(
    label: String,
    sub: String,
    checked: Boolean,
    onToggle: (Boolean) -> Unit
) {
    Row(
        modifier              = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment     = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.bodyMedium, color = JarvisColors.TextPrimary)
            Text(sub,   style = MaterialTheme.typography.bodySmall,  color = JarvisColors.TextMuted)
        }
        Switch(
            checked          = checked,
            onCheckedChange  = onToggle,
            colors           = SwitchDefaults.colors(
                checkedThumbColor   = JarvisColors.CyanCore,
                checkedTrackColor   = JarvisColors.CyanCore.copy(alpha = 0.3f),
                uncheckedThumbColor = JarvisColors.TextMuted,
                uncheckedTrackColor = JarvisColors.BorderNavy
            )
        )
    }
}
