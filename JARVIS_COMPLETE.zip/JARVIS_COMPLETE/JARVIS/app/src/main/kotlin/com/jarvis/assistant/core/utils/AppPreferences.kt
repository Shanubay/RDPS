package com.jarvis.assistant.core.utils

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.jarvis.assistant.core.constants.AppConstants
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "jarvis_prefs")

/**
 * AppPreferences — Centralized DataStore-based preference manager.
 * All persistent settings live here.
 */
@Singleton
class AppPreferences @Inject constructor(
    @ApplicationContext private val context: Context
) {

    // ── Keys ──────────────────────────────────────────────────────────────────
    private object Keys {
        val AI_PROVIDER        = stringPreferencesKey(AppConstants.Prefs.AI_PROVIDER)
        val ACTIVE_MODEL_PATH  = stringPreferencesKey(AppConstants.Prefs.ACTIVE_MODEL_PATH)
        val ACTIVE_MODEL_NAME  = stringPreferencesKey(AppConstants.Prefs.ACTIVE_MODEL_NAME)
        val VOICE_ENABLED      = booleanPreferencesKey(AppConstants.Prefs.VOICE_ENABLED)
        val TTS_PROVIDER       = stringPreferencesKey(AppConstants.Prefs.TTS_PROVIDER)
        val TTS_VOICE_ID       = stringPreferencesKey(AppConstants.Prefs.TTS_VOICE_ID)
        val TTS_SPEED          = floatPreferencesKey(AppConstants.Prefs.TTS_SPEED)
        val TTS_PITCH          = floatPreferencesKey(AppConstants.Prefs.TTS_PITCH)
        val OVERLAY_ENABLED    = booleanPreferencesKey(AppConstants.Prefs.OVERLAY_ENABLED)
        val FIRST_LAUNCH       = booleanPreferencesKey(AppConstants.Prefs.FIRST_LAUNCH)
        val USER_NAME          = stringPreferencesKey(AppConstants.Prefs.USER_NAME)
        val OFFLINE_MODE       = booleanPreferencesKey(AppConstants.Prefs.OFFLINE_MODE)
        val LOW_POWER_MODE     = booleanPreferencesKey(AppConstants.Prefs.LOW_POWER_MODE)
        val OPENAI_KEY         = stringPreferencesKey(AppConstants.Prefs.OPENAI_KEY)
        val GEMINI_KEY         = stringPreferencesKey(AppConstants.Prefs.GEMINI_KEY)
        val GROQ_KEY           = stringPreferencesKey(AppConstants.Prefs.GROQ_KEY)
        val ELEVENLABS_KEY     = stringPreferencesKey(AppConstants.Prefs.ELEVENLABS_KEY)
        val ELEVENLABS_VOICE_ID = stringPreferencesKey(AppConstants.Prefs.ELEVENLABS_VOICE_ID)
    }

    // ── Read flow helper ──────────────────────────────────────────────────────
    private val prefs: Flow<Preferences> = context.dataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }

    // ── AI Provider ───────────────────────────────────────────────────────────
    val aiProvider: Flow<String> = prefs.map {
        it[Keys.AI_PROVIDER] ?: AppConstants.AIProvider.OPENAI
    }

    suspend fun setAiProvider(provider: String) = save { it[Keys.AI_PROVIDER] = provider }

    // ── Active Local Model ────────────────────────────────────────────────────
    val activeModelPath: Flow<String?> = prefs.map { it[Keys.ACTIVE_MODEL_PATH] }
    val activeModelName: Flow<String?> = prefs.map { it[Keys.ACTIVE_MODEL_NAME] }

    suspend fun setActiveModel(path: String, name: String) = save {
        it[Keys.ACTIVE_MODEL_PATH] = path
        it[Keys.ACTIVE_MODEL_NAME] = name
    }

    // ── Voice ─────────────────────────────────────────────────────────────────
    val voiceEnabled: Flow<Boolean> = prefs.map { it[Keys.VOICE_ENABLED] ?: true }
    suspend fun setVoiceEnabled(enabled: Boolean) = save { it[Keys.VOICE_ENABLED] = enabled }

    // ── TTS ───────────────────────────────────────────────────────────────────
    val ttsProvider: Flow<String> = prefs.map {
        it[Keys.TTS_PROVIDER] ?: AppConstants.TTSProvider.ANDROID
    }
    val ttsVoiceId: Flow<String> = prefs.map {
        it[Keys.TTS_VOICE_ID] ?: AppConstants.ELEVENLABS_DEFAULT_VOICE
    }
    val ttsSpeed: Flow<Float> = prefs.map { it[Keys.TTS_SPEED] ?: AppConstants.TTS_DEFAULT_SPEED }
    val ttsPitch: Flow<Float> = prefs.map { it[Keys.TTS_PITCH] ?: AppConstants.TTS_DEFAULT_PITCH }

    suspend fun setTtsProvider(provider: String) = save { it[Keys.TTS_PROVIDER] = provider }
    suspend fun setTtsVoiceId(voiceId: String)   = save { it[Keys.TTS_VOICE_ID] = voiceId }
    suspend fun setTtsSpeed(speed: Float)         = save { it[Keys.TTS_SPEED] = speed }
    suspend fun setTtsPitch(pitch: Float)         = save { it[Keys.TTS_PITCH] = pitch }

    // ── Overlay ───────────────────────────────────────────────────────────────
    val overlayEnabled: Flow<Boolean> = prefs.map { it[Keys.OVERLAY_ENABLED] ?: false }
    suspend fun setOverlayEnabled(enabled: Boolean) = save { it[Keys.OVERLAY_ENABLED] = enabled }

    // ── Onboarding ────────────────────────────────────────────────────────────
    val isFirstLaunch: Flow<Boolean> = prefs.map { it[Keys.FIRST_LAUNCH] ?: true }
    suspend fun setFirstLaunchDone() = save { it[Keys.FIRST_LAUNCH] = false }

    // ── User ──────────────────────────────────────────────────────────────────
    val userName: Flow<String> = prefs.map { it[Keys.USER_NAME] ?: "Sir" }
    suspend fun setUserName(name: String) = save { it[Keys.USER_NAME] = name }

    // ── Offline Mode ──────────────────────────────────────────────────────────
    val offlineMode: Flow<Boolean> = prefs.map { it[Keys.OFFLINE_MODE] ?: false }
    suspend fun setOfflineMode(offline: Boolean) = save { it[Keys.OFFLINE_MODE] = offline }

    val lowPowerMode: Flow<Boolean> = prefs.map { it[Keys.LOW_POWER_MODE] ?: false }
    suspend fun setLowPowerMode(low: Boolean) = save { it[Keys.LOW_POWER_MODE] = low }

    // ── API Keys ──────────────────────────────────────────────────────────────
    val openAiKey: Flow<String>      = prefs.map { it[Keys.OPENAI_KEY] ?: "" }
    val geminiKey: Flow<String>      = prefs.map { it[Keys.GEMINI_KEY] ?: "" }
    val groqKey: Flow<String>        = prefs.map { it[Keys.GROQ_KEY] ?: "" }
    val elevenLabsKey: Flow<String>  = prefs.map { it[Keys.ELEVENLABS_KEY] ?: "" }
    val elevenLabsVoiceId: Flow<String> = prefs.map {
        it[Keys.ELEVENLABS_VOICE_ID] ?: AppConstants.ELEVENLABS_DEFAULT_VOICE
    }

    suspend fun setOpenAiKey(key: String)      = save { it[Keys.OPENAI_KEY] = key }
    suspend fun setGeminiKey(key: String)      = save { it[Keys.GEMINI_KEY] = key }
    suspend fun setGroqKey(key: String)        = save { it[Keys.GROQ_KEY] = key }
    suspend fun setElevenLabsKey(key: String)  = save { it[Keys.ELEVENLABS_KEY] = key }
    suspend fun setElevenLabsVoiceId(id: String) = save { it[Keys.ELEVENLABS_VOICE_ID] = id }

    // ── Helper ────────────────────────────────────────────────────────────────
    private suspend fun save(block: (MutablePreferences) -> Unit) {
        context.dataStore.edit(block)
    }
}
