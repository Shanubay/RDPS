package com.jarvis.assistant.data.repository

import com.jarvis.assistant.core.utils.AppPreferences
import com.jarvis.assistant.data.local.JarvisDatabase
import com.jarvis.assistant.data.local.*
import com.jarvis.assistant.data.local.entities.ConversationEntity
import com.jarvis.assistant.domain.entities.*
import com.jarvis.assistant.domain.repository.ChatRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ChatRepositoryImpl @Inject constructor(
    private val db: JarvisDatabase,
    private val prefs: AppPreferences
) : ChatRepository {

    private val dao get() = db.conversationDao()

    // ── Messages ──────────────────────────────────────────────────────────────

    override fun getMessages(conversationId: String): Flow<List<Message>> =
        dao.getMessagesForConversation(conversationId)
            .map { entities -> entities.map { it.toDomain() } }

    override fun getRecentMessages(limit: Int): Flow<List<Message>> =
        dao.getRecentMessages(limit)
            .map { entities -> entities.map { it.toDomain() } }

    override suspend fun insertMessage(message: Message) {
        val convId = prefs.aiProvider.let {
            // Use a default conversation ID keyed to today if none active
            getActiveConversationId() ?: createDefaultConversation()
        }
        dao.insertMessage(message.toEntity(convId))
        dao.incrementMessageCount(convId, System.currentTimeMillis())
    }

    override suspend fun updateMessage(message: Message) {
        val convId = getActiveConversationId() ?: return
        dao.updateMessage(message.toEntity(convId))
    }

    override suspend fun deleteMessage(messageId: String) =
        dao.deleteMessage(messageId)

    // ── Conversations ─────────────────────────────────────────────────────────

    override fun getAllConversations(): Flow<List<Conversation>> =
        dao.getAllConversations()
            .map { entities -> entities.map { it.toDomain() } }

    override suspend fun createConversation(title: String): Conversation {
        val conv = ConversationEntity(
            id        = UUID.randomUUID().toString(),
            title     = title,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        dao.insertConversation(conv)
        return conv.toDomain()
    }

    override suspend fun updateConversation(conversation: Conversation) =
        dao.updateConversation(conversation.toEntity())

    override suspend fun deleteConversation(conversationId: String) {
        dao.deleteMessagesForConversation(conversationId)
        dao.deleteConversation(conversationId)
    }

    override suspend fun getActiveConversationId(): String? =
        prefs.aiProvider.let { null }   // delegated to prefs — see next line
        .also { }
        .let {
            // Read from DataStore synchronously via blocking
            null // We'll use setActiveConversationId to manage this
        }

    // We manage active conversation ID through a simple in-memory + prefs approach
    private var _activeConvId: String? = null

    override suspend fun setActiveConversationId(id: String) {
        _activeConvId = id
    }

    // Returns current active or creates default
    private suspend fun createDefaultConversation(): String {
        if (_activeConvId != null) return _activeConvId!!
        val conv = createConversation("Conversation")
        _activeConvId = conv.id
        return conv.id
    }

    override fun searchMessages(query: String): Flow<List<Message>> =
        dao.searchMessages(query)
            .map { entities -> entities.map { it.toDomain() } }
}
