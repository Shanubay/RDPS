package com.jarvis.assistant.service.voice

import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaPlayer
import android.os.Binder
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.jarvis.assistant.core.constants.AppConstants
import com.jarvis.assistant.core.utils.AppPreferences
import com.jarvis.assistant.core.utils.NotificationHelper
import com.jarvis.assistant.domain.repository.AIRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.io.File
import java.io.FileOutputStream
import java.util.*
import javax.inject.Inject

/**
 * TtsService — JARVIS voice output engine.
 *
 * Providers:
 * • Android Neural TTS — free, offline, instant
 * • ElevenLabs AI Voice — ultra-realistic, cloud, paid
 *
 * Features:
 * • Interruptible speech (stop mid-sentence)
 * • Emotion styles: NATURAL / SERIOUS / FRIENDLY / WHISPER
 * • Speed and pitch control
 * • Text sanitization (remove markdown)
 * • Streaming word-by-word for faster first-word latency
 */
@AndroidEntryPoint
class TtsService : Service(), TextToSpeech.OnInitListener {

    @Inject lateinit var prefs: AppPreferences
    @Inject lateinit var aiRepository: AIRepository
    @Inject lateinit var notificationHelper: NotificationHelper

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private var androidTts: TextToSpeech? = null
    private var ttsReady = false
    private var mediaPlayer: MediaPlayer? = null
    private var currentSpeakJob: Job? = null

    private val _ttsState = MutableStateFlow<TtsState>(TtsState.Idle)
    val ttsState: StateFlow<TtsState> = _ttsState.asStateFlow()

    sealed class TtsState {
        object Idle     : TtsState()
        object Speaking : TtsState()
        object Stopped  : TtsState()
        data class Error(val message: String) : TtsState()
    }

    inner class TtsBinder : Binder() {
        fun getService() = this@TtsService
    }

    private val binder = TtsBinder()
    override fun onBind(intent: Intent): IBinder = binder

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        androidTts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            androidTts?.apply {
                language = Locale.US
                setSpeechRate(AppConstants.TTS_DEFAULT_SPEED)
                setPitch(AppConstants.TTS_DEFAULT_PITCH)
                setOnUtteranceProgressListener(utteranceListener)
            }
            ttsReady = true
        } else {
            android.util.Log.e("TtsService", "Android TTS init failed: $status")
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int =
        START_NOT_STICKY

    override fun onDestroy() {
        stopSpeaking()
        androidTts?.shutdown()
        serviceScope.cancel()
        super.onDestroy()
    }

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Speak text using the currently configured provider.
     * Interrupts any ongoing speech automatically.
     */
    fun speak(
        text: String,
        style: SpeechStyle = SpeechStyle.NATURAL,
        onDone: (() -> Unit)? = null
    ) {
        if (text.isBlank()) return

        stopSpeaking()
        val sanitized = sanitizeForSpeech(text)

        currentSpeakJob = serviceScope.launch {
            _ttsState.value = TtsState.Speaking
            try {
                val provider = prefs.ttsProvider.first()
                when (provider) {
                    AppConstants.TTSProvider.ELEVENLABS ->
                        speakWithElevenLabs(sanitized, style)
                    else ->
                        speakWithAndroid(sanitized, style)
                }
            } catch (e: Exception) {
                android.util.Log.e("TtsService", "TTS error", e)
                // Fallback to Android TTS
                speakWithAndroid(sanitized, style)
            } finally {
                _ttsState.value = TtsState.Idle
                onDone?.invoke()
            }
        }
    }

    fun stopSpeaking() {
        currentSpeakJob?.cancel()
        androidTts?.stop()
        mediaPlayer?.stop()
        mediaPlayer?.release()
        mediaPlayer = null
        _ttsState.value = TtsState.Stopped
    }

    val isSpeaking: Boolean
        get() = _ttsState.value is TtsState.Speaking

    // ── Android TTS ───────────────────────────────────────────────────────────

    private suspend fun speakWithAndroid(
        text: String,
        style: SpeechStyle
    ) = suspendCancellableCoroutine<Unit> { cont ->
        val tts = androidTts
        if (tts == null || !ttsReady) {
            if (cont.isActive) cont.resume(Unit) {}
            return@suspendCancellableCoroutine
        }

        // Apply style
        val (speed, pitch) = styleToParams(style)
        tts.setSpeechRate(speed)
        tts.setPitch(pitch)

        // Apply EQ / audio attributes
        val audioAttrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANT)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        tts.setAudioAttributes(audioAttrs)

        val utteranceId = UUID.randomUUID().toString()

        // Long text — split into sentences for lower latency
        val chunks = splitIntoSpeechChunks(text)
        var chunkIndex = 0

        fun speakNextChunk() {
            if (chunkIndex >= chunks.size) {
                if (cont.isActive) cont.resume(Unit) {}
                return
            }
            val chunk = chunks[chunkIndex++]
            val queueMode = if (chunkIndex == 1) TextToSpeech.QUEUE_FLUSH
                            else TextToSpeech.QUEUE_ADD
            tts.speak(chunk, queueMode, null, utteranceId + "_$chunkIndex")
        }

        val chunkListener = object : UtteranceProgressListener() {
            override fun onStart(id: String?) { }
            override fun onDone(id: String?) {
                if (id?.startsWith(utteranceId) == true) {
                    if (chunkIndex < chunks.size) speakNextChunk()
                    else if (cont.isActive) cont.resume(Unit) {}
                }
            }
            override fun onError(id: String?) {
                if (cont.isActive) cont.resume(Unit) {}
            }
        }
        tts.setOnUtteranceProgressListener(chunkListener)
        speakNextChunk()

        cont.invokeOnCancellation { tts.stop() }
    }

    // ── ElevenLabs TTS ────────────────────────────────────────────────────────

    private suspend fun speakWithElevenLabs(text: String, style: SpeechStyle) {
        val voiceId = prefs.elevenLabsVoiceId.first()
        val speed   = prefs.ttsSpeed.first()
        val pitch   = prefs.ttsPitch.first()

        val result = aiRepository.generateSpeech(
            text     = text,
            provider = AppConstants.TTSProvider.ELEVENLABS,
            voiceId  = voiceId,
            speed    = speed,
            pitch    = pitch
        )

        result.fold(
            onSuccess = { audioBytes ->
                playMp3Bytes(audioBytes)
            },
            onFailure = { e ->
                android.util.Log.e("TtsService", "ElevenLabs failed, fallback to Android", e)
                speakWithAndroid(text, style)
            }
        )
    }

    private suspend fun playMp3Bytes(audioBytes: ByteArray) =
        suspendCancellableCoroutine<Unit> { cont ->
            try {
                val tmpFile = File.createTempFile("jarvis_tts", ".mp3", cacheDir)
                FileOutputStream(tmpFile).use { it.write(audioBytes) }

                mediaPlayer = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANT)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    setDataSource(tmpFile.absolutePath)
                    prepare()
                    setOnCompletionListener {
                        tmpFile.delete()
                        if (cont.isActive) cont.resume(Unit) {}
                    }
                    setOnErrorListener { _, _, _ ->
                        tmpFile.delete()
                        if (cont.isActive) cont.resume(Unit) {}
                        true
                    }
                    start()
                }

                cont.invokeOnCancellation {
                    mediaPlayer?.stop()
                    mediaPlayer?.release()
                    mediaPlayer = null
                    tmpFile.delete()
                }
            } catch (e: Exception) {
                android.util.Log.e("TtsService", "MP3 playback failed", e)
                if (cont.isActive) cont.resume(Unit) {}
            }
        }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun sanitizeForSpeech(text: String): String = text
        .replace(Regex("```[\\s\\S]*?```"), "Code block omitted.")
        .replace(Regex("`[^`]+`"), "")
        .replace(Regex("#+\\s"), "")
        .replace(Regex("[*_~]{1,3}"), "")
        .replace(Regex("\\[([^]]+)\\]\\([^)]+\\)"), "$1")
        .replace(Regex("https?://\\S+"), "")
        .replace(Regex("\\n{2,}"), ". ")
        .replace("\n", " ")
        .trim()

    private fun splitIntoSpeechChunks(text: String, maxLength: Int = 200): List<String> {
        if (text.length <= maxLength) return listOf(text)
        val chunks = mutableListOf<String>()
        val sentences = text.split(Regex("(?<=[.!?])\\s+"))
        var current = StringBuilder()
        for (sentence in sentences) {
            if (current.length + sentence.length > maxLength && current.isNotEmpty()) {
                chunks.add(current.toString().trim())
                current = StringBuilder()
            }
            current.append(sentence).append(" ")
        }
        if (current.isNotEmpty()) chunks.add(current.toString().trim())
        return chunks.filter { it.isNotBlank() }
    }

    enum class SpeechStyle { NATURAL, SERIOUS, FRIENDLY, WHISPER }

    private fun styleToParams(style: SpeechStyle): Pair<Float, Float> = when (style) {
        SpeechStyle.NATURAL  -> Pair(AppConstants.TTS_DEFAULT_SPEED, AppConstants.TTS_DEFAULT_PITCH)
        SpeechStyle.SERIOUS  -> Pair(0.9f, 0.85f)
        SpeechStyle.FRIENDLY -> Pair(1.1f, 1.1f)
        SpeechStyle.WHISPER  -> Pair(AppConstants.TTS_WHISPER_SPEED, AppConstants.TTS_WHISPER_PITCH)
    }

    private val utteranceListener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?)  { _ttsState.value = TtsState.Speaking }
        override fun onDone(utteranceId: String?)   { }
        override fun onError(utteranceId: String?)  { _ttsState.value = TtsState.Error("TTS error") }
    }
}
