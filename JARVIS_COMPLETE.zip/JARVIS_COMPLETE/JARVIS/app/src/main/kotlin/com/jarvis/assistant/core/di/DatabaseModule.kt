package com.jarvis.assistant.core.di

import android.content.Context
import com.jarvis.assistant.core.llm.LlamaEngine
import com.jarvis.assistant.core.utils.AppPreferences
import com.jarvis.assistant.core.utils.EmbeddingUtils
import com.jarvis.assistant.core.utils.FileManager
import com.jarvis.assistant.data.local.JarvisDatabase
import com.jarvis.assistant.data.local.dao.*
import com.jarvis.assistant.data.repository.*
import com.jarvis.assistant.domain.repository.*
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

// ── Database & DAOs ───────────────────────────────────────────────────────────

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides @Singleton
    fun provideDatabase(@ApplicationContext context: Context): JarvisDatabase =
        JarvisDatabase.buildDatabase(context)

    @Provides @Singleton
    fun provideConversationDao(db: JarvisDatabase): ConversationDao =
        db.conversationDao()

    @Provides @Singleton
    fun provideMemoryDao(db: JarvisDatabase): MemoryDao =
        db.memoryDao()

    @Provides @Singleton
    fun provideModelDao(db: JarvisDatabase): ModelDao =
        db.modelDao()

    @Provides @Singleton
    fun provideNotificationDao(db: JarvisDatabase): NotificationDao =
        db.notificationDao()

    @Provides @Singleton
    fun provideRoutineDao(db: JarvisDatabase): RoutineDao =
        db.routineDao()
}

// ── Repository Bindings ───────────────────────────────────────────────────────

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds @Singleton
    abstract fun bindChatRepository(impl: ChatRepositoryImpl): ChatRepository

    @Binds @Singleton
    abstract fun bindMemoryRepository(impl: MemoryRepositoryImpl): MemoryRepository

    @Binds @Singleton
    abstract fun bindModelRepository(impl: ModelRepositoryImpl): ModelRepository

    @Binds @Singleton
    abstract fun bindDeviceRepository(impl: DeviceRepositoryImpl): DeviceRepository
}

// ── LlamaEngine ───────────────────────────────────────────────────────────────

@Module
@InstallIn(SingletonComponent::class)
object LlmModule {

    @Provides @Singleton
    fun provideLlamaEngine(@IoDispatcher dispatcher: kotlinx.coroutines.CoroutineDispatcher) =
        LlamaEngine(dispatcher)
}
