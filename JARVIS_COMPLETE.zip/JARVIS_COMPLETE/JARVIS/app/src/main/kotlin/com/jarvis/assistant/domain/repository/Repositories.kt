package com.jarvis.assistant.domain.repository

import com.jarvis.assistant.domain.entities.*
import kotlinx.coroutines.flow.Flow

// ══════════════════════════════════════════════════════════════════════════════
// JARVIS Repository Interfaces — Domain Layer
// These are pure contracts; implementations live in the data layer.
// ══════════════════════════════════════════════════════════════════════════════

// ── Chat / Conversation Repository ───────────────────────────────────────────

interface ChatRepository {
    /** Get all messages for a conversation, ordered by timestamp */
    fun getMessages(conversationId: String): Flow<List<Message>>

    /** Get the most recent N messages across all conversations */
    fun getRecentMessages(limit: Int): Flow<List<Message>>

    /** Insert a new message */
    suspend fun insertMessage(message: Message)

    /** Update an existing message (e.g. streaming complete) */
    suspend fun updateMessage(message: Message)

    /** Delete a single message */
    suspend fun deleteMessage(messageId: String)

    /** Get all conversations, ordered by most recent */
    fun getAllConversations(): Flow<List<Conversation>>

    /** Create a new conversation */
    suspend fun createConversation(title: String): Conversation

    /** Update conversation metadata */
    suspend fun updateConversation(conversation: Conversation)

    /** Delete a conversation and all its messages */
    suspend fun deleteConversation(conversationId: String)

    /** Get the active conversation ID from prefs */
    suspend fun getActiveConversationId(): String?

    /** Set the active conversation */
    suspend fun setActiveConversationId(id: String)

    /** Search messages by content */
    fun searchMessages(query: String): Flow<List<Message>>
}

// ── Memory Repository ─────────────────────────────────────────────────────────

interface MemoryRepository {
    /** Get all memories, ordered by recency */
    fun getAllMemories(): Flow<List<Memory>>

    /** Get memories by type */
    fun getMemoriesByType(type: MemoryType): Flow<List<Memory>>

    /** Get top memories by importance score */
    fun getTopMemories(limit: Int): Flow<List<Memory>>

    /** Insert a new memory */
    suspend fun insertMemory(memory: Memory)

    /** Update memory (e.g. increment access count) */
    suspend fun updateMemory(memory: Memory)

    /** Delete a specific memory */
    suspend fun deleteMemory(memoryId: String)

    /** Clear all memories */
    suspend fun clearAllMemories()

    /** Get all memories with embeddings for semantic search */
    suspend fun getAllMemoriesWithEmbeddings(): List<Memory>

    /** Get recent memories injected into AI context */
    suspend fun getContextMemories(limit: Int = 5): List<Memory>

    /** Mark memory as accessed (update access count + timestamp) */
    suspend fun touchMemory(memoryId: String)
}

// ── AI Repository ─────────────────────────────────────────────────────────────

interface AIRepository {
    /** Send messages to active AI provider and get a complete response */
    suspend fun complete(
        messages: List<Message>,
        systemPrompt: String,
        provider: String,
        maxTokens: Int
    ): Result<String>

    /** Stream tokens from AI provider */
    fun stream(
        messages: List<Message>,
        systemPrompt: String,
        provider: String,
        maxTokens: Int
    ): Flow<String>

    /** Transcribe audio bytes to text via Whisper */
    suspend fun transcribeAudio(audioBytes: ByteArray): Result<String>

    /** Generate TTS audio bytes */
    suspend fun generateSpeech(
        text: String,
        provider: String,
        voiceId: String,
        speed: Float,
        pitch: Float
    ): Result<ByteArray>

    /** Test if a provider API key is valid */
    suspend fun validateApiKey(provider: String, key: String): Boolean
}

// ── Model Repository ──────────────────────────────────────────────────────────

interface ModelRepository {
    /** Get all AI models (catalog + download status) */
    fun getAllModels(): Flow<List<AIModel>>

    /** Get currently active local model */
    suspend fun getActiveModel(): AIModel?

    /** Set the active local model */
    suspend fun setActiveModel(modelId: String)

    /** Download a model — emits progress */
    fun downloadModel(model: AIModel): Flow<AIModel>

    /** Delete a downloaded model */
    suspend fun deleteModel(modelId: String): Boolean

    /** Load a model into memory for inference */
    suspend fun loadModel(modelId: String): Boolean

    /** Unload model from memory */
    suspend fun unloadModel()

    /** Check if model is currently loaded in memory */
    fun isModelLoaded(): Boolean

    /** Run local inference */
    fun generateLocal(
        prompt: String,
        maxTokens: Int,
        temperature: Float
    ): Flow<String>
}

// ── Device Repository ─────────────────────────────────────────────────────────

interface DeviceRepository {
    /** Get current device state */
    fun getDeviceState(): Flow<DeviceState>

    /** Set wifi state */
    suspend fun setWifi(enabled: Boolean): Boolean

    /** Set bluetooth state */
    suspend fun setBluetooth(enabled: Boolean): Boolean

    /** Set flashlight state */
    suspend fun setFlashlight(enabled: Boolean): Boolean

    /** Set media volume (0–maxVolume) */
    suspend fun setVolume(level: Int): Boolean

    /** Adjust volume by delta */
    suspend fun adjustVolume(delta: Int): Int

    /** Get all installed apps */
    suspend fun getInstalledApps(): List<AppInfo>

    /** Get recent app notifications */
    fun getNotifications(): Flow<List<AppNotification>>

    /** Take a screenshot (requires MediaProjection or root) */
    suspend fun takeScreenshot(): Result<String>

    /** Get current foreground app */
    suspend fun getForegroundApp(): String?
}

data class AppInfo(
    val packageName: String,
    val label: String,
    val icon: Any? = null
)

// ── Settings Repository ───────────────────────────────────────────────────────

interface SettingsRepository {
    fun getSettings(): Flow<SettingsState>
    suspend fun updateSettings(settings: SettingsState)
    suspend fun getApiKey(provider: String): String
    suspend fun saveApiKey(provider: String, key: String)
}

// ── Routine Repository ────────────────────────────────────────────────────────

interface RoutineRepository {
    fun getAllRoutines(): Flow<List<Routine>>
    suspend fun insertRoutine(routine: Routine)
    suspend fun updateRoutine(routine: Routine)
    suspend fun deleteRoutine(routineId: String)
    suspend fun getRoutineById(id: String): Routine?
}
