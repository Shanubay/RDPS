package com.jarvis.assistant.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.jarvis.assistant.domain.entities.Memory
import com.jarvis.assistant.domain.entities.MemoryType
import com.jarvis.assistant.presentation.viewmodel.MemoryViewModel
import com.jarvis.assistant.ui.components.*
import com.jarvis.assistant.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MemoryScreen(
    viewModel: MemoryViewModel,
    onBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    var searchQuery   by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisColors.VoidBlack)
    ) {
        // ── Header ────────────────────────────────────────────────────────────
        Row(
            modifier              = Modifier
                .fillMaxWidth()
                .padding(JarvisSpacing.md),
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(JarvisSpacing.sm)
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, "Back", tint = JarvisColors.CyanCore)
                }
                Column {
                    Text(
                        "MEMORY CORE",
                        style         = MaterialTheme.typography.headlineMedium,
                        color         = JarvisColors.TextPrimary,
                        letterSpacing = 4.sp
                    )
                    Text(
                        "${uiState.memories.size} RECORDS",
                        style         = MaterialTheme.typography.labelSmall,
                        color         = JarvisColors.TextMuted,
                        letterSpacing = 2.sp
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(onClick = { showAddDialog = true }) {
                    Icon(Icons.Default.Add, "Add", tint = JarvisColors.CyanCore)
                }
                IconButton(onClick = { viewModel.clearAllMemories() }) {
                    Icon(Icons.Default.DeleteSweep, "Clear all", tint = JarvisColors.CrimsonAlert)
                }
            }
        }

        HudDivider()

        // ── Search ────────────────────────────────────────────────────────────
        OutlinedTextField(
            value         = searchQuery,
            onValueChange = {
                searchQuery = it
                viewModel.searchMemories(it)
            },
            modifier      = Modifier
                .fillMaxWidth()
                .padding(horizontal = JarvisSpacing.md, vertical = JarvisSpacing.sm),
            placeholder   = { Text("Search memories...", color = JarvisColors.TextDisabled) },
            leadingIcon   = {
                Icon(Icons.Default.Search, null, tint = JarvisColors.TextMuted)
            },
            trailingIcon  = if (searchQuery.isNotBlank()) {{
                IconButton(onClick = {
                    searchQuery = ""
                    viewModel.searchMemories("")
                }) {
                    Icon(Icons.Default.Close, null, tint = JarvisColors.TextMuted)
                }
            }} else null,
            singleLine    = true,
            colors        = OutlinedTextFieldDefaults.colors(
                focusedBorderColor    = JarvisColors.CyanCore.copy(0.6f),
                unfocusedBorderColor  = JarvisColors.BorderNavy,
                cursorColor           = JarvisColors.CyanCore,
                focusedContainerColor = JarvisColors.ElevatedNavy,
                unfocusedContainerColor = JarvisColors.SurfaceNavy,
                focusedTextColor      = JarvisColors.TextPrimary,
                unfocusedTextColor    = JarvisColors.TextPrimary
            ),
            shape = RoundedCornerShape(4.dp)
        )

        // ── Type Filter Chips ─────────────────────────────────────────────────
        LazyRow(
            contentPadding        = PaddingValues(horizontal = JarvisSpacing.md),
            horizontalArrangement = Arrangement.spacedBy(JarvisSpacing.sm),
            modifier              = Modifier.padding(bottom = JarvisSpacing.sm)
        ) {
            item {
                JarvisChip(
                    text    = "ALL",
                    color   = if (uiState.selectedType == null) JarvisColors.CyanCore else JarvisColors.TextMuted,
                    onClick = { viewModel.filterByType(null) }
                )
            }
            items(MemoryType.values()) { type ->
                JarvisChip(
                    text    = type.name,
                    color   = if (uiState.selectedType == type)
                                memoryTypeColor(type) else JarvisColors.TextMuted,
                    onClick = { viewModel.filterByType(type) }
                )
            }
        }

        HudDivider()

        // ── Memory List ───────────────────────────────────────────────────────
        val displayList = when {
            searchQuery.isNotBlank() -> uiState.searchResults.map { it.first }
            uiState.selectedType != null ->
                uiState.memories.filter { it.type == uiState.selectedType }
            else -> uiState.memories
        }

        if (displayList.isEmpty()) {
            Box(
                modifier          = Modifier.fillMaxSize(),
                contentAlignment  = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(JarvisSpacing.sm)
                ) {
                    Icon(
                        Icons.Default.Psychology,
                        null,
                        tint     = JarvisColors.TextDisabled,
                        modifier = Modifier.size(48.dp)
                    )
                    Text(
                        if (searchQuery.isNotBlank()) "No results for \"$searchQuery\""
                        else "No memories stored yet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = JarvisColors.TextMuted
                    )
                }
            }
        } else {
            LazyColumn(
                contentPadding      = PaddingValues(JarvisSpacing.md),
                verticalArrangement = Arrangement.spacedBy(JarvisSpacing.sm),
                modifier            = Modifier.fillMaxSize()
            ) {
                // Show relevance score when in search mode
                if (searchQuery.isNotBlank() && uiState.searchResults.isNotEmpty()) {
                    items(uiState.searchResults, key = { it.first.id }) { (memory, score) ->
                        MemoryCard(
                            memory        = memory,
                            relevanceScore = score,
                            onDelete      = { viewModel.deleteMemory(memory.id) }
                        )
                    }
                } else {
                    items(displayList, key = { it.id }) { memory ->
                        MemoryCard(
                            memory   = memory,
                            onDelete = { viewModel.deleteMemory(memory.id) }
                        )
                    }
                }
                item { Spacer(Modifier.height(JarvisSpacing.xxl)) }
            }
        }
    }

    // ── Add Memory Dialog ─────────────────────────────────────────────────────
    if (showAddDialog) {
        AddMemoryDialog(
            onDismiss = { showAddDialog = false },
            onSave    = { content, type ->
                viewModel.saveMemory(content, type)
                showAddDialog = false
            }
        )
    }
}

// ── Memory Card ───────────────────────────────────────────────────────────────

@Composable
private fun MemoryCard(
    memory: Memory,
    relevanceScore: Float = 0f,
    onDelete: () -> Unit
) {
    val typeColor = memoryTypeColor(memory.type)
    val fmt       = remember { SimpleDateFormat("MMM d, yyyy", Locale.ENGLISH) }

    var expanded by remember { mutableStateOf(false) }

    HudCard(
        modifier   = Modifier.fillMaxWidth(),
        glowColor  = typeColor,
        glowAlpha  = 0.2f
    ) {
        Column(
            modifier = Modifier
                .clickable { expanded = !expanded }
                .padding(JarvisSpacing.md),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier              = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment     = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment     = Alignment.CenterVertically
                    ) {
                        JarvisChip(
                            text  = memory.type.name,
                            color = typeColor
                        )
                        if (relevanceScore > 0f) {
                            Text(
                                "${"%.0f".format(relevanceScore * 100)}% match",
                                style = MaterialTheme.typography.labelSmall,
                                color = JarvisColors.GoldAlert
                            )
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text     = memory.content,
                        style    = MaterialTheme.typography.bodyMedium,
                        color    = JarvisColors.TextPrimary,
                        maxLines = if (expanded) Int.MAX_VALUE else 2
                    )
                }
                IconButton(
                    onClick  = onDelete,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        Icons.Default.Close, null,
                        tint     = JarvisColors.TextMuted,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            if (expanded) {
                HudDivider()
                Row(
                    modifier              = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        "Importance: ${"%.0f".format(memory.importance * 100)}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = JarvisColors.TextMuted
                    )
                    Text(
                        fmt.format(Date(memory.timestamp)),
                        style = MaterialTheme.typography.labelSmall,
                        color = JarvisColors.TextMuted
                    )
                }
            }
        }
    }
}

// ── Add Memory Dialog ─────────────────────────────────────────────────────────

@Composable
private fun AddMemoryDialog(
    onDismiss: () -> Unit,
    onSave: (String, MemoryType) -> Unit
) {
    var content     by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf(MemoryType.GENERAL) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor   = JarvisColors.CardNavy,
        titleContentColor = JarvisColors.TextPrimary,
        textContentColor  = JarvisColors.TextSecondary,
        title = {
            Text(
                "SAVE MEMORY",
                style         = MaterialTheme.typography.titleLarge,
                color         = JarvisColors.CyanCore,
                letterSpacing = 3.sp
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(JarvisSpacing.sm)) {
                OutlinedTextField(
                    value         = content,
                    onValueChange = { content = it },
                    modifier      = Modifier.fillMaxWidth(),
                    placeholder   = { Text("What should JARVIS remember?", color = JarvisColors.TextDisabled) },
                    minLines      = 3,
                    maxLines      = 5,
                    colors        = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor    = JarvisColors.CyanCore.copy(0.6f),
                        unfocusedBorderColor  = JarvisColors.BorderNavy,
                        cursorColor           = JarvisColors.CyanCore,
                        focusedContainerColor = JarvisColors.ElevatedNavy,
                        unfocusedContainerColor = JarvisColors.SurfaceNavy,
                        focusedTextColor      = JarvisColors.TextPrimary,
                        unfocusedTextColor    = JarvisColors.TextPrimary
                    ),
                    shape = RoundedCornerShape(4.dp)
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(MemoryType.values()) { type ->
                        JarvisChip(
                            text    = type.name,
                            color   = if (selectedType == type) memoryTypeColor(type)
                                      else JarvisColors.TextMuted,
                            onClick = { selectedType = type }
                        )
                    }
                }
            }
        },
        confirmButton = {
            JarvisButton(
                text    = "Save",
                onClick = { if (content.isNotBlank()) onSave(content, selectedType) },
                enabled = content.isNotBlank()
            )
        },
        dismissButton = {
            JarvisButton(text = "Cancel", onClick = onDismiss, color = JarvisColors.TextMuted)
        }
    )
}

// ── Memory Type Color ─────────────────────────────────────────────────────────

fun memoryTypeColor(type: MemoryType): Color = when (type) {
    MemoryType.FACT         -> JarvisColors.CyanCore
    MemoryType.PREFERENCE   -> JarvisColors.GoldAlert
    MemoryType.HABIT        -> JarvisColors.GreenOnline
    MemoryType.RELATIONSHIP -> Color(0xFFB47AFF)
    MemoryType.EVENT        -> Color(0xFFFF8C42)
    MemoryType.GENERAL      -> JarvisColors.TextSecondary
}
