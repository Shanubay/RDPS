package com.jarvis.assistant.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.core.utils.FileManager
import com.jarvis.assistant.domain.entities.AIModel
import com.jarvis.assistant.domain.entities.ModelStatus
import com.jarvis.assistant.domain.usecase.ModelManagerUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ModelManagerUiState(
    val models: List<AIModel> = emptyList(),
    val activeModelId: String? = null,
    val isLoadingModel: Boolean = false,
    val downloadingModelId: String? = null,
    val downloadProgress: Int = 0,
    val storageInfo: ModelManagerUseCase.StorageInfo? = null,
    val error: String? = null,
    val successMessage: String? = null
)

@HiltViewModel
class ModelManagerViewModel @Inject constructor(
    private val modelManagerUseCase: ModelManagerUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(ModelManagerUiState())
    val uiState: StateFlow<ModelManagerUiState> = _uiState.asStateFlow()

    init {
        loadModels()
        refreshStorageInfo()
    }

    private fun loadModels() {
        viewModelScope.launch {
            // Start with catalog
            val catalog = modelManagerUseCase.getCatalogModels()
            _uiState.update { it.copy(models = catalog) }

            // Observe live updates from Room
            modelManagerUseCase.getAllModels().collect { dbModels ->
                // Merge catalog with DB — DB takes precedence for status
                val merged = catalog.map { catalogModel ->
                    dbModels.find { it.id == catalogModel.id } ?: catalogModel
                }
                val active = modelManagerUseCase.getActiveModel()
                _uiState.update { it.copy(
                    models        = merged,
                    activeModelId = active?.id
                )}
            }
        }
    }

    fun downloadModel(model: AIModel) {
        if (_uiState.value.downloadingModelId != null) return

        viewModelScope.launch {
            _uiState.update { it.copy(downloadingModelId = model.id, downloadProgress = 0, error = null) }

            modelManagerUseCase.downloadModel(model).collect { event ->
                when (event) {
                    is ModelManagerUseCase.ModelEvent.DownloadProgress -> {
                        _uiState.update { it.copy(downloadProgress = event.percent) }
                        // Update model in list
                        updateModelInList(model.id) { m ->
                            m.copy(status = ModelStatus.DOWNLOADING, downloadProgress = event.percent)
                        }
                    }
                    is ModelManagerUseCase.ModelEvent.DownloadComplete -> {
                        _uiState.update { it.copy(
                            downloadingModelId = null,
                            downloadProgress   = 100,
                            successMessage     = "${model.name} downloaded successfully"
                        )}
                        updateModelInList(model.id) { m ->
                            m.copy(status = ModelStatus.READY, downloadProgress = 100, filePath = event.filePath)
                        }
                        refreshStorageInfo()
                    }
                    is ModelManagerUseCase.ModelEvent.DownloadError -> {
                        _uiState.update { it.copy(
                            downloadingModelId = null,
                            error = event.message
                        )}
                        updateModelInList(model.id) { m -> m.copy(status = ModelStatus.ERROR) }
                    }
                    else -> {}
                }
            }
        }
    }

    fun cancelDownload(modelId: String) {
        modelManagerUseCase.cancelDownload(modelId)
        _uiState.update { it.copy(downloadingModelId = null, downloadProgress = 0) }
        updateModelInList(modelId) { m -> m.copy(status = ModelStatus.NOT_DOWNLOADED, downloadProgress = 0) }
    }

    fun loadModel(model: AIModel) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingModel = true, error = null) }
            when (val result = modelManagerUseCase.loadModel(model.id)) {
                is ModelManagerUseCase.ModelEvent.LoadComplete -> {
                    modelManagerUseCase.setActiveModel(model.id)
                    _uiState.update { it.copy(
                        isLoadingModel = false,
                        activeModelId  = model.id,
                        successMessage = "${model.name} loaded and ready"
                    )}
                }
                is ModelManagerUseCase.ModelEvent.LoadError -> {
                    _uiState.update { it.copy(
                        isLoadingModel = false,
                        error          = result.message
                    )}
                }
                else -> _uiState.update { it.copy(isLoadingModel = false) }
            }
        }
    }

    fun deleteModel(model: AIModel) {
        viewModelScope.launch {
            modelManagerUseCase.deleteModel(model.id)
            updateModelInList(model.id) { m ->
                m.copy(status = ModelStatus.NOT_DOWNLOADED, downloadProgress = 0, filePath = "")
            }
            if (_uiState.value.activeModelId == model.id) {
                _uiState.update { it.copy(activeModelId = null) }
            }
            refreshStorageInfo()
        }
    }

    fun unloadModel() {
        viewModelScope.launch {
            modelManagerUseCase.unloadModel()
            _uiState.update { it.copy(activeModelId = null) }
        }
    }

    private fun refreshStorageInfo() {
        _uiState.update { it.copy(storageInfo = modelManagerUseCase.getStorageInfo()) }
    }

    private fun updateModelInList(modelId: String, update: (AIModel) -> AIModel) {
        _uiState.update { state ->
            state.copy(models = state.models.map { if (it.id == modelId) update(it) else it })
        }
    }

    fun clearError()   = _uiState.update { it.copy(error = null) }
    fun clearSuccess() = _uiState.update { it.copy(successMessage = null) }
}
