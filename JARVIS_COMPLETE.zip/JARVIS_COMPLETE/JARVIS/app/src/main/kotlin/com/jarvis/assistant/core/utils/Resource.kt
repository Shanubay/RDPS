package com.jarvis.assistant.core.utils

/**
 * Resource<T> — Unified result wrapper used across all layers.
 *
 * Replaces scattered null checks / exception handling with
 * a clean sealed class hierarchy.
 */
sealed class Resource<out T> {

    data class Success<T>(val data: T) : Resource<T>()
    data class Error(
        val message: String,
        val throwable: Throwable? = null,
        val code: Int? = null
    ) : Resource<Nothing>()
    data class Loading(val message: String = "") : Resource<Nothing>()

    val isSuccess: Boolean get() = this is Success
    val isError: Boolean   get() = this is Error
    val isLoading: Boolean get() = this is Loading

    fun getOrNull(): T? = if (this is Success) data else null
    fun getOrDefault(default: @UnsafeVariance T): T = if (this is Success) data else default
    fun errorMessage(): String? = if (this is Error) message else null

    fun <R> map(transform: (T) -> R): Resource<R> = when (this) {
        is Success -> Success(transform(data))
        is Error   -> this
        is Loading -> this
    }

    companion object {
        fun <T> success(data: T): Resource<T> = Success(data)
        fun error(message: String, t: Throwable? = null): Resource<Nothing> = Error(message, t)
        fun loading(message: String = ""): Resource<Nothing> = Loading(message)
    }
}

/**
 * Execute a suspending block and wrap the result in Resource<T>.
 * Catches all exceptions and maps them to Resource.Error.
 */
suspend fun <T> safeApiCall(
    errorMessage: String = "An unexpected error occurred",
    block: suspend () -> T
): Resource<T> = try {
    Resource.Success(block())
} catch (e: retrofit2.HttpException) {
    Resource.Error(
        message = e.response()?.errorBody()?.string() ?: "HTTP ${e.code()}",
        throwable = e,
        code = e.code()
    )
} catch (e: java.io.IOException) {
    Resource.Error("Network error: ${e.message}", e)
} catch (e: Exception) {
    Resource.Error("$errorMessage: ${e.message}", e)
}
