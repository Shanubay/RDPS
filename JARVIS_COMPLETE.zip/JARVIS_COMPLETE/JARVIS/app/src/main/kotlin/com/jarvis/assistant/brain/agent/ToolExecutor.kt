package com.jarvis.assistant.brain.agent

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import com.jarvis.assistant.core.utils.EmbeddingUtils
import com.jarvis.assistant.domain.entities.MemoryType
import com.jarvis.assistant.domain.usecase.ManageMemoryUseCase
import com.jarvis.assistant.service.accessibility.JarvisAccessibilityService
import com.jarvis.assistant.service.device.DeviceControlService
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * ToolExecutor — maps every AgentTool variant to a real Android action.
 *
 * Returns ToolResult with success flag + human-readable output for
 * injection back into the AI context ("Tool returned: flashlight turned on").
 */
@Singleton
class ToolExecutor @Inject constructor(
    @ApplicationContext private val context: Context,
    private val manageMemory: ManageMemoryUseCase
) {

    // Bound service reference — set by MainActivity
    var deviceService: DeviceControlService? = null

    suspend fun execute(tool: AgentTool): AgentTool.ToolResult {
        val start = System.currentTimeMillis()
        val (success, output) = runCatching { dispatch(tool) }
            .fold(
                onSuccess = { it },
                onFailure = { e -> Pair(false, "Error: ${e.message}") }
            )
        return AgentTool.ToolResult(
            tool       = tool,
            success    = success,
            output     = output,
            durationMs = System.currentTimeMillis() - start
        )
    }

    private suspend fun dispatch(tool: AgentTool): Pair<Boolean, String> = when (tool) {

        // ── Device ────────────────────────────────────────────────────────────

        is AgentTool.FlashlightTool -> {
            deviceService?.setFlashlight(tool.enable)
            Pair(true, "Flashlight ${if (tool.enable) "on" else "off"}.")
        }

        is AgentTool.VolumeTool -> {
            val am = context.getSystemService(android.media.AudioManager::class.java)
            when (tool.action) {
                AgentTool.VolumeTool.VolumeAction.UP   ->
                    am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC,
                        android.media.AudioManager.ADJUST_RAISE, 0)
                AgentTool.VolumeTool.VolumeAction.DOWN ->
                    am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC,
                        android.media.AudioManager.ADJUST_LOWER, 0)
                AgentTool.VolumeTool.VolumeAction.MUTE ->
                    am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC,
                        android.media.AudioManager.ADJUST_MUTE, 0)
                AgentTool.VolumeTool.VolumeAction.SET  ->
                    deviceService?.setVolume(tool.level)
            }
            Pair(true, "Volume ${tool.action.name.lowercase()}.")
        }

        is AgentTool.BluetoothTool -> {
            deviceService?.setBluetooth(tool.enable)
            Pair(true, "Bluetooth ${if (tool.enable) "enabled" else "disabled"}.")
        }

        is AgentTool.WifiSettingsTool -> {
            deviceService?.openWifiSettings()
            Pair(true, "WiFi settings opened.")
        }

        is AgentTool.BrightnessTool -> {
            deviceService?.setBrightness(tool.level)
            Pair(true, "Brightness set to ${tool.level}.")
        }

        is AgentTool.DoNotDisturbTool -> {
            deviceService?.setDoNotDisturb(tool.enable)
            Pair(true, "Do Not Disturb ${if (tool.enable) "enabled" else "disabled"}.")
        }

        // ── App Launch ────────────────────────────────────────────────────────

        is AgentTool.LaunchAppTool -> {
            val intent = context.packageManager
                .getLaunchIntentForPackage(tool.packageName)
            if (intent != null) {
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(intent)
                Pair(true, "${tool.appName} launched.")
            } else {
                Pair(false, "App ${tool.appName} not found.")
            }
        }

        is AgentTool.OpenUrlTool -> {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(tool.url)).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            Pair(true, "Opened ${tool.url}.")
        }

        // ── Communication ─────────────────────────────────────────────────────

        is AgentTool.SendSmsTool -> {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data  = Uri.parse("smsto:${tool.phoneNumber}")
                putExtra("sms_body", tool.message)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            Pair(true, "SMS to ${tool.contactName} ready to send.")
        }

        is AgentTool.CallContactTool -> {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data  = Uri.parse("tel:${tool.phoneNumber}")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            Pair(true, "Calling ${tool.contactName}.")
        }

        is AgentTool.SendWhatsAppTool -> {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data  = Uri.parse("https://wa.me/?text=${Uri.encode(tool.message)}")
                setPackage("com.whatsapp")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            runCatching { context.startActivity(intent) }
                .fold(
                    onSuccess = { Pair(true, "WhatsApp message prepared for ${tool.contactName}.") },
                    onFailure = { Pair(false, "WhatsApp not installed.") }
                )
        }

        // ── Navigation ────────────────────────────────────────────────────────

        is AgentTool.NavigateTool -> {
            val modeStr = when (tool.mode) {
                AgentTool.NavigateTool.NavigationMode.WALKING  -> "w"
                AgentTool.NavigateTool.NavigationMode.TRANSIT  -> "r"
                else                                           -> "d"
            }
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data  = Uri.parse(
                    "google.navigation:q=${Uri.encode(tool.destination)}&mode=$modeStr"
                )
                setPackage("com.google.android.apps.maps")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            runCatching { context.startActivity(intent) }
                .fold(
                    onSuccess = { Pair(true, "Navigating to ${tool.destination}.") },
                    onFailure = {
                        // Fallback: open in browser
                        val fallback = Intent(Intent.ACTION_VIEW,
                            Uri.parse("https://maps.google.com/maps?q=${Uri.encode(tool.destination)}")
                        ).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
                        context.startActivity(fallback)
                        Pair(true, "Opened maps for ${tool.destination}.")
                    }
                )
        }

        // ── Search ────────────────────────────────────────────────────────────

        is AgentTool.WebSearchTool -> {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data  = Uri.parse("https://www.google.com/search?q=${Uri.encode(tool.query)}")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            Pair(true, "Searching for: ${tool.query}.")
        }

        is AgentTool.YouTubeSearchTool -> {
            val intent = Intent(Intent.ACTION_SEARCH).apply {
                setPackage("com.google.android.youtube")
                putExtra("query", tool.query)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            runCatching { context.startActivity(intent) }
                .fold(
                    onSuccess = { Pair(true, "Searching YouTube for: ${tool.query}.") },
                    onFailure = {
                        val fallback = Intent(Intent.ACTION_VIEW,
                            Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(tool.query)}")
                        ).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
                        context.startActivity(fallback)
                        Pair(true, "YouTube search opened in browser.")
                    }
                )
        }

        // ── Alarms / Timers ───────────────────────────────────────────────────

        is AgentTool.SetAlarmTool -> {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR,    tool.hour)
                putExtra(AlarmClock.EXTRA_MINUTES, tool.minute)
                putExtra(AlarmClock.EXTRA_MESSAGE, tool.label)
                putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            val timeStr = "%02d:%02d".format(tool.hour, tool.minute)
            Pair(true, "Alarm set for $timeStr.")
        }

        is AgentTool.SetTimerTool -> {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH,  tool.durationSeconds)
                putExtra(AlarmClock.EXTRA_MESSAGE, tool.label)
                putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            val min = tool.durationSeconds / 60
            val sec = tool.durationSeconds % 60
            val str = if (min > 0) "${min}m ${sec}s" else "${sec}s"
            Pair(true, "Timer set for $str.")
        }

        // ── Screen ────────────────────────────────────────────────────────────

        is AgentTool.TakeScreenshotTool -> {
            Pair(false, "Screenshot requires MediaProjection — initiate from UI.")
        }

        is AgentTool.ReadScreenTool -> {
            val text = JarvisAccessibilityService.instance?.extractScreenText()
                ?: "Accessibility service not enabled."
            Pair(text.isNotBlank(), text.take(500))
        }

        // ── Memory ────────────────────────────────────────────────────────────

        is AgentTool.SaveMemoryTool -> {
            val memType = runCatching { MemoryType.valueOf(tool.type) }
                .getOrDefault(MemoryType.GENERAL)
            manageMemory.saveManualMemory(tool.content, memType)
            Pair(true, "Remembered: ${tool.content}")
        }

        is AgentTool.RecallMemoryTool -> {
            val results = manageMemory.semanticSearch(tool.query, topK = 3)
            if (results.isEmpty()) {
                Pair(true, "No memories found for: ${tool.query}")
            } else {
                val summary = results.joinToString("\n") { (mem, score) ->
                    "• ${mem.content} (relevance: ${"%.0f".format(score * 100)}%)"
                }
                Pair(true, summary)
            }
        }

        // ── Sub-agent (handled upstream by JarvisBrain) ───────────────────────

        is AgentTool.AiSubtaskTool ->
            Pair(false, "Sub-agent dispatch is handled by JarvisBrain — not ToolExecutor.")
    }
}
