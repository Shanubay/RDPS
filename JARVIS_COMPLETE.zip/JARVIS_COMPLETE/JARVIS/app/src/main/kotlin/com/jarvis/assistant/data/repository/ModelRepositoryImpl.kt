package com.jarvis.assistant.data.repository

import com.jarvis.assistant.core.constants.AppConstants
import com.jarvis.assistant.core.constants.ModelInfo
import com.jarvis.assistant.core.llm.LlamaEngine
import com.jarvis.assistant.core.utils.AppPreferences
import com.jarvis.assistant.core.utils.FileManager
import com.jarvis.assistant.data.local.JarvisDatabase
import com.jarvis.assistant.data.local.toDomain
import com.jarvis.assistant.data.local.toEntity
import com.jarvis.assistant.data.local.entities.LocalModelEntity
import com.jarvis.assistant.domain.entities.AIModel
import com.jarvis.assistant.domain.entities.ModelProvider
import com.jarvis.assistant.domain.entities.ModelStatus
import com.jarvis.assistant.domain.repository.ModelRepository
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ModelRepositoryImpl @Inject constructor(
    private val db: JarvisDatabase,
    private val fileManager: FileManager,
    private val llamaEngine: LlamaEngine,
    private val prefs: AppPreferences
) : ModelRepository {

    private val dao get() = db.modelDao()

    // ── Seed catalog on first call ────────────────────────────────────────────

    private var catalogSeeded = false

    private suspend fun ensureCatalogSeeded() {
        if (catalogSeeded) return
        catalogSeeded = true
        val existing = dao.getAllModelsOnce().map { it.id }.toSet()
        AppConstants.ModelCatalog.ALL.forEach { info ->
            if (info.id !in existing) {
                dao.insertModel(
                    LocalModelEntity(
                        id          = info.id,
                        name        = info.name,
                        description = info.description,
                        downloadUrl = info.url,
                        sizeBytes   = info.sizeBytes,
                        ramRequired = info.ramRequired,
                        status      = if (fileManager.isModelDownloaded(info.id))
                            ModelStatus.READY.name else ModelStatus.NOT_DOWNLOADED.name,
                        filePath    = if (fileManager.isModelDownloaded(info.id))
                            fileManager.getModelFilePath(info.id) else ""
                    )
                )
            } else if (fileManager.isModelDownloaded(info.id)) {
                // Update status if file exists but DB says not downloaded
                val entity = dao.getModelById(info.id)
                if (entity?.status == ModelStatus.NOT_DOWNLOADED.name) {
                    dao.markDownloadComplete(info.id, fileManager.getModelFilePath(info.id))
                }
            }
        }
    }

    override fun getAllModels(): Flow<List<AIModel>> = flow {
        ensureCatalogSeeded()
        emitAll(
            dao.getAllModels().map { list -> list.map { it.toDomain() } }
        )
    }

    override suspend fun getActiveModel(): AIModel? {
        ensureCatalogSeeded()
        return dao.getActiveModel()?.toDomain()
    }

    override suspend fun setActiveModel(modelId: String) {
        dao.clearActiveModel()
        dao.setActiveModel(modelId)
        val model = dao.getModelById(modelId)
        if (model != null) {
            prefs.setActiveModel(model.filePath, model.name)
        }
    }

    // ── Download ──────────────────────────────────────────────────────────────

    override fun downloadModel(model: AIModel): Flow<AIModel> = flow {
        dao.updateDownloadProgress(model.id, ModelStatus.DOWNLOADING.name, 0)
        emit(model.copy(status = ModelStatus.DOWNLOADING, downloadProgress = 0))

        val modelInfo = ModelInfo(
            id          = model.id,
            name        = model.name,
            description = model.description,
            url         = model.downloadUrl,
            sizeBytes   = model.sizeBytes,
            ramRequired = model.ramRequired
        )

        fileManager.downloadModel(modelInfo).collect { state ->
            when (state) {
                is FileManager.DownloadState.Progress -> {
                    dao.updateDownloadProgress(model.id, ModelStatus.DOWNLOADING.name, state.percent)
                    emit(model.copy(status = ModelStatus.DOWNLOADING, downloadProgress = state.percent))
                }
                is FileManager.DownloadState.Success -> {
                    dao.markDownloadComplete(model.id, state.filePath)
                    emit(model.copy(
                        status           = ModelStatus.READY,
                        downloadProgress = 100,
                        filePath         = state.filePath
                    ))
                }
                is FileManager.DownloadState.Error -> {
                    dao.markError(model.id)
                    emit(model.copy(status = ModelStatus.ERROR))
                }
                is FileManager.DownloadState.Cancelled -> {
                    dao.updateDownloadProgress(model.id, ModelStatus.NOT_DOWNLOADED.name, 0)
                    emit(model.copy(status = ModelStatus.NOT_DOWNLOADED, downloadProgress = 0))
                }
            }
        }
    }

    // ── Load / Unload ─────────────────────────────────────────────────────────

    override suspend fun loadModel(modelId: String): Boolean {
        val entity = dao.getModelById(modelId) ?: return false
        if (entity.filePath.isBlank()) return false

        return llamaEngine.loadModel(
            modelPath  = entity.filePath,
            contextSize = entity.contextLength,
            threads    = 4
        )
    }

    override suspend fun unloadModel() = llamaEngine.unloadModel()

    override fun isModelLoaded(): Boolean = llamaEngine.isModelLoaded()

    // ── Local inference ───────────────────────────────────────────────────────

    override fun generateLocal(
        prompt: String,
        maxTokens: Int,
        temperature: Float
    ): Flow<String> = llamaEngine.streamGenerate(prompt, maxTokens, temperature)

    // ── Delete ────────────────────────────────────────────────────────────────

    override suspend fun deleteModel(modelId: String): Boolean {
        val deleted = fileManager.deleteModel(modelId)
        if (deleted) {
            dao.updateDownloadProgress(modelId, ModelStatus.NOT_DOWNLOADED.name, 0)
            dao.getModelById(modelId)?.let { entity ->
                dao.updateModel(entity.copy(filePath = "", status = ModelStatus.NOT_DOWNLOADED.name))
            }
        }
        return deleted
    }
}
