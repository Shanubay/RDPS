package com.jarvis.assistant.core.di

import com.jarvis.assistant.domain.repository.DeviceRepository
import com.jarvis.assistant.data.repository.DeviceRepositoryImpl
import com.jarvis.assistant.data.repository.SettingsRepositoryImpl
import com.jarvis.assistant.domain.repository.SettingsRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * ServiceModule — binds remaining repository implementations.
 * Device and overlay services use @AndroidEntryPoint for self-injection.
 */
@Module
@InstallIn(SingletonComponent::class)
abstract class ServiceModule {

    @Binds @Singleton
    abstract fun bindSettingsRepository(impl: SettingsRepositoryImpl): SettingsRepository
}
