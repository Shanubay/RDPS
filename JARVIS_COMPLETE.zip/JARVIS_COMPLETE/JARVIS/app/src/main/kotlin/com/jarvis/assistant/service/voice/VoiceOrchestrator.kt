package com.jarvis.assistant.service.voice

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import com.jarvis.assistant.core.constants.AppConstants
import com.jarvis.assistant.core.utils.AppPreferences
import com.jarvis.assistant.core.utils.TimeUtils
import com.jarvis.assistant.domain.entities.VoiceState
import com.jarvis.assistant.domain.usecase.ProcessVoiceCommandUseCase
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

/**
 * VoiceOrchestrator — the central coordinator for the full voice pipeline.
 *
 * Manages the complete state machine:
 * IDLE → WAKE_WORD_LISTENING → LISTENING → PROCESSING → SPEAKING → IDLE
 *
 * Handles:
 * • Wake word broadcast from WakeWordService
 * • STT binding and result collection
 * • AI processing via ProcessVoiceCommandUseCase
 * • TTS output via TtsService
 * • Interruption (user speaks while JARVIS is speaking)
 */
@Singleton
class VoiceOrchestrator @Inject constructor(
    @ApplicationContext private val context: Context,
    private val processVoiceCommand: ProcessVoiceCommandUseCase,
    private val appPreferences: AppPreferences,
    private val timeUtils: TimeUtils
) {

    private val orchestratorScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val _voiceState   = MutableStateFlow(VoiceState.IDLE)
    private val _transcript   = MutableStateFlow("")
    private val _partialText  = MutableStateFlow("")
    private val _responseText = MutableStateFlow("")
    private val _amplitude    = MutableStateFlow(0f)
    private val _waveform     = MutableStateFlow(List(20) { 0f })
    private val _error        = MutableStateFlow<String?>(null)

    val voiceState:   StateFlow<VoiceState>    = _voiceState.asStateFlow()
    val transcript:   StateFlow<String>        = _transcript.asStateFlow()
    val partialText:  StateFlow<String>        = _partialText.asStateFlow()
    val responseText: StateFlow<String>        = _responseText.asStateFlow()
    val amplitude:    StateFlow<Float>         = _amplitude.asStateFlow()
    val waveform:     StateFlow<List<Float>>   = _waveform.asStateFlow()
    val error:        StateFlow<String?>       = _error.asStateFlow()

    // Active conversation tracking
    private var activeConversationId: String = ""
    private var processingJob: Job? = null

    // Bound service references (set from Activity/Service)
    var sttService: SpeechRecognitionService? = null
    var ttsService: TtsService?               = null

    // ── Wake Word Broadcast Receiver ──────────────────────────────────────────

    private val wakeWordReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action == AppConstants.Actions.WAKE_WORD_DETECTED) {
                onWakeWordDetected()
            }
        }
    }

    fun registerWakeWordReceiver() {
        val filter = IntentFilter(AppConstants.Actions.WAKE_WORD_DETECTED)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(wakeWordReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            context.registerReceiver(wakeWordReceiver, filter)
        }
    }

    fun unregisterWakeWordReceiver() {
        try { context.unregisterReceiver(wakeWordReceiver) } catch (e: Exception) { }
    }

    // ── State Machine ─────────────────────────────────────────────────────────

    private fun onWakeWordDetected() {
        if (_voiceState.value == VoiceState.SPEAKING) {
            // Interrupt JARVIS mid-speech
            ttsService?.stopSpeaking()
        }
        startListening()
    }

    fun startListening() {
        if (_voiceState.value == VoiceState.LISTENING) return

        _voiceState.value  = VoiceState.LISTENING
        _transcript.value  = ""
        _partialText.value = ""
        _error.value       = null

        val stt = sttService ?: run {
            _voiceState.value = VoiceState.ERROR
            _error.value      = "STT service not connected"
            return
        }

        // Observe STT state
        orchestratorScope.launch {
            stt.sttState.collect { state ->
                when (state) {
                    is SpeechRecognitionService.SttState.Listening ->
                        _voiceState.value = VoiceState.LISTENING

                    is SpeechRecognitionService.SttState.Partial ->
                        _partialText.value = state.text

                    is SpeechRecognitionService.SttState.Result -> {
                        _transcript.value  = state.text
                        _partialText.value = ""
                        processUserInput(state.text)
                    }

                    is SpeechRecognitionService.SttState.Error -> {
                        _voiceState.value = VoiceState.ERROR
                        _error.value      = state.message
                        scheduleReturnToIdle()
                    }

                    is SpeechRecognitionService.SttState.Idle -> { }
                }
            }
        }

        stt.startListening()
    }

    fun stopListening() {
        sttService?.stopListening()
        _voiceState.value = VoiceState.IDLE
    }

    // ── AI Processing ─────────────────────────────────────────────────────────

    private fun processUserInput(text: String) {
        if (text.isBlank()) {
            _voiceState.value = VoiceState.IDLE
            return
        }

        processingJob?.cancel()
        processingJob = orchestratorScope.launch {
            _voiceState.value   = VoiceState.PROCESSING
            _responseText.value = ""

            val streamedResponse = StringBuilder()

            processVoiceCommand(text, activeConversationId).collect { result ->
                when (result) {
                    is ProcessVoiceCommandUseCase.VoiceResult.Processing -> {
                        _voiceState.value = VoiceState.PROCESSING
                    }
                    is ProcessVoiceCommandUseCase.VoiceResult.StreamToken -> {
                        streamedResponse.append(result.token)
                        _responseText.value = streamedResponse.toString()
                    }
                    is ProcessVoiceCommandUseCase.VoiceResult.AiResponse -> {
                        _responseText.value = result.text
                        speakResponse(result.text)
                    }
                    is ProcessVoiceCommandUseCase.VoiceResult.DeviceAction -> {
                        _responseText.value = result.description
                        speakResponse(result.description)
                    }
                    is ProcessVoiceCommandUseCase.VoiceResult.Error -> {
                        _error.value      = result.message
                        _voiceState.value = VoiceState.ERROR
                        scheduleReturnToIdle()
                    }
                }
            }

            // If we got tokens but no final AiResponse event, speak what we have
            if (streamedResponse.isNotEmpty() &&
                _voiceState.value == VoiceState.PROCESSING) {
                speakResponse(streamedResponse.toString())
            }
        }
    }

    // ── TTS Output ────────────────────────────────────────────────────────────

    private fun speakResponse(text: String) {
        if (text.isBlank()) {
            _voiceState.value = VoiceState.IDLE
            return
        }

        _voiceState.value = VoiceState.SPEAKING

        ttsService?.speak(text, TtsService.SpeechStyle.NATURAL) {
            _voiceState.value = VoiceState.WAKE_WORD_LISTENING
        } ?: run {
            // No TTS service — just update state
            _voiceState.value = VoiceState.WAKE_WORD_LISTENING
        }
    }

    fun stopSpeaking() {
        ttsService?.stopSpeaking()
        _voiceState.value = VoiceState.IDLE
    }

    // ── Manual Text Input ─────────────────────────────────────────────────────

    fun processTextInput(text: String) {
        _transcript.value = text
        processUserInput(text)
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun scheduleReturnToIdle(delayMs: Long = 3000L) {
        orchestratorScope.launch {
            delay(delayMs)
            if (_voiceState.value == VoiceState.ERROR) {
                _voiceState.value = VoiceState.IDLE
                _error.value      = null
            }
        }
    }

    fun setConversationId(id: String) { activeConversationId = id }

    fun updateAmplitude(amplitude: Float) {
        _amplitude.value = amplitude
        // Update waveform ring buffer
        val current = _waveform.value.toMutableList()
        current.removeAt(0)
        current.add(amplitude)
        _waveform.value = current
    }

    fun getGreeting(): String = timeUtils.greetingWithPersonality

    fun destroy() {
        orchestratorScope.cancel()
        unregisterWakeWordReceiver()
    }
}
