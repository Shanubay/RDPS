package com.jarvis.assistant.domain.usecase

import com.jarvis.assistant.core.constants.AppConstants
import com.jarvis.assistant.core.utils.*
import com.jarvis.assistant.domain.entities.*
import com.jarvis.assistant.domain.repository.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject

/**
 * SendMessageUseCase — orchestrates the complete message → AI response pipeline.
 *
 * Flow:
 * 1. Save user message to Room
 * 2. Retrieve context memories
 * 3. Build system prompt with memories injected
 * 4. Route to correct AI provider
 * 5. Stream tokens back to UI
 * 6. Save AI response to Room
 * 7. Extract new memories from conversation
 */
class SendMessageUseCase @Inject constructor(
    private val chatRepository: ChatRepository,
    private val memoryRepository: MemoryRepository,
    private val aiRepository: AIRepository,
    private val commandClassifier: CommandClassifier,
    private val networkUtils: NetworkUtils,
    private val batteryUtils: BatteryUtils,
    private val deviceInfoUtils: DeviceInfoUtils,
    private val appPreferences: AppPreferences
) {

    sealed class StreamResult {
        data class Token(val text: String) : StreamResult()
        data class Complete(val fullText: String, val provider: String) : StreamResult()
        data class Error(val message: String) : StreamResult()
        object Loading : StreamResult()
    }

    operator fun invoke(
        userText: String,
        conversationId: String
    ): Flow<StreamResult> = flow {

        emit(StreamResult.Loading)

        // ── 1. Classify command ───────────────────────────────────────────────
        val classified = commandClassifier.classify(userText)

        // ── 2. Save user message ──────────────────────────────────────────────
        val userMessage = Message(
            role      = MessageRole.USER,
            content   = userText,
            isVoice   = false
        )
        chatRepository.insertMessage(userMessage.copy(
            // Add conversationId if we had it in the entity — for now we track externally
        ))

        // ── 3. Get recent conversation context ────────────────────────────────
        val recentMessages = chatRepository.getRecentMessages(
            AppConstants.MAX_CONTEXT_MESSAGES
        ).first()

        // ── 4. Get relevant memories ──────────────────────────────────────────
        val contextMemories = memoryRepository.getContextMemories(5)

        // ── 5. Build system prompt ────────────────────────────────────────────
        val userName = appPreferences.userName.first()
        val systemPrompt = buildSystemPrompt(userName, contextMemories)

        // ── 6. Select AI provider ─────────────────────────────────────────────
        val provider = selectProvider(classified)

        // ── 7. Stream AI response ─────────────────────────────────────────────
        val fullResponseBuilder = StringBuilder()
        val startTime = System.currentTimeMillis()

        aiRepository.stream(
            messages     = recentMessages.takeLast(AppConstants.MAX_CONTEXT_MESSAGES),
            systemPrompt = systemPrompt,
            provider     = provider,
            maxTokens    = when (classified.estimatedComplexity) {
                CommandClassifier.Complexity.HIGH   -> 2048
                CommandClassifier.Complexity.MEDIUM -> 1024
                CommandClassifier.Complexity.LOW    -> 512
            }
        ).collect { token ->
            fullResponseBuilder.append(token)
            emit(StreamResult.Token(token))
        }

        val fullResponse = fullResponseBuilder.toString()
        val duration     = System.currentTimeMillis() - startTime

        // ── 8. Save AI response ───────────────────────────────────────────────
        val aiMessage = Message(
            role       = MessageRole.ASSISTANT,
            content    = fullResponse,
            provider   = provider,
            tokenCount = fullResponse.estimateTokenCount(),
            durationMs = duration,
            status     = MessageStatus.SENT
        )
        chatRepository.insertMessage(aiMessage)

        emit(StreamResult.Complete(fullResponse, provider))

    }.catch { e ->
        emit(StreamResult.Error(e.message ?: "Unknown error"))
    }

    // ── System Prompt Builder ─────────────────────────────────────────────────

    private fun buildSystemPrompt(
        userName: String,
        memories: List<Memory>
    ): String {
        val memoryBlock = if (memories.isNotEmpty()) {
            "\n\n[MEMORY CONTEXT — Things you know about the user]\n" +
            memories.joinToString("\n") { "• ${it.content}" }
        } else ""

        return """
You are JARVIS, an advanced AI assistant modeled after Iron Man's JARVIS.
You are intelligent, witty, efficient, calm under pressure, and deeply loyal.
You speak like a trusted human assistant — never robotic, never verbose without reason.
You address the user as "$userName" occasionally, but not every message.
You are concise unless depth is required.
You have a dry wit and subtle confidence.
When performing device actions, confirm them briefly.
When uncertain, you say so honestly rather than fabricate.
Current time: ${java.text.SimpleDateFormat("HH:mm, EEEE, MMMM d yyyy", java.util.Locale.ENGLISH).format(java.util.Date())}
$memoryBlock
        """.trimIndent()
    }

    // ── Provider Selection (Smart Router) ────────────────────────────────────

    private suspend fun selectProvider(classified: CommandClassifier.ClassifiedCommand): String {
        val offlineMode = appPreferences.offlineMode.first()
        val hasInternet = networkUtils.isConnected
        val batteryMode = batteryUtils.powerMode
        val userProvider = appPreferences.aiProvider.first()

        // Offline forced or no internet
        if (offlineMode || !hasInternet) {
            return AppConstants.AIProvider.LOCAL_LLAMA
        }

        // User explicitly chose a provider
        if (userProvider != AppConstants.AIProvider.LOCAL_LLAMA) {
            return when {
                // Fast small queries → Groq
                classified.estimatedComplexity == CommandClassifier.Complexity.LOW ->
                    AppConstants.AIProvider.GROQ

                // Complex queries → OpenAI
                classified.estimatedComplexity == CommandClassifier.Complexity.HIGH ->
                    AppConstants.AIProvider.OPENAI

                // Battery saving → Gemini (generally cheaper/faster)
                batteryMode == BatteryUtils.PowerMode.LOW ->
                    AppConstants.AIProvider.GEMINI

                else -> userProvider
            }
        }

        return AppConstants.AIProvider.LOCAL_LLAMA
    }
}
