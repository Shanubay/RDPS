package com.jarvis.assistant.data.repository

import com.jarvis.assistant.core.utils.AppPreferences
import com.jarvis.assistant.core.utils.EncryptionManager
import com.jarvis.assistant.domain.entities.SettingsState
import com.jarvis.assistant.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SettingsRepositoryImpl @Inject constructor(
    private val prefs: AppPreferences,
    private val encryption: EncryptionManager
) : SettingsRepository {

    override fun getSettings(): Flow<SettingsState> = combine(
        prefs.aiProvider,
        prefs.openAiKey,
        prefs.geminiKey,
        prefs.groqKey,
        prefs.elevenLabsKey,
        prefs.ttsProvider,
        prefs.voiceEnabled,
        prefs.overlayEnabled,
        prefs.offlineMode,
        prefs.activeModelName,
        prefs.userName
    ) { values ->
        SettingsState(
            aiProvider      = values[0] as String,
            openAiKey       = encryption.decryptApiKey(values[1] as String),
            geminiKey       = encryption.decryptApiKey(values[2] as String),
            groqKey         = encryption.decryptApiKey(values[3] as String),
            elevenLabsKey   = encryption.decryptApiKey(values[4] as String),
            ttsProvider     = values[5] as String,
            voiceEnabled    = values[6] as Boolean,
            overlayEnabled  = values[7] as Boolean,
            offlineMode     = values[8] as Boolean,
            activeModelName = values[9] as String?,
            userName        = values[10] as String
        )
    }

    override suspend fun updateSettings(settings: SettingsState) {
        prefs.setAiProvider(settings.aiProvider)
        prefs.setTtsProvider(settings.ttsProvider)
        prefs.setVoiceEnabled(settings.voiceEnabled)
        prefs.setOverlayEnabled(settings.overlayEnabled)
        prefs.setOfflineMode(settings.offlineMode)
        prefs.setUserName(settings.userName)
    }

    override suspend fun getApiKey(provider: String): String {
        val encrypted = when (provider) {
            "openai"      -> prefs.openAiKey.first()
            "gemini"      -> prefs.geminiKey.first()
            "groq"        -> prefs.groqKey.first()
            "elevenlabs"  -> prefs.elevenLabsKey.first()
            else          -> ""
        }
        return encryption.decryptApiKey(encrypted)
    }

    override suspend fun saveApiKey(provider: String, key: String) {
        val encrypted = encryption.encryptApiKey(key)
        when (provider) {
            "openai"     -> prefs.setOpenAiKey(encrypted)
            "gemini"     -> prefs.setGeminiKey(encrypted)
            "groq"       -> prefs.setGroqKey(encrypted)
            "elevenlabs" -> prefs.setElevenLabsKey(encrypted)
        }
    }
}
