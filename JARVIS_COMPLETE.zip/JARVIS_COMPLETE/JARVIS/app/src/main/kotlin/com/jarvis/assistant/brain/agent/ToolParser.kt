package com.jarvis.assistant.brain.agent

import com.google.gson.Gson
import com.google.gson.JsonObject
import javax.inject.Inject
import javax.inject.Singleton

/**
 * ToolParser — converts AI-generated JSON tool calls into typed AgentTool instances.
 *
 * The AI is prompted to emit JSON in this format when it wants to use a tool:
 *
 * <tool>
 * {
 *   "tool": "flashlight",
 *   "parameters": { "enable": true }
 * }
 * </tool>
 *
 * This parser extracts those blocks from the AI's response stream.
 */
@Singleton
class ToolParser @Inject constructor(private val gson: Gson) {

    data class ParsedToolCall(
        val tool: AgentTool?,
        val remainingText: String,       // text around the tool tag
        val rawJson: String
    )

    // ── Extract tool blocks from AI response ──────────────────────────────────

    fun extractToolCalls(text: String): List<ParsedToolCall> {
        val results   = mutableListOf<ParsedToolCall>()
        val pattern   = Regex("<tool>([\\s\\S]*?)</tool>", RegexOption.MULTILINE)
        var lastEnd   = 0

        pattern.findAll(text).forEach { match ->
            val rawJson = match.groupValues[1].trim()
            val tool    = parseToolJson(rawJson)
            results.add(ParsedToolCall(
                tool          = tool,
                remainingText = text.substring(lastEnd, match.range.first).trim(),
                rawJson       = rawJson
            ))
            lastEnd = match.range.last + 1
        }
        return results
    }

    fun stripToolTags(text: String): String =
        text.replace(Regex("<tool>[\\s\\S]*?</tool>"), "").trim()

    fun hasToolCall(text: String): Boolean =
        text.contains("<tool>") && text.contains("</tool>")

    // ── JSON → AgentTool ──────────────────────────────────────────────────────

    fun parseToolJson(json: String): AgentTool? = try {
        val obj    = gson.fromJson(json, JsonObject::class.java)
        val name   = obj.get("tool")?.asString ?: return null
        val params = obj.getAsJsonObject("parameters") ?: JsonObject()

        when (name) {
            "flashlight"    -> AgentTool.FlashlightTool(
                enable = params.get("enable")?.asBoolean ?: true
            )
            "volume"        -> {
                val action = params.get("action")?.asString ?: "UP"
                val level  = params.get("level")?.asInt ?: -1
                AgentTool.VolumeTool(
                    action = AgentTool.VolumeTool.VolumeAction.valueOf(action.uppercase()),
                    level  = level
                )
            }
            "bluetooth"     -> AgentTool.BluetoothTool(
                enable = params.get("enable")?.asBoolean ?: true
            )
            "wifi_settings" -> AgentTool.WifiSettingsTool
            "brightness"    -> AgentTool.BrightnessTool(
                level = params.get("level")?.asInt ?: 128
            )
            "dnd"           -> AgentTool.DoNotDisturbTool(
                enable = params.get("enable")?.asBoolean ?: true
            )
            "launch_app"    -> AgentTool.LaunchAppTool(
                packageName = params.get("packageName")?.asString ?: "",
                appName     = params.get("appName")?.asString ?: ""
            )
            "open_url"      -> AgentTool.OpenUrlTool(
                url = params.get("url")?.asString ?: ""
            )
            "send_sms"      -> AgentTool.SendSmsTool(
                contactName = params.get("contactName")?.asString ?: "",
                phoneNumber = params.get("phoneNumber")?.asString ?: "",
                message     = params.get("message")?.asString ?: ""
            )
            "call_contact"  -> AgentTool.CallContactTool(
                contactName = params.get("contactName")?.asString ?: "",
                phoneNumber = params.get("phoneNumber")?.asString ?: ""
            )
            "send_whatsapp" -> AgentTool.SendWhatsAppTool(
                contactName = params.get("contactName")?.asString ?: "",
                message     = params.get("message")?.asString ?: ""
            )
            "navigate"      -> AgentTool.NavigateTool(
                destination = params.get("destination")?.asString ?: "",
                mode        = try {
                    AgentTool.NavigateTool.NavigationMode.valueOf(
                        params.get("mode")?.asString?.uppercase() ?: "DRIVING"
                    )
                } catch (e: Exception) { AgentTool.NavigateTool.NavigationMode.DRIVING }
            )
            "web_search"    -> AgentTool.WebSearchTool(
                query = params.get("query")?.asString ?: ""
            )
            "youtube_search"-> AgentTool.YouTubeSearchTool(
                query = params.get("query")?.asString ?: ""
            )
            "set_alarm"     -> AgentTool.SetAlarmTool(
                hour   = params.get("hour")?.asInt   ?: 8,
                minute = params.get("minute")?.asInt ?: 0,
                label  = params.get("label")?.asString ?: "JARVIS Alarm"
            )
            "set_timer"     -> AgentTool.SetTimerTool(
                durationSeconds = params.get("durationSeconds")?.asInt ?: 60,
                label           = params.get("label")?.asString ?: "JARVIS Timer"
            )
            "take_screenshot"-> AgentTool.TakeScreenshotTool
            "read_screen"    -> AgentTool.ReadScreenTool
            "save_memory"   -> AgentTool.SaveMemoryTool(
                content = params.get("content")?.asString ?: "",
                type    = params.get("type")?.asString ?: "GENERAL"
            )
            "recall_memory" -> AgentTool.RecallMemoryTool(
                query = params.get("query")?.asString ?: ""
            )
            "ai_subtask"    -> AgentTool.AiSubtaskTool(
                subtask = params.get("subtask")?.asString ?: "",
                context = params.get("context")?.asString ?: ""
            )
            else            -> null
        }
    } catch (e: Exception) {
        android.util.Log.e("ToolParser", "Parse failed: ${e.message} for json: $json")
        null
    }

    // ── Build tool manifest for system prompt ─────────────────────────────────

    fun buildToolManifest(): String {
        val tools = listOf(
            "flashlight"     to "Turn flashlight on/off. Params: {enable: bool}",
            "volume"         to "Control volume. Params: {action: UP|DOWN|MUTE|SET, level: 0-15}",
            "bluetooth"      to "Toggle bluetooth. Params: {enable: bool}",
            "wifi_settings"  to "Open WiFi settings. No params.",
            "brightness"     to "Set brightness. Params: {level: 0-255}",
            "dnd"            to "Toggle Do Not Disturb. Params: {enable: bool}",
            "launch_app"     to "Launch app. Params: {packageName: str, appName: str}",
            "open_url"       to "Open URL. Params: {url: str}",
            "send_sms"       to "Send SMS. Params: {contactName: str, phoneNumber: str, message: str}",
            "call_contact"   to "Call contact. Params: {contactName: str, phoneNumber: str}",
            "navigate"       to "Navigate to place. Params: {destination: str, mode: DRIVING|WALKING|TRANSIT}",
            "web_search"     to "Search web. Params: {query: str}",
            "youtube_search" to "Search YouTube. Params: {query: str}",
            "set_alarm"      to "Set alarm. Params: {hour: int, minute: int, label: str}",
            "set_timer"      to "Set timer. Params: {durationSeconds: int, label: str}",
            "read_screen"    to "Read screen text. No params.",
            "save_memory"    to "Save to memory. Params: {content: str, type: FACT|PREFERENCE|HABIT|GENERAL}",
            "recall_memory"  to "Search memory. Params: {query: str}",
            "ai_subtask"     to "Delegate subtask. Params: {subtask: str, context: str}"
        )
        return tools.joinToString("\n") { (name, desc) -> "• $name: $desc" }
    }
}
