package com.jarvis.assistant.data.remote.api

import com.google.gson.Gson
import com.jarvis.assistant.data.remote.dto.OpenAiStreamChunk
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import okhttp3.ResponseBody
import java.io.BufferedReader
import java.io.InputStreamReader
import javax.inject.Inject
import javax.inject.Singleton

/**
 * SseParser — parses Server-Sent Events (SSE) streams from OpenAI-compatible APIs.
 *
 * The OpenAI streaming format sends:
 *   data: {"choices":[{"delta":{"content":"Hello"}}]}
 *   data: [DONE]
 *
 * We parse each "data:" line, extract the content delta, and emit as a Flow<String>.
 * Also handles Gemini streaming format differences.
 */
@Singleton
class SseParser @Inject constructor(
    private val gson: Gson
) {

    /**
     * Parse an OpenAI/Groq/OpenRouter SSE stream.
     * Emits each token string as it arrives.
     */
    fun parseOpenAiStream(body: ResponseBody): Flow<String> = flow {
        val reader = BufferedReader(InputStreamReader(body.byteStream()))
        try {
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                val trimmed = line!!.trim()

                // Skip empty lines and comments
                if (trimmed.isEmpty() || trimmed.startsWith(":")) continue

                // Strip "data: " prefix
                if (!trimmed.startsWith("data:")) continue
                val data = trimmed.removePrefix("data:").trim()

                // Done signal
                if (data == "[DONE]") break

                // Parse JSON chunk
                try {
                    val chunk = gson.fromJson(data, OpenAiStreamChunk::class.java)
                    val token = chunk.choices.firstOrNull()?.delta?.content
                    if (!token.isNullOrEmpty()) emit(token)
                } catch (e: Exception) {
                    // Malformed JSON chunk — skip
                    android.util.Log.d("SseParser", "Skipping malformed chunk: $data")
                }
            }
        } finally {
            reader.close()
            body.close()
        }
    }

    /**
     * Parse a Gemini SSE stream.
     * Gemini wraps JSON in data: lines with a slightly different structure.
     */
    fun parseGeminiStream(body: ResponseBody): Flow<String> = flow {
        val reader = BufferedReader(InputStreamReader(body.byteStream()))
        val jsonBuffer = StringBuilder()
        var inObject = false
        var braceDepth = 0

        try {
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                val trimmed = line!!.trim()
                if (trimmed.isEmpty()) continue

                val data = if (trimmed.startsWith("data:"))
                    trimmed.removePrefix("data:").trim()
                else trimmed

                if (data == "[DONE]") break

                // Accumulate JSON
                for (ch in data) {
                    when (ch) {
                        '{' -> { braceDepth++; inObject = true }
                        '}' -> braceDepth--
                    }
                    if (inObject) jsonBuffer.append(ch)

                    // Complete JSON object
                    if (inObject && braceDepth == 0) {
                        try {
                            val json = jsonBuffer.toString()
                            val response = gson.fromJson(json,
                                com.jarvis.assistant.data.remote.dto.GeminiResponse::class.java)
                            val text = response.candidates
                                .firstOrNull()?.content?.parts?.firstOrNull()?.text
                            if (!text.isNullOrEmpty()) emit(text)
                        } catch (e: Exception) {
                            android.util.Log.d("SseParser", "Gemini parse error: ${e.message}")
                        }
                        jsonBuffer.clear()
                        inObject = false
                        braceDepth = 0
                    }
                }
            }
        } finally {
            reader.close()
            body.close()
        }
    }

    /**
     * Parse a raw text stream (for non-SSE streaming responses).
     * Used as a fallback when SSE parsing fails.
     */
    fun parseRawStream(body: ResponseBody): Flow<String> = flow {
        val reader = BufferedReader(InputStreamReader(body.byteStream()))
        try {
            val buffer = CharArray(64)
            var charsRead: Int
            val sb = StringBuilder()
            while (reader.read(buffer).also { charsRead = it } != -1) {
                sb.append(buffer, 0, charsRead)
                if (sb.isNotEmpty()) {
                    emit(sb.toString())
                    sb.clear()
                }
            }
        } finally {
            reader.close()
            body.close()
        }
    }
}
