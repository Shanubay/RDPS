package com.jarvis.assistant.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.*
import com.jarvis.assistant.domain.entities.DeviceState
import com.jarvis.assistant.presentation.viewmodel.DeviceControlViewModel
import com.jarvis.assistant.ui.components.*
import com.jarvis.assistant.ui.theme.*

// ══════════════════════════════════════════════════════════════════════════════
// DeviceControlScreen — hardware controls dashboard
// ══════════════════════════════════════════════════════════════════════════════

@Composable
fun DeviceControlScreen(
    viewModel: DeviceControlViewModel,
    onBack: () -> Unit
) {
    val uiState     by viewModel.uiState.collectAsState()
    val deviceState  = uiState.deviceState

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisColors.VoidBlack)
    ) {
        Row(
            modifier              = Modifier
                .fillMaxWidth()
                .padding(JarvisSpacing.md),
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(JarvisSpacing.sm)
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, "Back", tint = JarvisColors.CyanCore)
            }
            Column {
                Text(
                    "DEVICE CONTROL",
                    style         = MaterialTheme.typography.headlineMedium,
                    color         = JarvisColors.TextPrimary,
                    letterSpacing = 4.sp
                )
                Text(
                    if (uiState.isAccessibilityEnabled) "ACCESSIBILITY ONLINE"
                    else "ACCESSIBILITY OFFLINE",
                    style         = MaterialTheme.typography.labelSmall,
                    color         = if (uiState.isAccessibilityEnabled)
                                        JarvisColors.GreenOnline else JarvisColors.CrimsonAlert,
                    letterSpacing = 2.sp
                )
            }
        }

        HudDivider()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(JarvisSpacing.md),
            verticalArrangement = Arrangement.spacedBy(JarvisSpacing.lg)
        ) {
            // ── Status Row ────────────────────────────────────────────────────
            HudCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier              = Modifier
                        .fillMaxWidth()
                        .padding(JarvisSpacing.md),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    StatusItem(
                        label = "BATTERY",
                        value = "${deviceState.batteryLevel}%",
                        color = when {
                            deviceState.batteryLevel < 20 -> JarvisColors.CrimsonAlert
                            deviceState.batteryLevel < 50 -> JarvisColors.GoldAlert
                            else                           -> JarvisColors.GreenOnline
                        }
                    )
                    StatusItem(
                        label = "WIFI",
                        value = if (deviceState.isWifiEnabled) "ON" else "OFF",
                        color = if (deviceState.isWifiEnabled) JarvisColors.GreenOnline else JarvisColors.TextMuted
                    )
                    StatusItem(
                        label = "BT",
                        value = if (deviceState.isBluetoothEnabled) "ON" else "OFF",
                        color = if (deviceState.isBluetoothEnabled) JarvisColors.CyanCore else JarvisColors.TextMuted
                    )
                    StatusItem(
                        label = "VOLUME",
                        value = "${deviceState.volumeLevel}/${deviceState.maxVolume}",
                        color = JarvisColors.TextSecondary
                    )
                }
            }

            // ── Quick Controls Grid ───────────────────────────────────────────
            HudSectionHeader("Quick Controls")
            LazyVerticalGrid(
                columns             = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(JarvisSpacing.sm),
                verticalArrangement = Arrangement.spacedBy(JarvisSpacing.sm),
                modifier            = Modifier.heightIn(max = 400.dp)
            ) {
                item {
                    ControlTile(
                        icon      = Icons.Default.FlashOn,
                        label     = "Flashlight",
                        isActive  = deviceState.isFlashlightOn,
                        onClick   = { viewModel.toggleFlashlight() }
                    )
                }
                item {
                    ControlTile(
                        icon      = Icons.Default.DoNotDisturb,
                        label     = "Do Not Disturb",
                        isActive  = deviceState.isDoNotDisturb,
                        onClick   = { viewModel.setDoNotDisturb(!deviceState.isDoNotDisturb) }
                    )
                }
                item {
                    ControlTile(
                        icon      = Icons.Default.Bluetooth,
                        label     = "Bluetooth",
                        isActive  = deviceState.isBluetoothEnabled,
                        onClick   = { viewModel.setBluetooth(!deviceState.isBluetoothEnabled) }
                    )
                }
                item {
                    ControlTile(
                        icon      = Icons.Default.Wifi,
                        label     = "WiFi Settings",
                        isActive  = deviceState.isWifiEnabled,
                        onClick   = { viewModel.openWifiSettings() }
                    )
                }
            }

            // ── Volume Slider ─────────────────────────────────────────────────
            HudSectionHeader("Volume")
            HudCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(JarvisSpacing.md),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Slider(
                        value         = deviceState.volumeLevel.toFloat(),
                        onValueChange = { viewModel.setVolume(it.toInt()) },
                        valueRange    = 0f..deviceState.maxVolume.toFloat(),
                        steps         = deviceState.maxVolume - 1,
                        colors        = SliderDefaults.colors(
                            thumbColor            = JarvisColors.CyanCore,
                            activeTrackColor      = JarvisColors.CyanCore,
                            inactiveTrackColor    = JarvisColors.BorderNavy
                        )
                    )
                    Row(
                        modifier              = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("0", style = MaterialTheme.typography.labelSmall, color = JarvisColors.TextMuted)
                        Text(
                            "${deviceState.volumeLevel}",
                            style = MaterialTheme.typography.labelSmall,
                            color = JarvisColors.CyanCore
                        )
                        Text("${deviceState.maxVolume}", style = MaterialTheme.typography.labelSmall, color = JarvisColors.TextMuted)
                    }
                }
            }

            // ── Brightness Slider ─────────────────────────────────────────────
            HudSectionHeader("Brightness")
            HudCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(JarvisSpacing.md)) {
                    Slider(
                        value         = deviceState.brightnessLevel.toFloat(),
                        onValueChange = { viewModel.setBrightness(it.toInt()) },
                        valueRange    = 0f..255f,
                        colors        = SliderDefaults.colors(
                            thumbColor         = JarvisColors.GoldAlert,
                            activeTrackColor   = JarvisColors.GoldAlert,
                            inactiveTrackColor = JarvisColors.BorderNavy
                        )
                    )
                }
            }

            // ── Last Action ───────────────────────────────────────────────────
            if (uiState.lastAction.isNotBlank()) {
                JarvisStatusLabel(uiState.lastAction, color = JarvisColors.GreenOnline)
            }

            Spacer(Modifier.height(JarvisSpacing.xxl))
        }
    }
}

@Composable
private fun StatusItem(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = JarvisColors.TextMuted, letterSpacing = 2.sp)
        Text(value, style = MaterialTheme.typography.titleMedium, color = color)
    }
}

@Composable
private fun ControlTile(
    icon: ImageVector,
    label: String,
    isActive: Boolean,
    onClick: () -> Unit
) {
    val color = if (isActive) JarvisColors.CyanCore else JarvisColors.TextSecondary
    HudCard(
        modifier  = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        glowColor = color,
        glowAlpha = if (isActive) 0.35f else 0.1f
    ) {
        Column(
            modifier              = Modifier.padding(JarvisSpacing.md),
            horizontalAlignment   = Alignment.CenterHorizontally,
            verticalArrangement   = Arrangement.spacedBy(8.dp)
        ) {
            Icon(icon, null, tint = color, modifier = Modifier.size(28.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, color = color, letterSpacing = 1.sp)
            JarvisChip(
                text  = if (isActive) "ON" else "OFF",
                color = color
            )
        }
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// OnboardingScreen — first-run setup
// ══════════════════════════════════════════════════════════════════════════════

@Composable
fun OnboardingScreen(onComplete: () -> Unit) {
    var page     by remember { mutableStateOf(0) }
    var userName by remember { mutableStateOf("") }

    val pages = listOf(
        OnboardingPage(
            title    = "JARVIS",
            subtitle = "AI COMMAND CENTER",
            body     = "Your personal AI assistant. Voice-powered, always ready, infinitely capable.",
            accent   = JarvisColors.CyanCore
        ),
        OnboardingPage(
            title    = "MULTI-MODEL AI",
            subtitle = "SMART ROUTING",
            body     = "Automatically selects the best AI: GPT-4o, Gemini, Groq, or on-device LLaMA — based on your task, battery, and connection.",
            accent   = JarvisColors.GoldAlert
        ),
        OnboardingPage(
            title    = "DEVICE CONTROL",
            subtitle = "FULL AUTOMATION",
            body     = "\"Turn off WiFi, set alarm for 7 AM, navigate home.\" JARVIS controls your phone through natural conversation.",
            accent   = JarvisColors.GreenOnline
        )
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisColors.VoidBlack),
        contentAlignment = Alignment.Center
    ) {
        GridBackground()

        Column(
            modifier              = Modifier
                .fillMaxSize()
                .padding(JarvisSpacing.xl),
            verticalArrangement   = Arrangement.SpaceBetween,
            horizontalAlignment   = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(JarvisSpacing.xxl))

            ArcReactorOrb(size = 100.dp)

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(JarvisSpacing.md)
            ) {
                Text(
                    pages[page].title,
                    style         = MaterialTheme.typography.displayMedium,
                    color         = pages[page].accent,
                    letterSpacing = 8.sp
                )
                Text(
                    pages[page].subtitle,
                    style         = MaterialTheme.typography.labelLarge,
                    color         = JarvisColors.TextMuted,
                    letterSpacing = 4.sp
                )
                Spacer(Modifier.height(JarvisSpacing.md))
                Text(
                    pages[page].body,
                    style         = MaterialTheme.typography.bodyLarge,
                    color         = JarvisColors.TextSecondary,
                    textAlign     = androidx.compose.ui.text.style.TextAlign.Center
                )

                // Name input on last page
                if (page == pages.lastIndex) {
                    Spacer(Modifier.height(JarvisSpacing.lg))
                    OutlinedTextField(
                        value         = userName,
                        onValueChange = { userName = it },
                        modifier      = Modifier.fillMaxWidth(),
                        placeholder   = { Text("Your name", color = JarvisColors.TextDisabled) },
                        label         = { Text("How should JARVIS address you?", color = JarvisColors.TextMuted) },
                        singleLine    = true,
                        colors        = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor    = JarvisColors.CyanCore.copy(0.6f),
                            unfocusedBorderColor  = JarvisColors.BorderNavy,
                            cursorColor           = JarvisColors.CyanCore,
                            focusedContainerColor = JarvisColors.ElevatedNavy,
                            unfocusedContainerColor = JarvisColors.SurfaceNavy,
                            focusedTextColor      = JarvisColors.TextPrimary,
                            unfocusedTextColor    = JarvisColors.TextPrimary,
                            focusedLabelColor     = JarvisColors.CyanCore
                        ),
                        shape = RoundedCornerShape(4.dp)
                    )
                }
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(JarvisSpacing.md)
            ) {
                // Page dots
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    pages.indices.forEach { i ->
                        Box(
                            modifier = Modifier
                                .size(if (i == page) 20.dp else 6.dp, 6.dp)
                                .background(
                                    if (i == page) JarvisColors.CyanCore else JarvisColors.TextDisabled,
                                    RoundedCornerShape(3.dp)
                                )
                        )
                    }
                }

                JarvisButton(
                    text    = if (page < pages.lastIndex) "NEXT" else "ENGAGE",
                    onClick = {
                        if (page < pages.lastIndex) page++
                        else onComplete()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled  = page < pages.lastIndex || userName.isNotBlank()
                )
            }
        }
    }
}

private data class OnboardingPage(
    val title: String,
    val subtitle: String,
    val body: String,
    val accent: Color
)
