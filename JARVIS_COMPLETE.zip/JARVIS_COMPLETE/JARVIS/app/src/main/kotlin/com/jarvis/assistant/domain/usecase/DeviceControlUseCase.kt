package com.jarvis.assistant.domain.usecase

import android.content.Context
import android.media.AudioManager
import android.os.Build
import android.hardware.camera2.CameraManager
import com.jarvis.assistant.core.utils.CommandClassifier
import com.jarvis.assistant.domain.entities.DeviceState
import com.jarvis.assistant.domain.repository.DeviceRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

/**
 * DeviceControlUseCase — executes device control commands.
 *
 * Integrates with Android system APIs for:
 * Flashlight, Volume, WiFi, Bluetooth, Screenshots, Notifications
 */
class DeviceControlUseCase @Inject constructor(
    @ApplicationContext private val context: Context,
    private val deviceRepository: DeviceRepository
) {

    sealed class DeviceResult {
        data class Success(val message: String) : DeviceResult()
        data class Failed(val reason: String) : DeviceResult()
        data class StateChanged(val state: DeviceState) : DeviceResult()
    }

    fun getDeviceState(): Flow<DeviceState> = deviceRepository.getDeviceState()

    // ── Flashlight ────────────────────────────────────────────────────────────

    suspend fun toggleFlashlight(enable: Boolean): DeviceResult {
        return try {
            val cameraManager = context.getSystemService(CameraManager::class.java)
            val cameraId = cameraManager?.cameraIdList?.firstOrNull()
            if (cameraId != null) {
                cameraManager.setTorchMode(cameraId, enable)
                DeviceResult.Success(if (enable) "Flashlight on." else "Flashlight off.")
            } else {
                DeviceResult.Failed("No camera found")
            }
        } catch (e: Exception) {
            DeviceResult.Failed("Flashlight error: ${e.message}")
        }
    }

    // ── Volume ────────────────────────────────────────────────────────────────

    suspend fun setVolume(level: Int): DeviceResult {
        return try {
            val am = context.getSystemService(AudioManager::class.java)
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val clamped = level.coerceIn(0, max)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, clamped, AudioManager.FLAG_SHOW_UI)
            DeviceResult.Success("Volume set to $clamped.")
        } catch (e: Exception) {
            DeviceResult.Failed("Volume error: ${e.message}")
        }
    }

    suspend fun adjustVolume(direction: VolumeDirection): DeviceResult {
        return try {
            val am = context.getSystemService(AudioManager::class.java)
            val flag = when (direction) {
                VolumeDirection.UP   -> AudioManager.ADJUST_RAISE
                VolumeDirection.DOWN -> AudioManager.ADJUST_LOWER
                VolumeDirection.MUTE -> AudioManager.ADJUST_MUTE
            }
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, flag, AudioManager.FLAG_SHOW_UI)
            DeviceResult.Success("Volume ${direction.name.lowercase()}.")
        } catch (e: Exception) {
            DeviceResult.Failed(e.message ?: "Volume adjust failed")
        }
    }

    enum class VolumeDirection { UP, DOWN, MUTE }

    // ── WiFi ──────────────────────────────────────────────────────────────────

    suspend fun setWifi(enable: Boolean): DeviceResult {
        // Direct WiFi toggle removed in Android 10+; open settings panel instead
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            DeviceResult.Failed("WiFi toggle requires Settings on Android 10+. Opening settings…")
        } else {
            val success = deviceRepository.setWifi(enable)
            if (success) DeviceResult.Success("WiFi ${if (enable) "enabled" else "disabled"}.")
            else DeviceResult.Failed("WiFi toggle failed")
        }
    }

    // ── Bluetooth ─────────────────────────────────────────────────────────────

    suspend fun setBluetooth(enable: Boolean): DeviceResult {
        val success = deviceRepository.setBluetooth(enable)
        return if (success) DeviceResult.Success("Bluetooth ${if (enable) "enabled" else "disabled"}.")
        else DeviceResult.Failed("Bluetooth toggle failed")
    }

    // ── Screenshot ────────────────────────────────────────────────────────────

    suspend fun takeScreenshot(): DeviceResult {
        val result = deviceRepository.takeScreenshot()
        return result.fold(
            onSuccess = { path -> DeviceResult.Success("Screenshot saved: $path") },
            onFailure = { e   -> DeviceResult.Failed("Screenshot failed: ${e.message}") }
        )
    }

    // ── Notifications ─────────────────────────────────────────────────────────

    fun getNotifications(): Flow<List<com.jarvis.assistant.domain.entities.AppNotification>> =
        deviceRepository.getNotifications()

    // ── Installed Apps ────────────────────────────────────────────────────────

    suspend fun getInstalledApps() = deviceRepository.getInstalledApps()

    // ── Command dispatch ──────────────────────────────────────────────────────

    suspend fun executeCommand(
        commandType: CommandClassifier.CommandType,
        rawText: String
    ): DeviceResult {
        return when (commandType) {
            CommandClassifier.CommandType.FLASHLIGHT ->
                toggleFlashlight(rawText.contains("on", ignoreCase = true))

            CommandClassifier.CommandType.VOLUME_CONTROL -> {
                val dir = when {
                    rawText.contains("up", ignoreCase = true) ||
                    rawText.contains("louder", ignoreCase = true) ||
                    rawText.contains("increase", ignoreCase = true)  -> VolumeDirection.UP
                    rawText.contains("mute", ignoreCase = true)       -> VolumeDirection.MUTE
                    else                                              -> VolumeDirection.DOWN
                }
                adjustVolume(dir)
            }

            CommandClassifier.CommandType.WIFI_TOGGLE ->
                setWifi(rawText.contains("on", ignoreCase = true) ||
                        rawText.contains("enable", ignoreCase = true))

            CommandClassifier.CommandType.BLUETOOTH_TOGGLE ->
                setBluetooth(rawText.contains("on", ignoreCase = true) ||
                             rawText.contains("enable", ignoreCase = true))

            CommandClassifier.CommandType.SCREENSHOT ->
                takeScreenshot()

            else -> DeviceResult.Failed("Unsupported command type: $commandType")
        }
    }
}
