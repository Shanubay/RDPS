package com.jarvis.assistant.service.voice

import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.jarvis.assistant.JarvisApplication
import com.jarvis.assistant.core.constants.AppConstants
import com.jarvis.assistant.core.utils.NetworkUtils
import com.jarvis.assistant.core.utils.NotificationHelper
import com.jarvis.assistant.domain.repository.AIRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.Locale
import javax.inject.Inject

/**
 * SpeechRecognitionService — unified speech-to-text service.
 *
 * Strategy:
 * 1. Android SpeechRecognizer (default, online, best accuracy)
 * 2. Vosk (offline fallback if Vosk model downloaded)
 * 3. OpenAI Whisper (cloud fallback, highest accuracy)
 *
 * Exposes a bound service interface for the ViewModel to control.
 */
@AndroidEntryPoint
class SpeechRecognitionService : Service() {

    @Inject lateinit var networkUtils: NetworkUtils
    @Inject lateinit var notificationHelper: NotificationHelper
    @Inject lateinit var voskManager: VoskManager
    @Inject lateinit var aiRepository: AIRepository

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var speechRecognizer: SpeechRecognizer? = null
    private var currentListeningJob: Job? = null

    private val _sttState = MutableStateFlow<SttState>(SttState.Idle)
    val sttState: StateFlow<SttState> = _sttState.asStateFlow()

    // ── Bound service ─────────────────────────────────────────────────────────

    inner class SttBinder : Binder() {
        fun getService() = this@SpeechRecognitionService
    }

    private val binder = SttBinder()
    override fun onBind(intent: Intent): IBinder = binder

    // ── STT States ────────────────────────────────────────────────────────────

    sealed class SttState {
        object Idle : SttState()
        object Listening : SttState()
        data class Partial(val text: String) : SttState()
        data class Result(val text: String, val provider: String) : SttState()
        data class Error(val message: String) : SttState()
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        startForeground(
            JarvisApplication.NOTIFICATION_ID_VOICE,
            notificationHelper.buildVoiceNotification(true)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            AppConstants.Actions.START_LISTENING -> startListening()
            AppConstants.Actions.STOP_LISTENING  -> stopListening()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        stopListening()
        serviceScope.cancel()
        super.onDestroy()
    }

    // ── Public API ────────────────────────────────────────────────────────────

    fun startListening() {
        if (_sttState.value is SttState.Listening) return

        currentListeningJob?.cancel()
        currentListeningJob = serviceScope.launch {
            when {
                // Online → use Android SpeechRecognizer
                networkUtils.isConnected -> listenWithAndroid()
                // Offline + Vosk model → use Vosk
                voskManager.isModelAvailable -> listenWithVosk()
                // No options
                else -> _sttState.value = SttState.Error(
                    "No offline STT model. Download Vosk model or connect to internet."
                )
            }
        }
    }

    fun stopListening() {
        currentListeningJob?.cancel()
        speechRecognizer?.stopListening()
        speechRecognizer?.destroy()
        speechRecognizer = null
        _sttState.value = SttState.Idle
    }

    // ── Android SpeechRecognizer ──────────────────────────────────────────────

    private suspend fun listenWithAndroid() = suspendCancellableCoroutine<Unit> { cont ->
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            _sttState.value = SttState.Error("Speech recognition not available")
            cont.resume(Unit) {}
            return@suspendCancellableCoroutine
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {

                override fun onReadyForSpeech(params: android.os.Bundle?) {
                    _sttState.value = SttState.Listening
                }

                override fun onPartialResults(partial: android.os.Bundle?) {
                    val text = partial
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull() ?: return
                    if (text.isNotBlank()) _sttState.value = SttState.Partial(text)
                }

                override fun onResults(results: android.os.Bundle?) {
                    val text = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull() ?: ""
                    _sttState.value = if (text.isNotBlank())
                        SttState.Result(text, "android")
                    else
                        SttState.Error("No speech detected")
                    if (cont.isActive) cont.resume(Unit) {}
                }

                override fun onError(error: Int) {
                    val msg = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH       -> "No match — please try again"
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Speech timeout"
                        SpeechRecognizer.ERROR_AUDIO          -> "Audio error"
                        SpeechRecognizer.ERROR_NETWORK        -> "Network error"
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy"
                        else -> "Speech error ($error)"
                    }
                    _sttState.value = SttState.Error(msg)
                    if (cont.isActive) cont.resume(Unit) {}
                }

                override fun onBeginningOfSpeech()              { }
                override fun onRmsChanged(rms: Float)           { }
                override fun onBufferReceived(buf: ByteArray?)  { }
                override fun onEndOfSpeech()                    { }
                override fun onEvent(t: Int, p: android.os.Bundle?) { }
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS,
                AppConstants.STT_SILENCE_THRESHOLD_MS)
        }

        try {
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            _sttState.value = SttState.Error(e.message ?: "Failed to start listening")
            if (cont.isActive) cont.resume(Unit) {}
        }

        cont.invokeOnCancellation {
            speechRecognizer?.stopListening()
            speechRecognizer?.destroy()
            speechRecognizer = null
        }
    }

    // ── Vosk Offline STT ──────────────────────────────────────────────────────

    private suspend fun listenWithVosk() {
        _sttState.value = SttState.Listening
        var finalText = ""

        try {
            voskManager.startRecognition()
                .takeWhile { it !is VoskManager.VoskResult.Error }
                .collect { result ->
                    when (result) {
                        is VoskManager.VoskResult.Partial ->
                            _sttState.value = SttState.Partial(result.text)
                        is VoskManager.VoskResult.Final   -> {
                            finalText = result.text
                            _sttState.value = SttState.Result(result.text, "vosk")
                        }
                        is VoskManager.VoskResult.ModelNotFound ->
                            _sttState.value = SttState.Error("Vosk model not found")
                        else -> {}
                    }
                }
        } catch (e: Exception) {
            _sttState.value = SttState.Error(e.message ?: "Vosk error")
        }
    }
}
