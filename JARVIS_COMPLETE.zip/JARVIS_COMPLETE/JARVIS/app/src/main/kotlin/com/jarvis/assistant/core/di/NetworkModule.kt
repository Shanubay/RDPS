package com.jarvis.assistant.core.di

import com.google.gson.Gson
import com.jarvis.assistant.core.llm.LlamaEngine
import com.jarvis.assistant.core.utils.AppPreferences
import com.jarvis.assistant.core.utils.BatteryUtils
import com.jarvis.assistant.core.utils.DeviceInfoUtils
import com.jarvis.assistant.core.utils.NetworkUtils
import com.jarvis.assistant.data.remote.*
import com.jarvis.assistant.data.remote.api.SseParser
import com.jarvis.assistant.data.repository.AIRepositoryImpl
import com.jarvis.assistant.domain.repository.AIRepository
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    @Provides @Singleton
    fun provideOpenAiProvider(
        prefs: AppPreferences,
        gson: Gson,
        sseParser: SseParser,
        okHttp: OkHttpClient
    ) = OpenAiProvider(prefs, gson, sseParser, okHttp)

    @Provides @Singleton
    fun provideGeminiProvider(
        prefs: AppPreferences,
        gson: Gson,
        sseParser: SseParser,
        okHttp: OkHttpClient
    ) = GeminiProvider(prefs, gson, sseParser, okHttp)

    @Provides @Singleton
    fun provideGroqProvider(
        prefs: AppPreferences,
        gson: Gson,
        sseParser: SseParser,
        okHttp: OkHttpClient
    ) = GroqProvider(prefs, gson, sseParser, okHttp)

    @Provides @Singleton
    fun provideOpenRouterProvider(
        prefs: AppPreferences,
        gson: Gson,
        sseParser: SseParser,
        okHttp: OkHttpClient
    ) = OpenRouterProvider(prefs, gson, sseParser, okHttp)

    @Provides @Singleton
    fun provideLocalLlamaProvider(engine: LlamaEngine) =
        LocalLlamaProvider(engine)

    @Provides @Singleton
    fun provideAIRouter(
        openAi: OpenAiProvider,
        gemini: GeminiProvider,
        groq: GroqProvider,
        openRouter: OpenRouterProvider,
        local: LocalLlamaProvider,
        network: NetworkUtils,
        battery: BatteryUtils,
        device: DeviceInfoUtils,
        prefs: AppPreferences
    ) = AIRouter(openAi, gemini, groq, openRouter, local, network, battery, device, prefs)

    @Provides @Singleton
    fun provideSseParser(gson: Gson) = SseParser(gson)
}

@Module
@InstallIn(SingletonComponent::class)
abstract class AIRepositoryModule {
    @Binds @Singleton
    abstract fun bindAIRepository(impl: AIRepositoryImpl): AIRepository
}
