package com.jarvis.assistant.domain.usecase

import com.jarvis.assistant.core.utils.AppPreferences
import com.jarvis.assistant.core.utils.EmbeddingUtils
import com.jarvis.assistant.domain.entities.Memory
import com.jarvis.assistant.domain.entities.MemoryType
import com.jarvis.assistant.domain.entities.Message
import com.jarvis.assistant.domain.entities.MessageRole
import com.jarvis.assistant.domain.repository.MemoryRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

/**
 * ManageMemoryUseCase — handles all memory extraction, storage, and retrieval.
 *
 * Responsibilities:
 * • Extract facts from conversations using pattern matching + AI hints
 * • Embed memories for semantic search
 * • Retrieve relevant memories for AI context injection
 * • Semantic search for "what do you know about X"
 */
class ManageMemoryUseCase @Inject constructor(
    private val memoryRepository: MemoryRepository,
    private val embeddingUtils: EmbeddingUtils,
    private val appPreferences: AppPreferences
) {

    // ── Extract & save memories from a message pair ───────────────────────────

    suspend fun extractAndSave(userMessage: String, aiResponse: String) {
        val extracted = extractFacts(userMessage)
        for (fact in extracted) {
            val embedding = embeddingUtils.embed(fact.content)
            val embStr    = embeddingUtils.serializeEmbedding(embedding)
            memoryRepository.insertMemory(
                fact.copy(
                    embedding    = embedding,
                    embeddingStr = embStr
                )
            )
        }
    }

    // ── Semantic search ───────────────────────────────────────────────────────

    suspend fun semanticSearch(query: String, topK: Int = 5): List<Pair<Memory, Float>> {
        val queryEmbedding = embeddingUtils.embed(query)
        val allMemories    = memoryRepository.getAllMemoriesWithEmbeddings()

        return allMemories
            .mapNotNull { memory ->
                val vec = if (memory.embedding != null) memory.embedding
                else if (memory.embeddingStr.isNotBlank())
                    embeddingUtils.deserializeEmbedding(memory.embeddingStr)
                else return@mapNotNull null

                val score = embeddingUtils.cosineSimilarity(queryEmbedding, vec)
                if (score > 0.4f) memory to score else null
            }
            .sortedByDescending { (_, score) -> score }
            .take(topK)
            .also { results ->
                // Update access counts
                results.forEach { (memory, _) ->
                    memoryRepository.touchMemory(memory.id)
                }
            }
    }

    // ── Build memory context string for prompts ────────────────────────────────

    suspend fun buildMemoryContext(query: String): String {
        val relevant = semanticSearch(query, topK = 5)
        val top      = memoryRepository.getContextMemories(3)

        val combined = (relevant.map { it.first } + top)
            .distinctBy { it.id }
            .take(7)

        return if (combined.isEmpty()) ""
        else combined.joinToString("\n") { "• ${it.content}" }
    }

    // ── Manual memory save ────────────────────────────────────────────────────

    suspend fun saveManualMemory(content: String, type: MemoryType = MemoryType.GENERAL) {
        val embedding = embeddingUtils.embed(content)
        memoryRepository.insertMemory(
            Memory(
                content      = content,
                type         = type,
                embedding    = embedding,
                embeddingStr = embeddingUtils.serializeEmbedding(embedding),
                importance   = 0.8f,
                source       = "manual"
            )
        )
    }

    fun getAllMemories(): Flow<List<Memory>> = memoryRepository.getAllMemories()

    suspend fun deleteMemory(id: String) = memoryRepository.deleteMemory(id)
    suspend fun clearAll()               = memoryRepository.clearAllMemories()

    // ── Fact Extraction ───────────────────────────────────────────────────────

    private fun extractFacts(userText: String): List<Memory> {
        val facts = mutableListOf<Memory>()
        val lower = userText.lowercase()

        // Name patterns
        extractPattern(
            userText,
            listOf(
                Regex("my name is ([A-Za-z]+)", RegexOption.IGNORE_CASE),
                Regex("i'?m ([A-Za-z]+)", RegexOption.IGNORE_CASE),
                Regex("call me ([A-Za-z]+)", RegexOption.IGNORE_CASE)
            ),
            MemoryType.FACT
        ) { match -> "User's name is ${match.groupValues[1].trim()}" }
            .let { facts.addAll(it) }

        // Location patterns
        extractPattern(
            userText,
            listOf(
                Regex("i live in ([A-Za-z ,]+)", RegexOption.IGNORE_CASE),
                Regex("i'?m from ([A-Za-z ,]+)", RegexOption.IGNORE_CASE),
                Regex("i'?m in ([A-Za-z ,]+)", RegexOption.IGNORE_CASE)
            ),
            MemoryType.FACT
        ) { match -> "User lives in ${match.groupValues[1].trim()}" }
            .let { facts.addAll(it) }

        // Preference patterns
        extractPattern(
            userText,
            listOf(
                Regex("i (?:like|love|prefer|enjoy) (.+?)(?:\\.|$)", RegexOption.IGNORE_CASE),
                Regex("my favourite (.+?) is (.+?)(?:\\.|$)", RegexOption.IGNORE_CASE),
                Regex("i (?:hate|dislike|don'?t like) (.+?)(?:\\.|$)", RegexOption.IGNORE_CASE)
            ),
            MemoryType.PREFERENCE
        ) { match -> match.value.trim().replaceFirstChar { it.uppercase() } }
            .let { facts.addAll(it) }

        // Work / role patterns
        extractPattern(
            userText,
            listOf(
                Regex("i work (?:at|for|as) (.+?)(?:\\.|$)", RegexOption.IGNORE_CASE),
                Regex("i'?m a (.+?)(?:\\.|$)", RegexOption.IGNORE_CASE),
                Regex("my job is (.+?)(?:\\.|$)", RegexOption.IGNORE_CASE)
            ),
            MemoryType.FACT
        ) { match -> match.value.trim().replaceFirstChar { it.uppercase() } }
            .let { facts.addAll(it) }

        // Remember command: "remember that..."
        Regex("remember (?:that )?(.+)", RegexOption.IGNORE_CASE)
            .find(lower)
            ?.let { match ->
                facts.add(Memory(
                    content    = match.groupValues[1].trim().replaceFirstChar { it.uppercase() },
                    type       = MemoryType.GENERAL,
                    importance = 0.9f,
                    source     = "user_command"
                ))
            }

        return facts
    }

    private fun extractPattern(
        text: String,
        patterns: List<Regex>,
        type: MemoryType,
        transform: (MatchResult) -> String
    ): List<Memory> {
        val results = mutableListOf<Memory>()
        for (pattern in patterns) {
            pattern.find(text)?.let { match ->
                val content = transform(match)
                if (content.length in 5..200) {
                    results.add(Memory(
                        content    = content,
                        type       = type,
                        importance = 0.7f,
                        source     = "conversation"
                    ))
                }
            }
        }
        return results
    }
}
