package com.jarvis.assistant.data.local.dao

import androidx.room.*
import com.jarvis.assistant.data.local.entities.MemoryEntity
import kotlinx.coroutines.flow.Flow

// ══════════════════════════════════════════════════════════════════════════════
// MemoryDao — Room DAO for the JARVIS long-term memory system
// ══════════════════════════════════════════════════════════════════════════════

@Dao
interface MemoryDao {

    // ── Retrieval ─────────────────────────────────────────────────────────────

    @Query("SELECT * FROM memories ORDER BY last_accessed_at DESC")
    fun getAllMemories(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories ORDER BY last_accessed_at DESC")
    suspend fun getAllMemoriesOnce(): List<MemoryEntity>

    @Query("SELECT * FROM memories WHERE embedding_str != '' ORDER BY last_accessed_at DESC")
    suspend fun getAllMemoriesWithEmbeddings(): List<MemoryEntity>

    @Query("SELECT * FROM memories WHERE type = :type ORDER BY importance DESC, last_accessed_at DESC")
    fun getMemoriesByType(type: String): Flow<List<MemoryEntity>>

    @Query("""
        SELECT * FROM memories 
        ORDER BY (importance * 0.6 + (access_count * 0.1)) DESC
        LIMIT :limit
    """)
    fun getTopMemories(limit: Int): Flow<List<MemoryEntity>>

    @Query("""
        SELECT * FROM memories 
        ORDER BY (importance * 0.6 + (access_count * 0.1)) DESC
        LIMIT :limit
    """)
    suspend fun getTopMemoriesOnce(limit: Int): List<MemoryEntity>

    @Query("SELECT * FROM memories WHERE id = :id LIMIT 1")
    suspend fun getMemoryById(id: String): MemoryEntity?

    @Query("""
        SELECT * FROM memories 
        WHERE content LIKE '%' || :query || '%'
        ORDER BY importance DESC
        LIMIT 20
    """)
    suspend fun searchMemoriesByContent(query: String): List<MemoryEntity>

    // ── Write ─────────────────────────────────────────────────────────────────

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(memory: MemoryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemories(memories: List<MemoryEntity>)

    @Update
    suspend fun updateMemory(memory: MemoryEntity)

    @Query("DELETE FROM memories WHERE id = :id")
    suspend fun deleteMemory(id: String)

    @Query("DELETE FROM memories")
    suspend fun deleteAllMemories()

    // ── Access tracking ───────────────────────────────────────────────────────

    @Query("""
        UPDATE memories 
        SET access_count = access_count + 1,
            last_accessed_at = :timestamp
        WHERE id = :id
    """)
    suspend fun touchMemory(id: String, timestamp: Long = System.currentTimeMillis())

    @Query("""
        UPDATE memories 
        SET importance = :importance
        WHERE id = :id
    """)
    suspend fun updateImportance(id: String, importance: Float)

    // ── Deduplication ─────────────────────────────────────────────────────────

    @Query("SELECT * FROM memories WHERE content = :content LIMIT 1")
    suspend fun findByExactContent(content: String): MemoryEntity?

    @Query("""
        SELECT * FROM memories 
        WHERE content LIKE '%' || :keyword || '%'
        AND type = :type
        LIMIT 5
    """)
    suspend fun findSimilarByKeyword(keyword: String, type: String): List<MemoryEntity>

    // ── Stats ─────────────────────────────────────────────────────────────────

    @Query("SELECT COUNT(*) FROM memories")
    suspend fun getMemoryCount(): Int

    @Query("SELECT COUNT(*) FROM memories WHERE type = :type")
    suspend fun getMemoryCountByType(type: String): Int

    @Query("SELECT * FROM memories ORDER BY created_at ASC LIMIT :limit")
    suspend fun getOldestMemories(limit: Int): List<MemoryEntity>

    // ── Pruning (keep memory under limit) ─────────────────────────────────────

    @Query("""
        DELETE FROM memories WHERE id IN (
            SELECT id FROM memories 
            ORDER BY (importance * 0.5 + access_count * 0.1) ASC
            LIMIT :count
        )
    """)
    suspend fun pruneLowestPriorityMemories(count: Int)
}
