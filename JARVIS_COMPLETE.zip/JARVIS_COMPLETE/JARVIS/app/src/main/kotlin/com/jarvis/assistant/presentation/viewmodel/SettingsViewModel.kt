package com.jarvis.assistant.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.core.utils.AppPreferences
import com.jarvis.assistant.core.utils.EncryptionManager
import com.jarvis.assistant.domain.entities.SettingsState
import com.jarvis.assistant.domain.usecase.ValidateApiKeyUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val prefs: AppPreferences,
    private val encryption: EncryptionManager,
    private val validateApiKey: ValidateApiKeyUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(SettingsState())
    val uiState: StateFlow<SettingsState> = _uiState.asStateFlow()

    private val _validationState = MutableStateFlow<ValidateApiKeyUseCase.ValidationResult?>(null)
    val validationState: StateFlow<ValidateApiKeyUseCase.ValidationResult?> = _validationState.asStateFlow()

    init { loadSettings() }

    private fun loadSettings() {
        viewModelScope.launch {
            combine(
                prefs.aiProvider,
                prefs.openAiKey,
                prefs.geminiKey,
                prefs.groqKey,
                prefs.elevenLabsKey,
                prefs.ttsProvider,
                prefs.voiceEnabled,
                prefs.overlayEnabled,
                prefs.offlineMode,
                prefs.activeModelName,
                prefs.userName
            ) { values ->
                SettingsState(
                    aiProvider      = values[0] as String,
                    openAiKey       = encryption.decryptApiKey(values[1] as String),
                    geminiKey       = encryption.decryptApiKey(values[2] as String),
                    groqKey         = encryption.decryptApiKey(values[3] as String),
                    elevenLabsKey   = encryption.decryptApiKey(values[4] as String),
                    ttsProvider     = values[5] as String,
                    voiceEnabled    = values[6] as Boolean,
                    overlayEnabled  = values[7] as Boolean,
                    offlineMode     = values[8] as Boolean,
                    activeModelName = values[9] as String?,
                    userName        = values[10] as String
                )
            }.collect { state -> _uiState.value = state }
        }
    }

    fun setAiProvider(provider: String) {
        viewModelScope.launch { prefs.setAiProvider(provider) }
    }

    fun saveOpenAiKey(key: String) {
        viewModelScope.launch { prefs.setOpenAiKey(encryption.encryptApiKey(key)) }
    }

    fun saveGeminiKey(key: String) {
        viewModelScope.launch { prefs.setGeminiKey(encryption.encryptApiKey(key)) }
    }

    fun saveGroqKey(key: String) {
        viewModelScope.launch { prefs.setGroqKey(encryption.encryptApiKey(key)) }
    }

    fun saveElevenLabsKey(key: String) {
        viewModelScope.launch { prefs.setElevenLabsKey(encryption.encryptApiKey(key)) }
    }

    fun setTtsProvider(provider: String) {
        viewModelScope.launch { prefs.setTtsProvider(provider) }
    }

    fun setVoiceEnabled(enabled: Boolean) {
        viewModelScope.launch { prefs.setVoiceEnabled(enabled) }
    }

    fun setOverlayEnabled(enabled: Boolean) {
        viewModelScope.launch { prefs.setOverlayEnabled(enabled) }
    }

    fun setOfflineMode(offline: Boolean) {
        viewModelScope.launch { prefs.setOfflineMode(offline) }
    }

    fun setUserName(name: String) {
        viewModelScope.launch { prefs.setUserName(name) }
    }

    fun validateKey(provider: String, key: String) {
        viewModelScope.launch {
            _validationState.value = ValidateApiKeyUseCase.ValidationResult.Checking
            _validationState.value = validateApiKey(provider, key)
        }
    }

    fun clearValidation() { _validationState.value = null }
}
