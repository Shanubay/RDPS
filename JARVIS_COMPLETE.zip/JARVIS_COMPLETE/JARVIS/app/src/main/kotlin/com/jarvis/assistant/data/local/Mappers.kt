package com.jarvis.assistant.data.local

import com.jarvis.assistant.data.local.entities.*
import com.jarvis.assistant.domain.entities.*

// ══════════════════════════════════════════════════════════════════════════════
// Mappers — bidirectional conversion between Room entities and domain models
// ══════════════════════════════════════════════════════════════════════════════

// ── Conversation ──────────────────────────────────────────────────────────────

fun ConversationEntity.toDomain(): Conversation = Conversation(
    id           = id,
    title        = title,
    createdAt    = createdAt,
    updatedAt    = updatedAt,
    messageCount = messageCount,
    summary      = summary,
    tags         = tags
)

fun Conversation.toEntity(): ConversationEntity = ConversationEntity(
    id           = id,
    title        = title,
    createdAt    = createdAt,
    updatedAt    = updatedAt,
    messageCount = messageCount,
    summary      = summary,
    tags         = tags
)

// ── Message ───────────────────────────────────────────────────────────────────

fun MessageEntity.toDomain(): Message = Message(
    id           = id,
    role         = role,
    content      = content,
    timestamp    = timestamp,
    status       = status,
    provider     = provider,
    tokenCount   = tokenCount,
    durationMs   = durationMs,
    isVoice      = isVoice,
    audioPath    = audioPath
)

fun Message.toEntity(conversationId: String): MessageEntity = MessageEntity(
    id             = id,
    conversationId = conversationId,
    role           = role,
    content        = content,
    timestamp      = timestamp,
    status         = status,
    provider       = provider,
    tokenCount     = tokenCount,
    durationMs     = durationMs,
    isVoice        = isVoice,
    audioPath      = audioPath
)

// ── Memory ────────────────────────────────────────────────────────────────────

fun MemoryEntity.toDomain(): Memory = Memory(
    id              = id,
    content         = content,
    type            = type,
    embeddingStr    = embeddingStr,
    conversationId  = conversationId,
    createdAt       = createdAt,
    accessCount     = accessCount,
    lastAccessedAt  = lastAccessedAt,
    importance      = importance,
    source          = source
)

fun Memory.toEntity(): MemoryEntity = MemoryEntity(
    id              = id,
    content         = content,
    type            = type,
    embeddingStr    = embeddingStr,
    conversationId  = conversationId,
    createdAt       = createdAt,
    accessCount     = accessCount,
    lastAccessedAt  = lastAccessedAt,
    importance      = importance,
    source          = source
)

// ── LocalModel ────────────────────────────────────────────────────────────────

fun LocalModelEntity.toDomain(): AIModel = AIModel(
    id               = id,
    name             = name,
    description      = description,
    provider         = ModelProvider.LOCAL_LLAMA,
    downloadUrl      = downloadUrl,
    filePath         = filePath,
    sizeBytes        = sizeBytes,
    ramRequired      = ramRequired,
    status           = ModelStatus.valueOf(status),
    downloadProgress = downloadProgress,
    contextLength    = contextLength,
    quantization     = quantization,
    isDefault        = isActive
)

fun AIModel.toEntity(): LocalModelEntity = LocalModelEntity(
    id               = id,
    name             = name,
    description      = description,
    downloadUrl      = downloadUrl,
    filePath         = filePath,
    sizeBytes        = sizeBytes,
    ramRequired      = ramRequired,
    status           = status.name,
    downloadProgress = downloadProgress,
    contextLength    = contextLength,
    quantization     = quantization,
    isActive         = isDefault
)

// ── Notification ──────────────────────────────────────────────────────────────

fun NotificationEntity.toDomain(): AppNotification = AppNotification(
    id          = id,
    packageName = packageName,
    appName     = appName,
    title       = title,
    text        = text,
    timestamp   = timestamp,
    isRead      = isRead
)

fun AppNotification.toEntity(): NotificationEntity = NotificationEntity(
    id          = id,
    packageName = packageName,
    appName     = appName,
    title       = title,
    text        = text,
    timestamp   = timestamp,
    isRead      = isRead
)
