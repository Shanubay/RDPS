package com.jarvis.assistant.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.*
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.jarvis.assistant.domain.entities.*
import com.jarvis.assistant.presentation.viewmodel.BrainViewModel
import com.jarvis.assistant.presentation.viewmodel.BrainUiState
import com.jarvis.assistant.ui.components.*
import com.jarvis.assistant.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: BrainViewModel,
    onNavigateToSettings: () -> Unit = {},
    onNavigateToMemory: () -> Unit   = {},
    onNavigateToModels: () -> Unit   = {}
) {
    val uiState by viewModel.uiState.collectAsState()
    val listState = rememberLazyListState()
    val scope     = rememberCoroutineScope()
    var inputText by remember { mutableStateOf("") }

    // Auto-scroll to bottom on new messages
    LaunchedEffect(uiState.messages.size, uiState.streamingText) {
        if (uiState.messages.isNotEmpty()) {
            listState.animateScrollToItem(uiState.messages.lastIndex)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisColors.VoidBlack)
    ) {
        // Subtle grid background
        GridBackground()

        Column(modifier = Modifier.fillMaxSize()) {

            // ── Top Bar ───────────────────────────────────────────────────────
            ChatTopBar(
                title              = uiState.conversationTitle,
                activeProvider     = uiState.activeProvider,
                onSettingsClick    = onNavigateToSettings,
                onMemoryClick      = onNavigateToMemory,
                onClearClick       = { viewModel.clearConversation() }
            )

            HudDivider()

            // ── Messages ──────────────────────────────────────────────────────
            Box(modifier = Modifier.weight(1f)) {
                LazyColumn(
                    state          = listState,
                    contentPadding = PaddingValues(
                        start  = JarvisSpacing.md,
                        end    = JarvisSpacing.md,
                        top    = JarvisSpacing.md,
                        bottom = JarvisSpacing.lg
                    ),
                    verticalArrangement = Arrangement.spacedBy(JarvisSpacing.sm)
                ) {
                    // Empty state
                    if (uiState.messages.isEmpty()) {
                        item {
                            EmptyState(
                                modifier = Modifier
                                    .fillParentMaxSize()
                                    .padding(JarvisSpacing.xl)
                            )
                        }
                    }

                    // Messages
                    items(uiState.messages, key = { it.id }) { message ->
                        MessageBubble(message = message)
                    }

                    // Tool results
                    if (uiState.toolResults.isNotEmpty()) {
                        item {
                            ToolResultsRow(results = uiState.toolResults)
                        }
                    }

                    // Thinking indicator
                    if (uiState.isThinking && uiState.streamingText.isBlank()) {
                        item {
                            ThinkingBubble(step = uiState.currentStep, activeTool = uiState.activeTool)
                        }
                    }
                }

                // Fade at top
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(32.dp)
                        .align(Alignment.TopCenter)
                        .background(
                            Brush.verticalGradient(
                                listOf(JarvisColors.VoidBlack, Color.Transparent)
                            )
                        )
                )
            }

            HudDivider()

            // ── Voice Orb + Input ─────────────────────────────────────────────
            BottomInputSection(
                uiState   = uiState,
                inputText = inputText,
                onInputChange = { inputText = it },
                onSend    = {
                    if (inputText.isNotBlank()) {
                        viewModel.sendMessage(inputText)
                        inputText = ""
                    }
                },
                onModelsClick = onNavigateToModels
            )
        }

        // Error snackbar
        uiState.error?.let { error ->
            Snackbar(
                modifier         = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(JarvisSpacing.md),
                containerColor   = JarvisColors.CrimsonAlert.copy(alpha = 0.9f),
                contentColor     = JarvisColors.TextPrimary,
                action           = {
                    TextButton(onClick = { viewModel.clearError() }) {
                        Text("DISMISS", color = JarvisColors.TextPrimary)
                    }
                }
            ) {
                Text(error)
            }
        }
    }
}

// ── Top App Bar ───────────────────────────────────────────────────────────────

@Composable
private fun ChatTopBar(
    title: String,
    activeProvider: String,
    onSettingsClick: () -> Unit,
    onMemoryClick: () -> Unit,
    onClearClick: () -> Unit
) {
    Row(
        modifier              = Modifier
            .fillMaxWidth()
            .padding(horizontal = JarvisSpacing.md, vertical = JarvisSpacing.sm),
        verticalAlignment     = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(
                text          = "JARVIS",
                style         = MaterialTheme.typography.headlineMedium,
                color         = JarvisColors.CyanCore,
                letterSpacing = 6.sp,
                fontWeight    = FontWeight.W300
            )
            if (activeProvider.isNotBlank()) {
                Text(
                    text          = "via ${activeProvider.uppercase()}",
                    style         = MaterialTheme.typography.labelSmall,
                    color         = JarvisColors.TextMuted,
                    letterSpacing = 1.sp
                )
            } else {
                Text(
                    text          = title.take(24),
                    style         = MaterialTheme.typography.labelSmall,
                    color         = JarvisColors.TextMuted,
                    letterSpacing = 1.sp
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            IconButton(onClick = onMemoryClick) {
                Icon(
                    Icons.Default.Psychology,
                    contentDescription = "Memory",
                    tint               = JarvisColors.TextSecondary,
                    modifier           = Modifier.size(20.dp)
                )
            }
            IconButton(onClick = onClearClick) {
                Icon(
                    Icons.Default.DeleteOutline,
                    contentDescription = "Clear",
                    tint               = JarvisColors.TextMuted,
                    modifier           = Modifier.size(20.dp)
                )
            }
            IconButton(onClick = onSettingsClick) {
                Icon(
                    Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint               = JarvisColors.TextSecondary,
                    modifier           = Modifier.size(20.dp)
                )
            }
        }
    }
}

// ── Message Bubble ────────────────────────────────────────────────────────────

@Composable
fun MessageBubble(message: Message) {
    val isUser     = message.role == MessageRole.USER
    val isStreaming = message.status == MessageStatus.STREAMING
    val bubbleColor = if (isUser) JarvisColors.UserBubble else JarvisColors.JarvisBubble
    val borderColor = if (isUser) JarvisColors.UserBubbleBorder else JarvisColors.JarvisBubbleBorder

    Row(
        modifier              = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Column(
            modifier              = Modifier
                .widthIn(max = 320.dp)
                .clip(
                    RoundedCornerShape(
                        topStart    = if (isUser) 10.dp else 2.dp,
                        topEnd      = if (isUser) 2.dp else 10.dp,
                        bottomStart = 10.dp,
                        bottomEnd   = 10.dp
                    )
                )
                .background(bubbleColor)
                .border(
                    BorderStroke(0.5.dp, borderColor),
                    RoundedCornerShape(
                        topStart    = if (isUser) 10.dp else 2.dp,
                        topEnd      = if (isUser) 2.dp else 10.dp,
                        bottomStart = 10.dp,
                        bottomEnd   = 10.dp
                    )
                )
                .padding(horizontal = 12.dp, vertical = 9.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            if (!isUser) {
                Text(
                    text          = "JARVIS",
                    style         = MaterialTheme.typography.labelSmall,
                    color         = JarvisColors.CyanCore,
                    letterSpacing = 2.sp
                )
            }

            if (message.content.isNotBlank()) {
                Text(
                    text  = message.content,
                    style = MaterialTheme.typography.bodyMedium,
                    color = JarvisColors.TextPrimary
                )
            }

            if (isStreaming) {
                StreamingCursor()
            }

            // Meta info
            if (!isUser && message.provider.isNotBlank()) {
                Text(
                    text          = message.provider.uppercase(),
                    style         = MaterialTheme.typography.labelSmall,
                    color         = JarvisColors.TextMuted,
                    letterSpacing = 1.sp
                )
            }
        }
    }
}

@Composable
private fun StreamingCursor() {
    val alpha by rememberInfiniteTransition(label = "cursor").animateFloat(
        initialValue  = 0f,
        targetValue   = 1f,
        animationSpec = infiniteRepeatable(
            animation  = tween(500),
            repeatMode = RepeatMode.Reverse
        ),
        label = "cursorAlpha"
    )
    Canvas(Modifier.size(width = 8.dp, height = 14.dp)) {
        drawRect(JarvisColors.CyanCore.copy(alpha = alpha))
    }
}

// ── Thinking Bubble ───────────────────────────────────────────────────────────

@Composable
private fun ThinkingBubble(step: Int, activeTool: com.jarvis.assistant.brain.agent.AgentTool?) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
        HudFrame(
            modifier    = Modifier.widthIn(min = 140.dp, max = 280.dp),
            accentColor = JarvisColors.GoldAlert
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                ThinkingIndicator(color = JarvisColors.GoldAlert)
                activeTool?.let { tool ->
                    ToolBadge(toolName = tool.name, success = null)
                }
                if (step > 1) {
                    Text(
                        text   = "Step $step",
                        style  = MaterialTheme.typography.labelSmall,
                        color  = JarvisColors.TextMuted
                    )
                }
            }
        }
    }
}

// ── Tool Results Row ──────────────────────────────────────────────────────────

@Composable
private fun ToolResultsRow(results: List<com.jarvis.assistant.brain.agent.AgentTool.ToolResult>) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        results.forEach { result ->
            ToolBadge(
                toolName = "${result.tool.name}: ${result.output.take(40)}",
                success  = result.success
            )
        }
    }
}

// ── Bottom Input Section ──────────────────────────────────────────────────────

@Composable
private fun BottomInputSection(
    uiState: BrainUiState,
    inputText: String,
    onInputChange: (String) -> Unit,
    onSend: () -> Unit,
    onModelsClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(JarvisColors.SpaceBlack)
            .padding(JarvisSpacing.md),
        verticalArrangement = Arrangement.spacedBy(JarvisSpacing.sm)
    ) {
        Row(
            modifier              = Modifier.fillMaxWidth(),
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(JarvisSpacing.sm)
        ) {
            // Text Input
            OutlinedTextField(
                value         = inputText,
                onValueChange = onInputChange,
                modifier      = Modifier.weight(1f),
                placeholder   = {
                    Text(
                        text  = "Command JARVIS...",
                        color = JarvisColors.TextDisabled,
                        style = MaterialTheme.typography.bodyMedium
                    )
                },
                textStyle     = MaterialTheme.typography.bodyMedium.copy(
                    color = JarvisColors.TextPrimary
                ),
                singleLine    = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { onSend() }),
                colors        = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor   = JarvisColors.CyanCore.copy(alpha = 0.6f),
                    unfocusedBorderColor = JarvisColors.BorderNavy,
                    cursorColor          = JarvisColors.CyanCore,
                    focusedContainerColor   = JarvisColors.ElevatedNavy,
                    unfocusedContainerColor = JarvisColors.SurfaceNavy
                ),
                shape = RoundedCornerShape(4.dp)
            )

            // Send
            IconButton(
                onClick  = onSend,
                enabled  = inputText.isNotBlank() && !uiState.isLoading,
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(
                        if (inputText.isNotBlank())
                            JarvisColors.CyanCore.copy(alpha = 0.15f)
                        else
                            Color.Transparent
                    )
                    .border(
                        BorderStroke(0.5.dp, JarvisColors.CyanCore.copy(0.3f)),
                        RoundedCornerShape(4.dp)
                    )
            ) {
                if (uiState.isLoading) {
                    JarvisLoader(color = JarvisColors.CyanCore, size = 18.dp)
                } else {
                    Icon(
                        Icons.Default.Send,
                        contentDescription = "Send",
                        tint    = JarvisColors.CyanCore,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Model chip
        Row(
            modifier              = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment     = Alignment.CenterVertically
        ) {
            JarvisChip(
                text    = uiState.activeProvider.ifBlank { "AUTO" },
                color   = JarvisColors.CyanCore,
                onClick = onModelsClick
            )
            if (uiState.isThinking) {
                JarvisChip(
                    text  = "Step ${uiState.currentStep}",
                    color = JarvisColors.GoldAlert
                )
            }
        }
    }
}

// ── Empty State ───────────────────────────────────────────────────────────────

@Composable
private fun EmptyState(modifier: Modifier = Modifier) {
    Column(
        modifier              = modifier,
        verticalArrangement   = Arrangement.Center,
        horizontalAlignment   = Alignment.CenterHorizontally
    ) {
        ArcReactorOrb(size = 80.dp, voiceState = VoiceState.IDLE)
        Spacer(Modifier.height(JarvisSpacing.lg))
        Text(
            text          = "JARVIS",
            style         = MaterialTheme.typography.displayMedium,
            color         = JarvisColors.CyanCore,
            letterSpacing = 12.sp
        )
        Spacer(Modifier.height(JarvisSpacing.sm))
        Text(
            text          = "AI COMMAND CENTER",
            style         = MaterialTheme.typography.labelLarge,
            color         = JarvisColors.TextMuted,
            letterSpacing = 4.sp
        )
        Spacer(Modifier.height(JarvisSpacing.xl))
        Text(
            text      = "All systems online.\nAwaiting your command.",
            style     = MaterialTheme.typography.bodyMedium,
            color     = JarvisColors.TextSecondary,
            textAlign = TextAlign.Center
        )
    }
}

// ── Grid Background ───────────────────────────────────────────────────────────

@Composable
private fun GridBackground() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val gridSize = 40.dp.toPx()
        val color    = Color(0x04FFFFFF)
        var x = 0f
        while (x < size.width) {
            drawLine(color, Offset(x, 0f), Offset(x, size.height), 0.5f)
            x += gridSize
        }
        var y = 0f
        while (y < size.height) {
            drawLine(color, Offset(0f, y), Offset(size.width, y), 0.5f)
            y += gridSize
        }
    }
}
