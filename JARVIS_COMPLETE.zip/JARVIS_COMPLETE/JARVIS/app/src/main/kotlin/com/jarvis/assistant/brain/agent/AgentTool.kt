package com.jarvis.assistant.brain.agent

import com.jarvis.assistant.core.utils.CommandClassifier

// ══════════════════════════════════════════════════════════════════════════════
// AgentTool — every capability JARVIS can invoke autonomously
// ══════════════════════════════════════════════════════════════════════════════

sealed class AgentTool {

    abstract val name: String
    abstract val description: String
    abstract val parameters: Map<String, String>    // param name → description

    // ── Device Control ────────────────────────────────────────────────────────

    data class FlashlightTool(
        val enable: Boolean
    ) : AgentTool() {
        override val name        = "flashlight"
        override val description = "Turn the phone flashlight on or off"
        override val parameters  = mapOf("enable" to "true to turn on, false to turn off")
    }

    data class VolumeTool(
        val action: VolumeAction,
        val level: Int = -1
    ) : AgentTool() {
        override val name        = "volume"
        override val description = "Control device volume"
        override val parameters  = mapOf(
            "action" to "UP, DOWN, MUTE, or SET",
            "level"  to "0-15 for SET action"
        )
        enum class VolumeAction { UP, DOWN, MUTE, SET }
    }

    data class BluetoothTool(val enable: Boolean) : AgentTool() {
        override val name        = "bluetooth"
        override val description = "Toggle Bluetooth on or off"
        override val parameters  = mapOf("enable" to "true or false")
    }

    object WifiSettingsTool : AgentTool() {
        override val name        = "wifi_settings"
        override val description = "Open WiFi settings panel"
        override val parameters  = emptyMap<String, String>()
    }

    data class BrightnessTool(val level: Int) : AgentTool() {
        override val name        = "brightness"
        override val description = "Set screen brightness (0-255)"
        override val parameters  = mapOf("level" to "0-255")
    }

    data class DoNotDisturbTool(val enable: Boolean) : AgentTool() {
        override val name        = "dnd"
        override val description = "Toggle Do Not Disturb mode"
        override val parameters  = mapOf("enable" to "true or false")
    }

    // ── App Launch ────────────────────────────────────────────────────────────

    data class LaunchAppTool(
        val packageName: String,
        val appName: String
    ) : AgentTool() {
        override val name        = "launch_app"
        override val description = "Launch an installed application"
        override val parameters  = mapOf(
            "packageName" to "App package name",
            "appName"     to "Human readable app name"
        )
    }

    data class OpenUrlTool(val url: String) : AgentTool() {
        override val name        = "open_url"
        override val description = "Open a URL in the browser"
        override val parameters  = mapOf("url" to "Full URL to open")
    }

    // ── Communication ─────────────────────────────────────────────────────────

    data class SendSmsTool(
        val contactName: String,
        val phoneNumber: String,
        val message: String
    ) : AgentTool() {
        override val name        = "send_sms"
        override val description = "Send an SMS message to a contact"
        override val parameters  = mapOf(
            "contactName" to "Name of the contact",
            "phoneNumber" to "Phone number",
            "message"     to "Message text"
        )
    }

    data class CallContactTool(
        val contactName: String,
        val phoneNumber: String
    ) : AgentTool() {
        override val name        = "call_contact"
        override val description = "Make a phone call to a contact"
        override val parameters  = mapOf(
            "contactName" to "Name of the contact",
            "phoneNumber" to "Phone number to call"
        )
    }

    data class SendWhatsAppTool(
        val contactName: String,
        val message: String
    ) : AgentTool() {
        override val name        = "send_whatsapp"
        override val description = "Send a WhatsApp message"
        override val parameters  = mapOf(
            "contactName" to "Name of the contact",
            "message"     to "Message text"
        )
    }

    // ── Navigation ────────────────────────────────────────────────────────────

    data class NavigateTool(
        val destination: String,
        val mode: NavigationMode = NavigationMode.DRIVING
    ) : AgentTool() {
        override val name        = "navigate"
        override val description = "Open navigation to a destination"
        override val parameters  = mapOf(
            "destination" to "Address or place name",
            "mode"        to "DRIVING, WALKING, or TRANSIT"
        )
        enum class NavigationMode { DRIVING, WALKING, TRANSIT }
    }

    // ── Web / Search ──────────────────────────────────────────────────────────

    data class WebSearchTool(val query: String) : AgentTool() {
        override val name        = "web_search"
        override val description = "Search the web for information"
        override val parameters  = mapOf("query" to "Search query string")
    }

    data class YouTubeSearchTool(val query: String) : AgentTool() {
        override val name        = "youtube_search"
        override val description = "Search YouTube for a video"
        override val parameters  = mapOf("query" to "Search query")
    }

    // ── System ────────────────────────────────────────────────────────────────

    data class SetAlarmTool(
        val hour: Int,
        val minute: Int,
        val label: String = "JARVIS Alarm"
    ) : AgentTool() {
        override val name        = "set_alarm"
        override val description = "Set an alarm at a specific time"
        override val parameters  = mapOf(
            "hour"   to "Hour in 24h format",
            "minute" to "Minute",
            "label"  to "Alarm label"
        )
    }

    data class SetTimerTool(
        val durationSeconds: Int,
        val label: String = "JARVIS Timer"
    ) : AgentTool() {
        override val name        = "set_timer"
        override val description = "Set a countdown timer"
        override val parameters  = mapOf(
            "durationSeconds" to "Duration in seconds",
            "label"           to "Timer label"
        )
    }

    object TakeScreenshotTool : AgentTool() {
        override val name        = "take_screenshot"
        override val description = "Take a screenshot of the current screen"
        override val parameters  = emptyMap<String, String>()
    }

    object ReadScreenTool : AgentTool() {
        override val name        = "read_screen"
        override val description = "Read all visible text on screen"
        override val parameters  = emptyMap<String, String>()
    }

    // ── Memory ────────────────────────────────────────────────────────────────

    data class SaveMemoryTool(
        val content: String,
        val type: String = "GENERAL"
    ) : AgentTool() {
        override val name        = "save_memory"
        override val description = "Save a fact or preference to long-term memory"
        override val parameters  = mapOf(
            "content" to "The information to remember",
            "type"    to "FACT, PREFERENCE, HABIT, RELATIONSHIP, EVENT, or GENERAL"
        )
    }

    data class RecallMemoryTool(val query: String) : AgentTool() {
        override val name        = "recall_memory"
        override val description = "Search long-term memory for relevant information"
        override val parameters  = mapOf("query" to "What to search for in memory")
    }

    // ── Compose-and-Send ──────────────────────────────────────────────────────

    data class AiSubtaskTool(
        val subtask: String,
        val context: String = ""
    ) : AgentTool() {
        override val name        = "ai_subtask"
        override val description = "Delegate a complex subtask to an AI sub-agent"
        override val parameters  = mapOf(
            "subtask" to "The task to complete",
            "context" to "Relevant context for the subtask"
        )
    }

    // ── Tool Result ───────────────────────────────────────────────────────────

    data class ToolResult(
        val tool: AgentTool,
        val success: Boolean,
        val output: String,
        val durationMs: Long = 0
    )
}
