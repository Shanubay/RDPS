package com.jarvis.assistant.core.di

import android.content.Context
import com.jarvis.assistant.brain.ContextBuilder
import com.jarvis.assistant.brain.ConversationSummarizer
import com.jarvis.assistant.brain.JarvisBrain
import com.jarvis.assistant.brain.RoutineEngine
import com.jarvis.assistant.brain.agent.ToolExecutor
import com.jarvis.assistant.brain.agent.ToolParser
import com.jarvis.assistant.core.utils.AppPreferences
import com.jarvis.assistant.core.utils.BatteryUtils
import com.jarvis.assistant.core.utils.TimeUtils
import com.jarvis.assistant.data.local.JarvisDatabase
import com.jarvis.assistant.data.remote.AIRouter
import com.jarvis.assistant.domain.repository.ChatRepository
import com.jarvis.assistant.domain.repository.RoutineRepository
import com.jarvis.assistant.domain.usecase.ManageMemoryUseCase
import com.google.gson.Gson
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object BrainModule {

    @Provides @Singleton
    fun provideToolParser(gson: Gson) = ToolParser(gson)

    @Provides @Singleton
    fun provideToolExecutor(
        @ApplicationContext context: Context,
        manageMemory: ManageMemoryUseCase
    ) = ToolExecutor(context, manageMemory)

    @Provides @Singleton
    fun provideJarvisBrain(
        aiRouter: AIRouter,
        toolParser: ToolParser,
        toolExecutor: ToolExecutor,
        manageMemory: ManageMemoryUseCase,
        prefs: AppPreferences
    ) = JarvisBrain(aiRouter, toolParser, toolExecutor, manageMemory, prefs)

    @Provides @Singleton
    fun provideConversationSummarizer(
        aiRouter: AIRouter,
        chatRepository: ChatRepository
    ) = ConversationSummarizer(aiRouter, chatRepository)

    @Provides @Singleton
    fun provideContextBuilder(
        manageMemory: ManageMemoryUseCase,
        summarizer: ConversationSummarizer,
        db: JarvisDatabase,
        prefs: AppPreferences,
        batteryUtils: BatteryUtils,
        timeUtils: TimeUtils
    ) = ContextBuilder(manageMemory, summarizer, db, prefs, batteryUtils, timeUtils)

    @Provides @Singleton
    fun provideRoutineEngine(
        @ApplicationContext context: Context,
        routineRepository: RoutineRepository,
        toolExecutor: ToolExecutor,
        timeUtils: TimeUtils
    ) = RoutineEngine(context, routineRepository, toolExecutor, timeUtils)
}
