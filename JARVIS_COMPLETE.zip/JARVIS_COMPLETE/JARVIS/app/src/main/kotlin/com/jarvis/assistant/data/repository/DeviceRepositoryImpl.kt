package com.jarvis.assistant.data.repository

import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.hardware.camera2.CameraManager
import com.jarvis.assistant.data.local.JarvisDatabase
import com.jarvis.assistant.data.local.toDomain
import com.jarvis.assistant.domain.entities.AppNotification
import com.jarvis.assistant.domain.entities.DeviceState
import com.jarvis.assistant.domain.repository.AppInfo
import com.jarvis.assistant.domain.repository.DeviceRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DeviceRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context,
    private val db: JarvisDatabase
) : DeviceRepository {

    private val audioManager      by lazy { context.getSystemService(AudioManager::class.java) }
    private val bluetoothManager  by lazy { context.getSystemService(BluetoothManager::class.java) }
    private val wifiManager       by lazy { context.applicationContext.getSystemService(WifiManager::class.java) }

    override fun getDeviceState(): Flow<DeviceState> = flow {
        val state = DeviceState(
            isWifiEnabled      = wifiManager?.isWifiEnabled ?: false,
            isBluetoothEnabled = bluetoothManager?.adapter?.isEnabled ?: false,
            isFlashlightOn     = false,
            volumeLevel        = audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 0,
            maxVolume          = audioManager?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: 15,
            batteryLevel       = 100,
            isCharging         = false,
            isDoNotDisturb     = false,
            brightnessLevel    = 128,
            currentApp         = getForegroundApp() ?: ""
        )
        emit(state)
    }

    override suspend fun setWifi(enabled: Boolean): Boolean {
        return try {
            @Suppress("DEPRECATION")
            wifiManager?.isWifiEnabled = enabled
            true
        } catch (e: Exception) { false }
    }

    override suspend fun setBluetooth(enabled: Boolean): Boolean {
        return try {
            val adapter = bluetoothManager?.adapter ?: return false
            if (enabled) adapter.enable() else adapter.disable()
            true
        } catch (e: Exception) { false }
    }

    override suspend fun setFlashlight(enabled: Boolean): Boolean {
        return try {
            val cameraManager = context.getSystemService(CameraManager::class.java)
            val cameraId = cameraManager?.cameraIdList?.firstOrNull() ?: return false
            cameraManager.setTorchMode(cameraId, enabled)
            true
        } catch (e: Exception) { false }
    }

    override suspend fun setVolume(level: Int): Boolean {
        return try {
            audioManager?.setStreamVolume(
                AudioManager.STREAM_MUSIC, level, AudioManager.FLAG_SHOW_UI
            )
            true
        } catch (e: Exception) { false }
    }

    override suspend fun adjustVolume(delta: Int): Int {
        val current = audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 0
        val max     = audioManager?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: 15
        val target  = (current + delta).coerceIn(0, max)
        audioManager?.setStreamVolume(AudioManager.STREAM_MUSIC, target, AudioManager.FLAG_SHOW_UI)
        return target
    }

    override suspend fun getInstalledApps(): List<AppInfo> {
        val pm = context.packageManager
        return pm.getInstalledPackages(PackageManager.GET_META_DATA)
            .filter { pkg -> pm.getLaunchIntentForPackage(pkg.packageName) != null }
            .map { pkg ->
                AppInfo(
                    packageName = pkg.packageName,
                    label       = pm.getApplicationLabel(pkg.applicationInfo).toString()
                )
            }
            .sortedBy { it.label }
    }

    override fun getNotifications(): Flow<List<AppNotification>> =
        db.notificationDao().getAllNotifications()
            .map { list -> list.map { it.toDomain() } }

    override suspend fun takeScreenshot(): Result<String> =
        Result.failure(Exception("Screenshot requires MediaProjection permission — request from UI"))

    override suspend fun getForegroundApp(): String? {
        return try {
            val usm = context.getSystemService(UsageStatsManager::class.java)
            val now = System.currentTimeMillis()
            val stats = usm?.queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY,
                now - 10_000,
                now
            )
            stats?.maxByOrNull { it.lastTimeUsed }?.packageName
        } catch (e: Exception) { null }
    }
}
