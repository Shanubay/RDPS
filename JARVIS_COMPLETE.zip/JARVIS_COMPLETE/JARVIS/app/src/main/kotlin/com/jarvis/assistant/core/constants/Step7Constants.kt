package com.jarvis.assistant.core.constants

// ══════════════════════════════════════════════════════════════════════════════
// AppConstants extensions — Step 7 additions
// Append these into the existing AppConstants object
// ══════════════════════════════════════════════════════════════════════════════

// Add to AppConstants object in AppConstants.kt:

object Step7Constants {

    // Broadcast / Intent actions
    object Actions {
        const val WAKE_WORD_DETECTED       = "com.jarvis.assistant.WAKE_WORD_DETECTED"
        const val START_LISTENING          = "com.jarvis.assistant.START_LISTENING"
        const val STOP_LISTENING           = "com.jarvis.assistant.STOP_LISTENING"
        const val STOP_WAKE_WORD           = "com.jarvis.assistant.STOP_WAKE_WORD"
        const val SHOW_OVERLAY             = "com.jarvis.assistant.SHOW_OVERLAY"
        const val HIDE_OVERLAY             = "com.jarvis.assistant.HIDE_OVERLAY"
        const val TOGGLE_OVERLAY           = "com.jarvis.assistant.TOGGLE_OVERLAY"
        const val DEVICE_TOGGLE_FLASHLIGHT = "com.jarvis.assistant.DEVICE_TOGGLE_FLASHLIGHT"
        const val DEVICE_SET_VOLUME        = "com.jarvis.assistant.DEVICE_SET_VOLUME"
    }

    // TTS providers
    object TTSProvider {
        const val ANDROID_TTS  = "android_tts"
        const val ELEVENLABS   = "elevenlabs"
    }

    // TTS parameters
    const val TTS_DEFAULT_SPEED  = 1.0f
    const val TTS_DEFAULT_PITCH  = 1.0f
    const val TTS_WHISPER_SPEED  = 0.75f
    const val TTS_WHISPER_PITCH  = 0.9f

    // ElevenLabs
    const val ELEVENLABS_DEFAULT_VOICE = "pNInz6obpgDQGcFmaJgB"  // Adam voice

    // STT
    const val STT_SILENCE_THRESHOLD_MS = 1500L

    // Token routing thresholds
    const val TOKEN_THRESHOLD_FAST    = 150
    const val TOKEN_THRESHOLD_COMPLEX = 800

    // Notification IDs
    const val NOTIFICATION_ID_VOICE   = 1001
    const val NOTIFICATION_ID_OVERLAY = 1002
    const val NOTIFICATION_ID_AI      = 1003
    const val NOTIFICATION_ID_DEVICE  = 1004
}

// ── ModelInfo data class (referenced by ModelRepositoryImpl) ──────────────────

data class ModelInfo(
    val id: String,
    val name: String,
    val description: String,
    val url: String,
    val sizeBytes: Long,
    val ramRequired: String
)
