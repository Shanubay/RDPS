package com.jarvis.assistant.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ══════════════════════════════════════════════════════════════════════════════
// JARVIS Design System — Iron Man HUD Aesthetic
// Deep space black + electric cyan + gold alert + crimson error
// ══════════════════════════════════════════════════════════════════════════════

// ── Palette ───────────────────────────────────────────────────────────────────

object JarvisColors {
    // Primary — electric cyan (Arc Reactor blue)
    val CyanCore        = Color(0xFF00D4FF)
    val CyanBright      = Color(0xFF33DFFF)
    val CyanDim         = Color(0xFF0099CC)
    val CyanGlow        = Color(0x4400D4FF)    // translucent for glow effects
    val CyanSubtle      = Color(0x1A00D4FF)

    // Gold — stark/warning tone
    val GoldAlert       = Color(0xFFFFB800)
    val GoldDim         = Color(0xFFCC9400)
    val GoldGlow        = Color(0x44FFB800)

    // Crimson — error / danger
    val CrimsonAlert    = Color(0xFFFF3B30)
    val CrimsonGlow     = Color(0x44FF3B30)

    // Green — success
    val GreenOnline     = Color(0xFF00FF88)
    val GreenDim        = Color(0xFF00CC66)

    // Backgrounds — deep space
    val VoidBlack       = Color(0xFF030508)
    val SpaceBlack      = Color(0xFF070B10)
    val DeepNavy        = Color(0xFF0A0F1A)
    val SurfaceNavy     = Color(0xFF0D1421)
    val ElevatedNavy    = Color(0xFF111926)
    val CardNavy        = Color(0xFF141E2E)
    val BorderNavy      = Color(0xFF1C2A3E)

    // Text
    val TextPrimary     = Color(0xFFE8F4FF)
    val TextSecondary   = Color(0xFF7FA8CC)
    val TextMuted       = Color(0xFF3D5A7A)
    val TextDisabled    = Color(0xFF1E3050)

    // User bubble
    val UserBubble      = Color(0xFF0A1628)
    val UserBubbleBorder = Color(0xFF1A3A5C)
    val JarvisBubble    = Color(0xFF080E1A)
    val JarvisBubbleBorder = Color(0xFF0F2040)
}

// ── Dark Color Scheme ─────────────────────────────────────────────────────────

private val JarvisDarkColorScheme = darkColorScheme(
    primary          = JarvisColors.CyanCore,
    onPrimary        = JarvisColors.VoidBlack,
    primaryContainer = JarvisColors.CyanSubtle,
    onPrimaryContainer = JarvisColors.CyanBright,

    secondary        = JarvisColors.GoldAlert,
    onSecondary      = JarvisColors.VoidBlack,
    secondaryContainer = JarvisColors.GoldGlow,
    onSecondaryContainer = JarvisColors.GoldAlert,

    tertiary         = JarvisColors.GreenOnline,
    onTertiary       = JarvisColors.VoidBlack,

    error            = JarvisColors.CrimsonAlert,
    onError          = JarvisColors.TextPrimary,
    errorContainer   = JarvisColors.CrimsonGlow,

    background       = JarvisColors.VoidBlack,
    onBackground     = JarvisColors.TextPrimary,

    surface          = JarvisColors.SpaceBlack,
    onSurface        = JarvisColors.TextPrimary,
    surfaceVariant   = JarvisColors.SurfaceNavy,
    onSurfaceVariant = JarvisColors.TextSecondary,

    outline          = JarvisColors.BorderNavy,
    outlineVariant   = JarvisColors.TextMuted,

    inverseSurface   = JarvisColors.TextPrimary,
    inverseOnSurface = JarvisColors.VoidBlack,
)

// ── Typography ────────────────────────────────────────────────────────────────
// Uses system fonts — Rajdhani/Exo feel via weight/tracking manipulation

val JarvisTypography = Typography(
    displayLarge = TextStyle(
        fontWeight   = FontWeight.W300,
        fontSize     = 48.sp,
        lineHeight   = 52.sp,
        letterSpacing = (-0.5).sp
    ),
    displayMedium = TextStyle(
        fontWeight   = FontWeight.W300,
        fontSize     = 36.sp,
        lineHeight   = 40.sp,
        letterSpacing = 2.sp
    ),
    headlineLarge = TextStyle(
        fontWeight   = FontWeight.W600,
        fontSize     = 28.sp,
        lineHeight   = 32.sp,
        letterSpacing = 3.sp
    ),
    headlineMedium = TextStyle(
        fontWeight   = FontWeight.W500,
        fontSize     = 22.sp,
        lineHeight   = 26.sp,
        letterSpacing = 2.sp
    ),
    titleLarge = TextStyle(
        fontWeight   = FontWeight.W600,
        fontSize     = 18.sp,
        lineHeight   = 22.sp,
        letterSpacing = 1.5.sp
    ),
    titleMedium = TextStyle(
        fontWeight   = FontWeight.W500,
        fontSize     = 15.sp,
        lineHeight   = 20.sp,
        letterSpacing = 1.sp
    ),
    titleSmall = TextStyle(
        fontWeight   = FontWeight.W600,
        fontSize     = 12.sp,
        lineHeight   = 16.sp,
        letterSpacing = 2.sp
    ),
    bodyLarge = TextStyle(
        fontWeight   = FontWeight.W400,
        fontSize     = 15.sp,
        lineHeight   = 22.sp,
        letterSpacing = 0.15.sp
    ),
    bodyMedium = TextStyle(
        fontWeight   = FontWeight.W400,
        fontSize     = 13.sp,
        lineHeight   = 20.sp,
        letterSpacing = 0.1.sp
    ),
    bodySmall = TextStyle(
        fontWeight   = FontWeight.W400,
        fontSize     = 11.sp,
        lineHeight   = 16.sp,
        letterSpacing = 0.4.sp
    ),
    labelLarge = TextStyle(
        fontWeight   = FontWeight.W600,
        fontSize     = 12.sp,
        lineHeight   = 16.sp,
        letterSpacing = 1.5.sp
    ),
    labelSmall = TextStyle(
        fontWeight   = FontWeight.W500,
        fontSize     = 10.sp,
        lineHeight   = 14.sp,
        letterSpacing = 1.5.sp
    )
)

// ── Shapes ────────────────────────────────────────────────────────────────────

val JarvisShapes = Shapes(
    extraSmall = androidx.compose.foundation.shape.RoundedCornerShape(3.dp),
    small      = androidx.compose.foundation.shape.RoundedCornerShape(4.dp),
    medium     = androidx.compose.foundation.shape.RoundedCornerShape(6.dp),
    large      = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
    extraLarge = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
)

// ── Spacing ───────────────────────────────────────────────────────────────────

object JarvisSpacing {
    val xs: Dp  = 4.dp
    val sm: Dp  = 8.dp
    val md: Dp  = 16.dp
    val lg: Dp  = 24.dp
    val xl: Dp  = 32.dp
    val xxl: Dp = 48.dp
}

// ── Elevation (as glow intensity) ─────────────────────────────────────────────

object JarvisElevation {
    val none: Dp   = 0.dp
    val low: Dp    = 1.dp
    val medium: Dp = 4.dp
    val high: Dp   = 8.dp
    val overlay: Dp = 12.dp
}

// ── Theme ─────────────────────────────────────────────────────────────────────

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = JarvisDarkColorScheme,
        typography  = JarvisTypography,
        shapes      = JarvisShapes,
        content     = content
    )
}
