package com.jarvis.assistant.core.utils

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import dagger.hilt.android.qualifiers.ApplicationContext
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton

// ══════════════════════════════════════════════════════════════════════════════
// TimeUtils — time-aware greeting and formatting helpers
// ══════════════════════════════════════════════════════════════════════════════

@Singleton
class TimeUtils @Inject constructor() {

    private val fullFmt    = SimpleDateFormat("HH:mm, EEEE d MMMM yyyy", Locale.ENGLISH)
    private val shortFmt   = SimpleDateFormat("HH:mm", Locale.ENGLISH)

    val fullDateTimeString: String
        get() = fullFmt.format(Date())

    val shortTimeString: String
        get() = shortFmt.format(Date())

    val currentHour: Int
        get() = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)

    val greeting: String
        get() = when (currentHour) {
            in 5..11  -> "Good morning"
            in 12..16 -> "Good afternoon"
            in 17..20 -> "Good evening"
            else      -> "Good evening"
        }

    val greetingWithPersonality: String
        get() = when (currentHour) {
            in 5..11  -> "Good morning. All systems online. How may I assist?"
            in 12..16 -> "Good afternoon. What do you need?"
            in 17..20 -> "Good evening. Ready when you are."
            else      -> "Still awake? Ready when you are."
        }

    val isNight: Boolean     get() = currentHour < 6 || currentHour >= 22
    val isMorning: Boolean   get() = currentHour in 6..11
    val isAfternoon: Boolean get() = currentHour in 12..17
    val isEvening: Boolean   get() = currentHour in 18..21
}

// ══════════════════════════════════════════════════════════════════════════════
// BatteryUtils — battery level + power mode detection
// ══════════════════════════════════════════════════════════════════════════════

@Singleton
class BatteryUtils @Inject constructor(
    @ApplicationContext private val context: Context
) {

    enum class PowerMode { NORMAL, BATTERY_SAVING, CRITICAL, CHARGING }

    val batteryLevel: Int
        get() {
            val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val intent = context.registerReceiver(null, filter) ?: return 100
            val level  = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 100)
            val scale  = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            return (level * 100 / scale.toFloat()).toInt()
        }

    val isCharging: Boolean
        get() {
            val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val intent = context.registerReceiver(null, filter) ?: return false
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            return status == BatteryManager.BATTERY_STATUS_CHARGING ||
                   status == BatteryManager.BATTERY_STATUS_FULL
        }

    val powerMode: PowerMode
        get() = when {
            isCharging       -> PowerMode.CHARGING
            batteryLevel < 10 -> PowerMode.CRITICAL
            batteryLevel < 20 -> PowerMode.BATTERY_SAVING
            else              -> PowerMode.NORMAL
        }

    val isBatteryCritical: Boolean
        get() = batteryLevel < 10 && !isCharging

    val isBatterySaving: Boolean
        get() = batteryLevel < 20 && !isCharging
}

// ══════════════════════════════════════════════════════════════════════════════
// NetworkUtils — connection state helper
// ══════════════════════════════════════════════════════════════════════════════

@Singleton
class NetworkUtils @Inject constructor(
    @ApplicationContext private val context: Context
) {

    val isConnected: Boolean
        get() {
            val cm = context.getSystemService(android.net.ConnectivityManager::class.java)
            val net = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(net) ?: return false
            return caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                   caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        }

    val isWifi: Boolean
        get() {
            val cm = context.getSystemService(android.net.ConnectivityManager::class.java)
            val net = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(net) ?: return false
            return caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)
        }

    val connectionType: String
        get() {
            val cm = context.getSystemService(android.net.ConnectivityManager::class.java)
            val net = cm.activeNetwork ?: return "NONE"
            val caps = cm.getNetworkCapabilities(net) ?: return "NONE"
            return when {
                caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)     -> "WIFI"
                caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR) -> "CELLULAR"
                caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET) -> "ETHERNET"
                else -> "UNKNOWN"
            }
        }
}
