package com.jarvis.assistant.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.domain.entities.AppNotification
import com.jarvis.assistant.domain.entities.DeviceState
import com.jarvis.assistant.domain.repository.DeviceRepository
import com.jarvis.assistant.domain.usecase.DeviceControlUseCase
import com.jarvis.assistant.service.accessibility.JarvisAccessibilityService
import com.jarvis.assistant.service.device.DeviceControlService
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class DeviceControlUiState(
    val deviceState: DeviceState         = DeviceState(),
    val notifications: List<AppNotification> = emptyList(),
    val installedApps: List<com.jarvis.assistant.domain.repository.AppInfo> = emptyList(),
    val screenText: String               = "",
    val isAccessibilityEnabled: Boolean  = false,
    val lastAction: String               = "",
    val error: String?                   = null
)

@HiltViewModel
class DeviceControlViewModel @Inject constructor(
    private val deviceControlUseCase: DeviceControlUseCase,
    private val deviceRepository: DeviceRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(DeviceControlUiState())
    val uiState: StateFlow<DeviceControlUiState> = _uiState.asStateFlow()

    // Bound service reference (set from Activity)
    var deviceService: DeviceControlService? = null

    init {
        observeDeviceState()
        observeNotifications()
        observeAccessibility()
    }

    private fun observeDeviceState() {
        viewModelScope.launch {
            deviceControlUseCase.getDeviceState().collect { state ->
                _uiState.update { it.copy(deviceState = state) }
            }
        }
    }

    private fun observeNotifications() {
        viewModelScope.launch {
            deviceControlUseCase.getNotifications().collect { notifs ->
                _uiState.update { it.copy(notifications = notifs) }
            }
        }
    }

    private fun observeAccessibility() {
        viewModelScope.launch {
            JarvisAccessibilityService.isConnected.collect { connected ->
                _uiState.update { it.copy(isAccessibilityEnabled = connected) }
            }
        }
    }

    // ── Hardware Controls ─────────────────────────────────────────────────────

    fun toggleFlashlight() {
        deviceService?.toggleFlashlight()
        _uiState.update { it.copy(lastAction = "Flashlight toggled") }
    }

    fun setVolume(level: Int) {
        deviceService?.setVolume(level)
        _uiState.update { it.copy(lastAction = "Volume set to $level") }
    }

    fun volumeUp()   { deviceService?.adjustVolume(android.media.AudioManager.ADJUST_RAISE) }
    fun volumeDown() { deviceService?.adjustVolume(android.media.AudioManager.ADJUST_LOWER) }
    fun muteVolume() { deviceService?.muteVolume() }

    fun setBluetooth(enable: Boolean) {
        deviceService?.setBluetooth(enable)
        _uiState.update { it.copy(lastAction = "Bluetooth ${if (enable) "on" else "off"}") }
    }

    fun openWifiSettings() {
        deviceService?.openWifiSettings()
        _uiState.update { it.copy(lastAction = "WiFi settings opened") }
    }

    fun setBrightness(level: Int) {
        deviceService?.setBrightness(level)
        _uiState.update { it.copy(lastAction = "Brightness set to $level") }
    }

    fun setDoNotDisturb(enable: Boolean) {
        deviceService?.setDoNotDisturb(enable)
        _uiState.update { it.copy(lastAction = "DND ${if (enable) "on" else "off"}") }
    }

    // ── Navigation ────────────────────────────────────────────────────────────

    fun goHome()    { deviceService?.goHome() }
    fun goBack()    { deviceService?.goBack() }
    fun goRecents() { deviceService?.goRecents() }

    // ── Screen Reading ────────────────────────────────────────────────────────

    fun readScreen() {
        val text = deviceService?.readScreen() ?: "Accessibility service not enabled"
        _uiState.update { it.copy(screenText = text) }
    }

    // ── Apps ──────────────────────────────────────────────────────────────────

    fun loadInstalledApps() {
        viewModelScope.launch {
            val apps = deviceControlUseCase.getInstalledApps()
            _uiState.update { it.copy(installedApps = apps) }
        }
    }

    // ── Voice Command Dispatch ────────────────────────────────────────────────

    fun executeVoiceCommand(command: String) {
        viewModelScope.launch {
            val classified = com.jarvis.assistant.core.utils.CommandClassifier()
                .classify(command)
            val result = deviceControlUseCase.executeCommand(classified.type, command)
            val msg = when (result) {
                is DeviceControlUseCase.DeviceResult.Success -> result.message
                is DeviceControlUseCase.DeviceResult.Failed  -> "Failed: ${result.reason}"
                is DeviceControlUseCase.DeviceResult.StateChanged -> "State updated"
            }
            _uiState.update { it.copy(lastAction = msg) }
        }
    }

    fun clearError()  = _uiState.update { it.copy(error = null) }
}
