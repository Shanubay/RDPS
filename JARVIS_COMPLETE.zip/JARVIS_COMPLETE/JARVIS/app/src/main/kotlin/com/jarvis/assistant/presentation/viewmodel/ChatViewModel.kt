package com.jarvis.assistant.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.core.utils.AppPreferences
import com.jarvis.assistant.domain.entities.*
import com.jarvis.assistant.domain.usecase.*
import com.jarvis.assistant.service.voice.VoiceOrchestrator
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ChatViewModel @Inject constructor(
    private val sendMessage: SendMessageUseCase,
    private val getConversation: GetConversationUseCase,
    private val manageMemory: ManageMemoryUseCase,
    private val voiceOrchestrator: VoiceOrchestrator,
    private val appPreferences: AppPreferences
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    private var activeConversationId = ""

    // ── Combine voice orchestrator state into UI ──────────────────────────────

    init {
        viewModelScope.launch {
            combine(
                voiceOrchestrator.voiceState,
                voiceOrchestrator.amplitude,
                voiceOrchestrator.waveform,
                voiceOrchestrator.error
            ) { voiceState, amplitude, waveform, error ->
                _uiState.update { it.copy(
                    voiceState = voiceState,
                    amplitude  = amplitude,
                    waveform   = waveform,
                    error      = error
                )}
            }.collect()
        }

        // Stream partial transcript into input field
        viewModelScope.launch {
            voiceOrchestrator.partialText.collect { partial ->
                if (partial.isNotBlank()) {
                    _uiState.update { it.copy(inputText = partial) }
                }
            }
        }

        // Handle confirmed transcript
        viewModelScope.launch {
            voiceOrchestrator.transcript.collect { transcript ->
                if (transcript.isNotBlank()) {
                    _uiState.update { it.copy(inputText = transcript) }
                }
            }
        }

        // Stream AI response tokens into the last message
        viewModelScope.launch {
            voiceOrchestrator.responseText.collect { text ->
                if (text.isNotBlank()) {
                    _uiState.update { it.copy(streamingText = text) }
                }
            }
        }

        initConversation()
    }

    private fun initConversation() {
        viewModelScope.launch {
            val conv = getConversation.getOrCreateActiveConversation()
            activeConversationId = conv.id
            voiceOrchestrator.setConversationId(conv.id)
            loadMessages()
        }
    }

    private fun loadMessages() {
        viewModelScope.launch {
            getConversation.getMessages(activeConversationId).collect { messages ->
                _uiState.update { it.copy(messages = messages) }
            }
        }
    }

    // ── Text Message Send ─────────────────────────────────────────────────────

    fun sendTextMessage(text: String) {
        if (text.isBlank() || _uiState.value.isLoading) return

        _uiState.update { it.copy(
            inputText     = "",
            isLoading     = true,
            streamingText = "",
            error         = null
        )}

        viewModelScope.launch {
            // Optimistically add user message to UI
            val userMsg = Message(role = MessageRole.USER, content = text)
            _uiState.update { state ->
                state.copy(messages = state.messages + userMsg)
            }

            val streamingMsg = Message(
                role    = MessageRole.ASSISTANT,
                content = "",
                status  = MessageStatus.STREAMING
            )
            _uiState.update { state ->
                state.copy(messages = state.messages + streamingMsg)
            }

            val responseBuilder = StringBuilder()

            sendMessage(text, activeConversationId).collect { result ->
                when (result) {
                    is SendMessageUseCase.StreamResult.Loading -> {
                        _uiState.update { it.copy(isLoading = true) }
                    }
                    is SendMessageUseCase.StreamResult.Token -> {
                        responseBuilder.append(result.text)
                        // Update the streaming message in the list
                        _uiState.update { state ->
                            state.copy(
                                messages = state.messages.dropLast(1) + streamingMsg.copy(
                                    content = responseBuilder.toString()
                                ),
                                streamingText = responseBuilder.toString()
                            )
                        }
                    }
                    is SendMessageUseCase.StreamResult.Complete -> {
                        // Finalize message
                        _uiState.update { state ->
                            state.copy(
                                messages = state.messages.dropLast(1) + Message(
                                    role     = MessageRole.ASSISTANT,
                                    content  = result.fullText,
                                    provider = result.provider,
                                    status   = MessageStatus.SENT
                                ),
                                isLoading      = false,
                                streamingText  = "",
                                activeProvider = result.provider
                            )
                        }
                        // Extract memories in background
                        manageMemory.extractAndSave(text, result.fullText)
                    }
                    is SendMessageUseCase.StreamResult.Error -> {
                        _uiState.update { it.copy(
                            isLoading = false,
                            error     = result.message,
                            messages  = it.messages.dropLast(1)
                        )}
                    }
                }
            }
        }
    }

    // ── Voice Control ─────────────────────────────────────────────────────────

    fun startVoiceInput() = voiceOrchestrator.startListening()
    fun stopVoiceInput()  = voiceOrchestrator.stopListening()
    fun stopSpeaking()    = voiceOrchestrator.stopSpeaking()

    // ── UI Events ─────────────────────────────────────────────────────────────

    fun updateInputText(text: String) = _uiState.update { it.copy(inputText = text) }
    fun clearError()                  = _uiState.update { it.copy(error = null) }

    fun clearConversation() {
        viewModelScope.launch {
            getConversation.deleteConversation(activeConversationId)
            val newConv = getConversation.createConversation("New Conversation")
            activeConversationId = newConv.id
            voiceOrchestrator.setConversationId(newConv.id)
            _uiState.update { it.copy(messages = emptyList()) }
        }
    }

    fun getGreeting() = voiceOrchestrator.getGreeting()

    override fun onCleared() {
        super.onCleared()
    }
}
