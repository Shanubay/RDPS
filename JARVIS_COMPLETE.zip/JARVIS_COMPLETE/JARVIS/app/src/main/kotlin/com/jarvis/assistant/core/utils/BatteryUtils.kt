package com.jarvis.assistant.core.utils

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * BatteryUtils — Provides battery level and charging state.
 * Used by the AI Router for performance-aware decisions.
 */
@Singleton
class BatteryUtils @Inject constructor(
    @ApplicationContext private val context: Context
) {

    private fun getBatteryIntent(): Intent? =
        context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))

    val batteryLevel: Int
        get() {
            val intent = getBatteryIntent() ?: return 50
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            return if (level >= 0 && scale > 0) (level * 100 / scale) else 50
        }

    val isCharging: Boolean
        get() {
            val intent = getBatteryIntent() ?: return false
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            return status == BatteryManager.BATTERY_STATUS_CHARGING ||
                   status == BatteryManager.BATTERY_STATUS_FULL
        }

    val isLowBattery: Boolean
        get() = batteryLevel <= 15

    val powerMode: PowerMode
        get() = when {
            isCharging     -> PowerMode.CHARGING
            isLowBattery   -> PowerMode.LOW
            batteryLevel < 30 -> PowerMode.SAVING
            else           -> PowerMode.NORMAL
        }

    enum class PowerMode { CHARGING, NORMAL, SAVING, LOW }
}
