package com.jarvis.assistant.core.utils

import android.content.Context
import com.jarvis.assistant.core.constants.AppConstants
import com.jarvis.assistant.core.constants.ModelInfo
import com.jarvis.assistant.core.di.IoDispatcher
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import javax.inject.Inject
import javax.inject.Singleton

/**
 * FileManager — handles GGUF model file downloads, storage, and verification.
 *
 * Features:
 * • Resumable downloads (via Range header)
 * • Progress flow streaming
 * • SHA-256 integrity verification
 * • Storage estimation
 * • Model listing and deletion
 */
@Singleton
class FileManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val okHttpClient: OkHttpClient,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) {

    // ── Models directory ──────────────────────────────────────────────────────

    val modelsDir: File
        get() = File(context.filesDir, AppConstants.MODELS_DIR).also { it.mkdirs() }

    fun getModelFile(modelId: String): File =
        File(modelsDir, "$modelId.gguf")

    fun getPartialFile(modelId: String): File =
        File(modelsDir, "$modelId.gguf.part")

    fun isModelDownloaded(modelId: String): Boolean =
        getModelFile(modelId).exists() && getModelFile(modelId).length() > 0

    fun getModelFilePath(modelId: String): String = getModelFile(modelId).absolutePath

    // ── Storage ───────────────────────────────────────────────────────────────

    fun getAvailableStorageBytes(): Long {
        val stat = android.os.StatFs(context.filesDir.absolutePath)
        return stat.availableBlocksLong * stat.blockSizeLong
    }

    fun getTotalStorageBytes(): Long {
        val stat = android.os.StatFs(context.filesDir.absolutePath)
        return stat.totalBlocksLong * stat.blockSizeLong
    }

    fun getUsedModelsStorageBytes(): Long =
        modelsDir.walkTopDown()
            .filter { it.isFile }
            .sumOf { it.length() }

    fun hasEnoughStorageFor(sizeBytes: Long, marginBytes: Long = 200_000_000L): Boolean =
        getAvailableStorageBytes() > sizeBytes + marginBytes

    // ── Download ──────────────────────────────────────────────────────────────

    sealed class DownloadState {
        data class Progress(val bytesDownloaded: Long, val totalBytes: Long, val percent: Int) : DownloadState()
        data class Success(val filePath: String) : DownloadState()
        data class Error(val message: String, val throwable: Throwable? = null) : DownloadState()
        object Cancelled : DownloadState()
    }

    private val activeDownloads = mutableMapOf<String, Boolean>()

    fun downloadModel(modelInfo: ModelInfo): Flow<DownloadState> = flow {
        val modelFile   = getModelFile(modelInfo.id)
        val partialFile = getPartialFile(modelInfo.id)

        // Check if already downloaded
        if (modelFile.exists() && modelFile.length() > 100_000) {
            emit(DownloadState.Success(modelFile.absolutePath))
            return@flow
        }

        // Check storage
        if (!hasEnoughStorageFor(modelInfo.sizeBytes)) {
            emit(DownloadState.Error("Insufficient storage. Need ${modelInfo.sizeBytes.toFileSizeString()}."))
            return@flow
        }

        activeDownloads[modelInfo.id] = true

        try {
            // Resume support: check existing partial file
            val existingBytes = if (partialFile.exists()) partialFile.length() else 0L

            val requestBuilder = Request.Builder().url(modelInfo.url)
            if (existingBytes > 0) {
                requestBuilder.addHeader("Range", "bytes=$existingBytes-")
            }

            val response = okHttpClient.newCall(requestBuilder.build()).execute()

            if (!response.isSuccessful && response.code != 206) {
                emit(DownloadState.Error("HTTP ${response.code}: ${response.message}"))
                return@flow
            }

            val body = response.body
                ?: run { emit(DownloadState.Error("Empty response body")); return@flow }

            val contentLength = response.header("Content-Length")?.toLongOrNull() ?: modelInfo.sizeBytes
            val totalBytes    = contentLength + existingBytes

            // Stream to partial file
            val outputStream = partialFile.outputStream().apply {
                if (existingBytes > 0) {
                    // append mode for resume
                }
            }

            val appendStream = if (existingBytes > 0) {
                java.io.FileOutputStream(partialFile, true)
            } else {
                partialFile.outputStream()
            }

            var downloadedBytes = existingBytes
            val buffer = ByteArray(AppConstants.MODEL_CHUNK_SIZE.coerceAtMost(8192))

            body.byteStream().use { input ->
                appendStream.use { output ->
                    var bytesRead: Int
                    while (input.read(buffer).also { bytesRead = it } != -1) {
                        if (activeDownloads[modelInfo.id] != true) {
                            emit(DownloadState.Cancelled)
                            return@flow
                        }
                        output.write(buffer, 0, bytesRead)
                        downloadedBytes += bytesRead
                        val percent = ((downloadedBytes.toFloat() / totalBytes) * 100).toInt()
                        emit(DownloadState.Progress(downloadedBytes, totalBytes, percent.coerceIn(0, 100)))
                    }
                }
            }

            // Rename partial → final
            if (partialFile.renameTo(modelFile)) {
                activeDownloads.remove(modelInfo.id)
                emit(DownloadState.Success(modelFile.absolutePath))
            } else {
                emit(DownloadState.Error("Failed to finalize model file"))
            }

        } catch (e: Exception) {
            activeDownloads.remove(modelInfo.id)
            emit(DownloadState.Error("Download failed: ${e.message}", e))
        }
    }.flowOn(ioDispatcher)

    fun cancelDownload(modelId: String) {
        activeDownloads[modelId] = false
    }

    // ── Delete ────────────────────────────────────────────────────────────────

    fun deleteModel(modelId: String): Boolean {
        val modelFile   = getModelFile(modelId)
        val partialFile = getPartialFile(modelId)
        var deleted = false
        if (modelFile.exists())   deleted = modelFile.delete()
        if (partialFile.exists()) partialFile.delete()
        return deleted
    }

    // ── List downloaded models ────────────────────────────────────────────────

    fun listDownloadedModels(): List<DownloadedModelInfo> {
        return modelsDir.listFiles()
            ?.filter { it.isFile && it.extension == "gguf" }
            ?.map { file ->
                DownloadedModelInfo(
                    id       = file.nameWithoutExtension,
                    name     = file.nameWithoutExtension,
                    filePath = file.absolutePath,
                    sizeBytes = file.length(),
                    lastModified = file.lastModified()
                )
            }
            ?: emptyList()
    }

    // ── Integrity check ───────────────────────────────────────────────────────

    suspend fun verifyModelIntegrity(modelId: String, expectedSha256: String? = null): Boolean =
        withContext(ioDispatcher) {
            val file = getModelFile(modelId)
            if (!file.exists()) return@withContext false
            if (file.length() < 100_000) return@withContext false

            // If no expected hash, just verify file is readable
            if (expectedSha256 == null) {
                return@withContext try {
                    FileInputStream(file).use { it.read(ByteArray(1024)) }
                    true
                } catch (e: Exception) { false }
            }

            // SHA-256 verification
            try {
                val digest = MessageDigest.getInstance("SHA-256")
                FileInputStream(file).use { input ->
                    val buffer = ByteArray(8192)
                    var bytesRead: Int
                    while (input.read(buffer).also { bytesRead = it } != -1) {
                        digest.update(buffer, 0, bytesRead)
                    }
                }
                val actualHash = digest.digest().joinToString("") { "%02x".format(it) }
                actualHash.equals(expectedSha256, ignoreCase = true)
            } catch (e: Exception) {
                android.util.Log.e("FileManager", "Integrity check failed", e)
                false
            }
        }

    data class DownloadedModelInfo(
        val id: String,
        val name: String,
        val filePath: String,
        val sizeBytes: Long,
        val lastModified: Long
    )
}
