package com.jarvis.assistant.core.utils

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.jarvis.assistant.JarvisApplication
import com.jarvis.assistant.R
import com.jarvis.assistant.core.constants.AppConstants
import com.jarvis.assistant.presentation.ui.MainActivity
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * NotificationHelper — builds Notifications for all JARVIS foreground services.
 *
 * All notifications are minimal, non-intrusive, and dismissible where allowed.
 */
@Singleton
class NotificationHelper @Inject constructor(
    @ApplicationContext private val context: Context
) {

    private val manager: NotificationManager
        get() = context.getSystemService(NotificationManager::class.java)

    // ── Open JARVIS pending intent ────────────────────────────────────────────

    private fun openJarvisIntent(): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            action = AppConstants.Actions.OPEN_MAIN
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        return PendingIntent.getActivity(
            context, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    // ── Voice Service notification ────────────────────────────────────────────

    fun buildVoiceNotification(isListening: Boolean = false): Notification =
        NotificationCompat.Builder(context, JarvisApplication.CHANNEL_VOICE)
            .setContentTitle(if (isListening) "JARVIS is Listening" else context.getString(R.string.notification_voice_title))
            .setContentText(if (isListening) "Speak now…" else context.getString(R.string.notification_voice_text))
            .setSmallIcon(R.drawable.ic_jarvis_logo)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(openJarvisIntent())
            .build()

    fun updateVoiceNotification(isListening: Boolean) {
        manager.notify(
            JarvisApplication.NOTIFICATION_ID_VOICE,
            buildVoiceNotification(isListening)
        )
    }

    // ── Overlay Service notification ──────────────────────────────────────────

    fun buildOverlayNotification(): Notification =
        NotificationCompat.Builder(context, JarvisApplication.CHANNEL_OVERLAY)
            .setContentTitle(context.getString(R.string.notification_overlay_title))
            .setContentText(context.getString(R.string.notification_overlay_text))
            .setSmallIcon(R.drawable.ic_jarvis_logo)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setContentIntent(openJarvisIntent())
            .build()

    // ── AI Processing notification ────────────────────────────────────────────

    fun buildAiNotification(status: String = "Processing…"): Notification =
        NotificationCompat.Builder(context, JarvisApplication.CHANNEL_AI)
            .setContentTitle(context.getString(R.string.notification_ai_title))
            .setContentText(status)
            .setSmallIcon(R.drawable.ic_jarvis_logo)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setProgress(0, 0, true)
            .setContentIntent(openJarvisIntent())
            .build()

    // ── Device Control notification ───────────────────────────────────────────

    fun buildDeviceControlNotification(): Notification =
        NotificationCompat.Builder(context, JarvisApplication.CHANNEL_DEVICE)
            .setContentTitle(context.getString(R.string.notification_device_title))
            .setContentText("Device automation ready")
            .setSmallIcon(R.drawable.ic_jarvis_logo)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setContentIntent(openJarvisIntent())
            .build()

    // ── Model Download notification ───────────────────────────────────────────

    fun buildModelDownloadNotification(
        modelName: String,
        progress: Int
    ): Notification =
        NotificationCompat.Builder(context, JarvisApplication.CHANNEL_AI)
            .setContentTitle("Downloading $modelName")
            .setContentText("$progress% complete")
            .setSmallIcon(R.drawable.ic_jarvis_logo)
            .setProgress(100, progress, false)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openJarvisIntent())
            .build()

    fun updateModelDownloadNotification(modelName: String, progress: Int) {
        manager.notify(
            JarvisApplication.NOTIFICATION_ID_AI,
            buildModelDownloadNotification(modelName, progress)
        )
    }

    fun cancelNotification(id: Int) = manager.cancel(id)
}
