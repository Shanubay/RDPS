package com.jarvis.assistant.service.overlay

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.FrameLayout
import androidx.compose.runtime.*
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.jarvis.assistant.core.constants.AppConstants
import com.jarvis.assistant.core.utils.NotificationHelper
import com.jarvis.assistant.service.voice.VoiceOrchestrator
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * OverlayService — floating JARVIS UI that appears above all other apps.
 *
 * Renders using Jetpack Compose inside a WindowManager overlay view.
 * Supports:
 * • Collapsed bubble (pulsing JARVIS logo)
 * • Expanded panel (voice waveform + recent response)
 * • Draggable positioning
 * • Auto-hide after response
 * • Iron Man HUD aesthetic
 */
@AndroidEntryPoint
class OverlayService : Service(), LifecycleOwner, SavedStateRegistryOwner {

    @Inject lateinit var notificationHelper: NotificationHelper
    @Inject lateinit var voiceOrchestrator: VoiceOrchestrator

    // ── Lifecycle plumbing for Compose in a Service ───────────────────────────

    private val lifecycleRegistry              = LifecycleRegistry(this)
    private val savedStateRegistryController   = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle             get() = lifecycleRegistry
    override val savedStateRegistry: SavedStateRegistry
        get() = savedStateRegistryController.savedStateRegistry

    // ── Window Manager ────────────────────────────────────────────────────────

    private var windowManager: WindowManager? = null
    private var overlayView: View?            = null
    private var isExpanded                    = false

    private val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    else
        @Suppress("DEPRECATION")
        WindowManager.LayoutParams.TYPE_PHONE

    inner class OverlayBinder : Binder() {
        fun getService() = this@OverlayService
    }

    override fun onBind(intent: Intent): IBinder = OverlayBinder()

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performAttach()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.currentState = Lifecycle.State.CREATED

        startForeground(
            com.jarvis.assistant.JarvisApplication.NOTIFICATION_ID_OVERLAY,
            notificationHelper.buildOverlayNotification()
        )

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            AppConstants.Actions.SHOW_OVERLAY -> showOverlay()
            AppConstants.Actions.HIDE_OVERLAY -> hideOverlay()
            AppConstants.Actions.TOGGLE_OVERLAY -> toggleOverlay()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
        hideOverlay()
        super.onDestroy()
    }

    // ── Overlay Display ───────────────────────────────────────────────────────

    fun showOverlay() {
        if (overlayView != null) return

        lifecycleRegistry.currentState = Lifecycle.State.STARTED

        val params = buildLayoutParams(collapsed = true)

        // Wrapper FrameLayout that hosts the ComposeView
        val wrapper = FrameLayout(this)

        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@OverlayService)
            setViewTreeSavedStateRegistryOwner(this@OverlayService)
            setContent {
                JarvisOverlayContent(
                    voiceOrchestrator = voiceOrchestrator,
                    isExpanded        = isExpanded,
                    onToggleExpand    = { toggleExpand(params) },
                    onDismiss         = { hideOverlay() },
                    onMicClick        = { voiceOrchestrator.startListening() }
                )
            }
        }

        wrapper.addView(composeView)

        // Drag to reposition
        setupDragListener(wrapper, params)

        overlayView = wrapper
        windowManager?.addView(wrapper, params)
        lifecycleRegistry.currentState = Lifecycle.State.RESUMED
    }

    fun hideOverlay() {
        overlayView?.let {
            windowManager?.removeView(it)
            overlayView = null
        }
        lifecycleRegistry.currentState = Lifecycle.State.CREATED
    }

    private fun toggleOverlay() {
        if (overlayView == null) showOverlay() else hideOverlay()
    }

    private fun toggleExpand(params: WindowManager.LayoutParams) {
        isExpanded = !isExpanded
        val newParams = buildLayoutParams(collapsed = !isExpanded)
        // Preserve position
        newParams.x = params.x
        newParams.y = params.y
        overlayView?.let { windowManager?.updateViewLayout(it, newParams) }
    }

    // ── Layout Params ─────────────────────────────────────────────────────────

    private fun buildLayoutParams(collapsed: Boolean): WindowManager.LayoutParams {
        val size = if (collapsed)
            dpToPx(72) else dpToPx(300)
        val height = if (collapsed)
            dpToPx(72) else dpToPx(200)

        return WindowManager.LayoutParams(
            size,
            height,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x       = dpToPx(16)
            y       = dpToPx(120)
        }
    }

    // ── Drag ─────────────────────────────────────────────────────────────────

    private fun setupDragListener(view: View, params: WindowManager.LayoutParams) {
        var initialX = 0; var initialY = 0
        var touchX   = 0f; var touchY  = 0f
        var isDragging = false

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x; initialY = params.y
                    touchX   = event.rawX; touchY  = event.rawY
                    isDragging = false
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (Math.abs(dx) > 8 || Math.abs(dy) > 8) isDragging = true
                    if (isDragging) {
                        params.x = initialX - dx   // RTL-friendly
                        params.y = initialY + dy
                        windowManager?.updateViewLayout(view, params)
                    }
                    isDragging
                }
                MotionEvent.ACTION_UP -> {
                    isDragging.also { isDragging = false }
                }
                else -> false
            }
        }
    }

    private fun dpToPx(dp: Int): Int =
        (dp * resources.displayMetrics.density).toInt()
}

// ── Compose Overlay Content (stub — full Iron Man UI built in Step 10) ───────

@Composable
private fun JarvisOverlayContent(
    voiceOrchestrator: VoiceOrchestrator,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    onDismiss: () -> Unit,
    onMicClick: () -> Unit
) {
    // Minimal stub so the service compiles. Full Arc Reactor overlay in Step 10.
    val voiceState by voiceOrchestrator.voiceState.collectAsState()

    androidx.compose.foundation.layout.Box(
        modifier          = androidx.compose.ui.Modifier
            .size(if (isExpanded) 300.dp else 72.dp)
            .background(
                androidx.compose.ui.graphics.Color(0xCC0A0A0A),
                androidx.compose.foundation.shape.CircleShape
            ),
        contentAlignment  = androidx.compose.ui.Alignment.Center
    ) {
        androidx.compose.material3.Text(
            text  = "J",
            color = androidx.compose.ui.graphics.Color(0xFF00D4FF),
            fontSize = 28.sp
        )
    }
}

private val Int.dp: androidx.compose.ui.unit.Dp
    get() = androidx.compose.ui.unit.Dp(this.toFloat())

private val Int.sp: androidx.compose.ui.unit.TextUnit
    get() = androidx.compose.ui.unit.TextUnit(this.toFloat(), androidx.compose.ui.unit.TextUnitType.Sp)

private fun androidx.compose.ui.Modifier.background(
    color: androidx.compose.ui.graphics.Color,
    shape: androidx.compose.ui.graphics.Shape
) = this.then(
    androidx.compose.ui.draw.clip(shape)
        .then(androidx.compose.foundation.background(color))
)
