package com.jarvis.assistant.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.*
import com.jarvis.assistant.domain.entities.AIModel
import com.jarvis.assistant.domain.entities.ModelStatus
import com.jarvis.assistant.presentation.viewmodel.ModelManagerViewModel
import com.jarvis.assistant.ui.components.*
import com.jarvis.assistant.ui.theme.*

@Composable
fun ModelManagerScreen(
    viewModel: ModelManagerViewModel,
    onBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisColors.VoidBlack)
    ) {
        // Header
        Row(
            modifier              = Modifier
                .fillMaxWidth()
                .padding(JarvisSpacing.md),
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(JarvisSpacing.sm)
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, "Back", tint = JarvisColors.CyanCore)
            }
            Column {
                Text(
                    "LOCAL MODELS",
                    style         = MaterialTheme.typography.headlineMedium,
                    color         = JarvisColors.TextPrimary,
                    letterSpacing = 4.sp
                )
                Text(
                    "ON-DEVICE AI  •  NO INTERNET REQUIRED",
                    style         = MaterialTheme.typography.labelSmall,
                    color         = JarvisColors.TextMuted,
                    letterSpacing = 2.sp
                )
            }
        }

        HudDivider()

        // Storage info
        HudCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(JarvisSpacing.md)
        ) {
            Column(
                modifier = Modifier.padding(JarvisSpacing.md),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                HudSectionHeader("Storage", accentColor = JarvisColors.GoldAlert)
                HudProgressBar(
                    progress = uiState.storageUsedBytes.toFloat() /
                               uiState.storageTotalBytes.toFloat().coerceAtLeast(1f),
                    label    = "Disk usage: ${formatBytes(uiState.storageUsedBytes)} " +
                               "/ ${formatBytes(uiState.storageTotalBytes)}"
                )
            }
        }

        LazyColumn(
            contentPadding      = PaddingValues(JarvisSpacing.md),
            verticalArrangement = Arrangement.spacedBy(JarvisSpacing.sm)
        ) {
            items(uiState.availableModels, key = { it.id }) { model ->
                ModelCard(
                    model        = model,
                    downloadState = uiState.downloadStates[model.id],
                    isActive     = uiState.activeModel?.id == model.id,
                    onDownload   = { viewModel.downloadModel(model.id) },
                    onCancel     = { viewModel.cancelDownload(model.id) },
                    onDelete     = { viewModel.deleteModel(model.id) },
                    onLoad       = { viewModel.loadModel(model.id) },
                    onUnload     = { viewModel.unloadModel() }
                )
            }
            item { Spacer(Modifier.height(JarvisSpacing.xxl)) }
        }
    }
}

// ── Model Card ────────────────────────────────────────────────────────────────

@Composable
private fun ModelCard(
    model: AIModel,
    downloadState: ModelManagerViewModel.DownloadState?,
    isActive: Boolean,
    onDownload: () -> Unit,
    onCancel: () -> Unit,
    onDelete: () -> Unit,
    onLoad: () -> Unit,
    onUnload: () -> Unit
) {
    val accentColor = when {
        isActive                                     -> JarvisColors.GreenOnline
        model.status == ModelStatus.DOWNLOADED       -> JarvisColors.CyanCore
        model.status == ModelStatus.DOWNLOADING      -> JarvisColors.GoldAlert
        else                                         -> JarvisColors.TextMuted
    }

    HudCard(
        modifier  = Modifier.fillMaxWidth(),
        glowColor = accentColor,
        glowAlpha = if (isActive) 0.4f else 0.15f
    ) {
        Column(
            modifier = Modifier.padding(JarvisSpacing.md),
            verticalArrangement = Arrangement.spacedBy(JarvisSpacing.sm)
        ) {
            // Model name + status
            Row(
                modifier              = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment     = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        model.name,
                        style  = MaterialTheme.typography.titleMedium,
                        color  = JarvisColors.TextPrimary
                    )
                    Text(
                        model.description.take(60),
                        style  = MaterialTheme.typography.bodySmall,
                        color  = JarvisColors.TextMuted
                    )
                }
                if (isActive) {
                    JarvisStatusLabel("ACTIVE", color = JarvisColors.GreenOnline)
                }
            }

            // Size + RAM chips
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                JarvisChip(
                    text  = formatBytes(model.sizeBytes),
                    color = JarvisColors.TextSecondary
                )
                JarvisChip(
                    text  = "${model.ramRequired} RAM",
                    color = JarvisColors.GoldAlert
                )
                JarvisChip(
                    text  = model.quantization,
                    color = JarvisColors.CyanDim
                )
            }

            // Download progress
            downloadState?.let { state ->
                when (state) {
                    is ModelManagerViewModel.DownloadState.Downloading -> {
                        HudProgressBar(
                            progress = state.progress,
                            label    = "Downloading  •  ${formatBytes(state.bytesDownloaded)} of ${formatBytes(state.totalBytes)}"
                        )
                    }
                    is ModelManagerViewModel.DownloadState.Verifying -> {
                        Row(
                            verticalAlignment     = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            JarvisLoader(size = 14.dp, color = JarvisColors.GoldAlert)
                            Text("Verifying integrity...",
                                style = MaterialTheme.typography.bodySmall,
                                color = JarvisColors.GoldAlert)
                        }
                    }
                    is ModelManagerViewModel.DownloadState.Failed -> {
                        Text(
                            "Download failed: ${state.error}",
                            style = MaterialTheme.typography.bodySmall,
                            color = JarvisColors.CrimsonAlert
                        )
                    }
                    else -> {}
                }
            }

            HudDivider()

            // Action buttons
            Row(horizontalArrangement = Arrangement.spacedBy(JarvisSpacing.sm)) {
                when (model.status) {
                    ModelStatus.NOT_DOWNLOADED -> {
                        JarvisButton(
                            text    = "Download",
                            onClick = onDownload,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    ModelStatus.DOWNLOADING -> {
                        JarvisButton(
                            text          = "Cancel",
                            onClick       = onCancel,
                            modifier      = Modifier.weight(1f),
                            isDestructive = true
                        )
                    }
                    ModelStatus.DOWNLOADED -> {
                        if (isActive) {
                            JarvisButton(
                                text          = "Unload",
                                onClick       = onUnload,
                                modifier      = Modifier.weight(1f),
                                color         = JarvisColors.TextSecondary
                            )
                        } else {
                            JarvisButton(
                                text    = "Load",
                                onClick = onLoad,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        IconButton(onClick = onDelete) {
                            Icon(
                                Icons.Default.DeleteOutline, null,
                                tint = JarvisColors.CrimsonAlert
                            )
                        }
                    }
                    ModelStatus.LOADING -> {
                        Row(
                            verticalAlignment     = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier              = Modifier.fillMaxWidth()
                        ) {
                            JarvisLoader(size = 16.dp)
                            Text("Loading model...",
                                style = MaterialTheme.typography.bodySmall,
                                color = JarvisColors.CyanCore)
                        }
                    }
                    else -> {}
                }
            }
        }
    }
}

private fun formatBytes(bytes: Long): String = when {
    bytes >= 1_073_741_824L -> "${"%.1f".format(bytes / 1_073_741_824.0)} GB"
    bytes >= 1_048_576L     -> "${"%.0f".format(bytes / 1_048_576.0)} MB"
    else                    -> "${"%.0f".format(bytes / 1024.0)} KB"
}
