package com.jarvis.assistant.brain

import android.content.Context
import com.jarvis.assistant.brain.agent.AgentTool
import com.jarvis.assistant.brain.agent.ToolExecutor
import com.jarvis.assistant.core.utils.TimeUtils
import com.jarvis.assistant.domain.entities.Routine
import com.jarvis.assistant.domain.entities.RoutineAction
import com.jarvis.assistant.domain.entities.RoutineTrigger
import com.jarvis.assistant.domain.repository.RoutineRepository
import com.jarvis.assistant.service.voice.TtsService
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

/**
 * RoutineEngine — evaluates and executes JARVIS automation routines.
 *
 * Routines are chains of actions triggered by:
 * • Time of day
 * • Wake word variants ("good morning")
 * • Charging state changes
 * • App launch events
 *
 * Examples:
 * "Good morning" → Read weather + calendar + news briefing
 * Charging connected → Set volume to 0 + DND on
 * 9:00 AM weekdays → Brief daily summary
 */
@Singleton
class RoutineEngine @Inject constructor(
    @ApplicationContext private val context: Context,
    private val routineRepository: RoutineRepository,
    private val toolExecutor: ToolExecutor,
    private val timeUtils: TimeUtils
) {

    private val engineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // ── Trigger Evaluation ────────────────────────────────────────────────────

    fun onWakeWord(phrase: String) {
        engineScope.launch {
            val routines = routineRepository.getAllRoutines().first()
            routines.filter { it.isEnabled }
                .filter { routine ->
                    routine.trigger is RoutineTrigger.WakeWord &&
                    phrase.lowercase().contains(
                        (routine.trigger as RoutineTrigger.WakeWord).phrase.lowercase()
                    )
                }
                .forEach { executeRoutine(it) }
        }
    }

    fun onChargingConnected() {
        engineScope.launch {
            val routines = routineRepository.getAllRoutines().first()
            routines.filter { it.isEnabled }
                .filter { it.trigger is RoutineTrigger.ChargingConnected }
                .forEach { executeRoutine(it) }
        }
    }

    fun onChargingDisconnected() {
        engineScope.launch {
            val routines = routineRepository.getAllRoutines().first()
            routines.filter { it.isEnabled }
                .filter { it.trigger is RoutineTrigger.ChargingDisconnected }
                .forEach { executeRoutine(it) }
        }
    }

    fun onAppOpened(packageName: String) {
        engineScope.launch {
            val routines = routineRepository.getAllRoutines().first()
            routines.filter { it.isEnabled }
                .filter { routine ->
                    routine.trigger is RoutineTrigger.AppOpened &&
                    (routine.trigger as RoutineTrigger.AppOpened).packageName == packageName
                }
                .forEach { executeRoutine(it) }
        }
    }

    fun checkTimeRoutines() {
        engineScope.launch {
            val now      = java.util.Calendar.getInstance()
            val hour     = now.get(java.util.Calendar.HOUR_OF_DAY)
            val minute   = now.get(java.util.Calendar.MINUTE)
            val routines = routineRepository.getAllRoutines().first()

            routines.filter { it.isEnabled }
                .filter { routine ->
                    routine.trigger is RoutineTrigger.TimeOfDay &&
                    (routine.trigger as RoutineTrigger.TimeOfDay).hour == hour &&
                    (routine.trigger as RoutineTrigger.TimeOfDay).minute == minute
                }
                .forEach { executeRoutine(it) }
        }
    }

    // ── Routine Execution ─────────────────────────────────────────────────────

    private suspend fun executeRoutine(routine: Routine) {
        android.util.Log.i("RoutineEngine", "Executing: ${routine.name}")

        routine.actions.forEach { action ->
            when (action) {
                is RoutineAction.SpeakText -> {
                    speakText(action.text)
                    delay(500)
                }
                is RoutineAction.LaunchApp -> {
                    toolExecutor.execute(
                        AgentTool.LaunchAppTool(action.packageName, action.packageName)
                    )
                }
                is RoutineAction.SetVolume -> {
                    toolExecutor.execute(
                        AgentTool.VolumeTool(
                            AgentTool.VolumeTool.VolumeAction.SET,
                            action.level
                        )
                    )
                }
                is RoutineAction.ToggleWifi -> {
                    toolExecutor.execute(AgentTool.WifiSettingsTool)
                }
                is RoutineAction.ToggleBluetooth -> {
                    toolExecutor.execute(AgentTool.BluetoothTool(action.enable))
                }
                is RoutineAction.SendAiQuery -> {
                    // Would trigger JarvisBrain — handled via orchestrator
                    android.util.Log.d("RoutineEngine", "AI query: ${action.query}")
                }
            }
            delay(200)  // small gap between actions
        }

        // Update last-run timestamp
        routineRepository.updateRoutine(
            routine.copy(lastRun = System.currentTimeMillis())
        )
    }

    private fun speakText(text: String) {
        // Fire-and-forget TTS via service intent
        val intent = android.content.Intent(context,
            com.jarvis.assistant.service.voice.TtsService::class.java)
        // TtsService is bound — use VoiceOrchestrator in production
        android.util.Log.d("RoutineEngine", "Speak: $text")
    }

    // ── Built-in Routines ─────────────────────────────────────────────────────

    fun getDefaultRoutines(): List<Routine> = listOf(
        Routine(
            name    = "Good Morning Briefing",
            trigger = RoutineTrigger.TimeOfDay(7, 0),
            actions = listOf(
                RoutineAction.SpeakText("Good morning. All systems are online."),
                RoutineAction.SendAiQuery("Give me a brief morning summary.")
            )
        ),
        Routine(
            name    = "Charging: Night Mode",
            trigger = RoutineTrigger.ChargingConnected,
            actions = listOf(
                RoutineAction.SetVolume(0),
                RoutineAction.ToggleBluetooth(false)
            )
        ),
        Routine(
            name    = "Charging: Morning Mode",
            trigger = RoutineTrigger.ChargingDisconnected,
            actions = listOf(
                RoutineAction.SetVolume(8)
            )
        )
    )

    fun destroy() {
        engineScope.cancel()
    }
}
