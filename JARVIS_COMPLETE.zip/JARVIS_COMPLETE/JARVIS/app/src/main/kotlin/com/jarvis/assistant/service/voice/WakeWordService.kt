package com.jarvis.assistant.service.voice

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.jarvis.assistant.JarvisApplication
import com.jarvis.assistant.core.constants.AppConstants
import com.jarvis.assistant.core.utils.AudioUtils
import com.jarvis.assistant.core.utils.NotificationHelper
import com.jarvis.assistant.core.utils.containsWakeWord
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.Locale
import javax.inject.Inject

/**
 * WakeWordService — always-on foreground service that listens for "Hey Jarvis".
 *
 * Uses Android SpeechRecognizer in continuous mode.
 * When wake word detected → broadcasts ACTION_WAKE_WORD_DETECTED.
 * Auto-restarts after each recognition cycle.
 * Handles battery-optimized restart after silence.
 */
@AndroidEntryPoint
class WakeWordService : Service() {

    @Inject lateinit var notificationHelper: NotificationHelper
    @Inject lateinit var audioUtils: AudioUtils

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false
    private var restartJob: Job? = null

    companion object {
        private const val TAG           = "WakeWordService"
        private const val RESTART_DELAY = 500L   // ms between recognition cycles
        var isRunning = false
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        startForeground(
            JarvisApplication.NOTIFICATION_ID_VOICE,
            notificationHelper.buildVoiceNotification(false)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            AppConstants.Actions.STOP_WAKE_WORD -> stopSelf()
            else                                -> startWakeWordListening()
        }
        return START_STICKY   // auto-restart if killed
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        isRunning = false
        stopListening()
        serviceScope.cancel()
        super.onDestroy()
    }

    // ── Wake Word Listening ───────────────────────────────────────────────────

    private fun startWakeWordListening() {
        if (isListening) return
        serviceScope.launch {
            initSpeechRecognizer()
            beginListeningCycle()
        }
    }

    private fun initSpeechRecognizer() {
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(wakeWordListener)
        }
    }

    private fun beginListeningCycle() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            android.util.Log.w(TAG, "Speech recognition not available on this device")
            return
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.ENGLISH.toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
        }

        try {
            isListening = true
            speechRecognizer?.startListening(intent)
            notificationHelper.updateVoiceNotification(false)
        } catch (e: Exception) {
            android.util.Log.e(TAG, "Start listening failed", e)
            scheduleRestart()
        }
    }

    private fun stopListening() {
        isListening = false
        restartJob?.cancel()
        speechRecognizer?.stopListening()
        speechRecognizer?.destroy()
        speechRecognizer = null
    }

    private fun scheduleRestart(delayMs: Long = RESTART_DELAY) {
        isListening = false
        restartJob?.cancel()
        restartJob = serviceScope.launch {
            delay(delayMs)
            if (isRunning) {
                initSpeechRecognizer()
                beginListeningCycle()
            }
        }
    }

    // ── Wake Word Listener ────────────────────────────────────────────────────

    private val wakeWordListener = object : RecognitionListener {

        override fun onResults(results: android.os.Bundle?) {
            isListening = false
            val matches = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?: run { scheduleRestart(); return }

            val detected = matches.any { it.containsWakeWord(AppConstants.WAKE_WORD) }
            if (detected) {
                android.util.Log.i(TAG, "✅ Wake word detected: ${matches.first()}")
                onWakeWordDetected()
            } else {
                scheduleRestart()
            }
        }

        override fun onPartialResults(partial: android.os.Bundle?) {
            val partials = partial
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?: return
            val detected = partials.any { it.containsWakeWord(AppConstants.WAKE_WORD) }
            if (detected) {
                android.util.Log.i(TAG, "✅ Wake word detected (partial): ${partials.firstOrNull()}")
                speechRecognizer?.stopListening()
                onWakeWordDetected()
            }
        }

        override fun onError(error: Int) {
            isListening = false
            val delay = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH           -> RESTART_DELAY
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT     -> RESTART_DELAY
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY    -> 1000L
                SpeechRecognizer.ERROR_AUDIO              -> 500L
                SpeechRecognizer.ERROR_NETWORK            -> 2000L
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    android.util.Log.e(TAG, "Missing RECORD_AUDIO permission"); 5000L
                }
                else -> RESTART_DELAY
            }
            scheduleRestart(delay)
        }

        override fun onReadyForSpeech(params: android.os.Bundle?)   { }
        override fun onBeginningOfSpeech()                          { }
        override fun onRmsChanged(rmsdB: Float)                     { }
        override fun onBufferReceived(buffer: ByteArray?)           { }
        override fun onEndOfSpeech()                                { isListening = false }
        override fun onEvent(eventType: Int, params: android.os.Bundle?) { }
    }

    // ── Wake Word Detected ────────────────────────────────────────────────────

    private fun onWakeWordDetected() {
        notificationHelper.updateVoiceNotification(true)

        // Broadcast to MainActivity / OverlayService
        val intent = Intent(AppConstants.Actions.WAKE_WORD_DETECTED).apply {
            setPackage(packageName)
        }
        sendBroadcast(intent)

        // Restart wake word after a delay (let STT service take over briefly)
        scheduleRestart(3000L)
    }
}
