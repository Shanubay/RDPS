package com.jarvis.assistant.service.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * JarvisAccessibilityService — enables JARVIS to interact with any app on screen.
 *
 * Capabilities:
 * • Read on-screen text content for context-aware AI assistance
 * • Perform taps, swipes, scrolls via gesture dispatch
 * • Click UI elements by text label or content description
 * • Navigate back / home / recents
 * • Detect foreground app changes
 * • Extract notification content
 */
class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "JarvisA11y"

        // Singleton reference for use from other services/VMs
        private var _instance: JarvisAccessibilityService? = null
        val instance: JarvisAccessibilityService? get() = _instance

        private val _isConnected = MutableStateFlow(false)
        val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

        private val _foregroundPackage = MutableStateFlow("")
        val foregroundPackage: StateFlow<String> = _foregroundPackage.asStateFlow()

        private val _screenText = MutableStateFlow("")
        val screenText: StateFlow<String> = _screenText.asStateFlow()
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onServiceConnected() {
        _instance     = this
        _isConnected.value = true
        android.util.Log.i(TAG, "Accessibility service connected")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        _instance          = null
        _isConnected.value = false
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        _instance          = null
        _isConnected.value = false
        super.onDestroy()
    }

    // ── Event Handling ────────────────────────────────────────────────────────

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                val pkg = event.packageName?.toString() ?: return
                if (pkg != packageName) {   // ignore our own app
                    _foregroundPackage.value = pkg
                }
            }
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
                // Extract screen text lazily — only when requested
            }
            AccessibilityEvent.TYPE_ANNOUNCEMENT -> {
                android.util.Log.d(TAG, "Announcement: ${event.text.joinToString()}")
            }
        }
    }

    override fun onInterrupt() {
        android.util.Log.w(TAG, "Accessibility service interrupted")
    }

    // ── Screen Content Extraction ─────────────────────────────────────────────

    fun extractScreenText(): String {
        val root = rootInActiveWindow ?: return ""
        val sb   = StringBuilder()
        extractNodeText(root, sb, depth = 0)
        val text = sb.toString().trim()
        _screenText.value = text
        return text
    }

    private fun extractNodeText(
        node: AccessibilityNodeInfo?,
        sb: StringBuilder,
        depth: Int
    ) {
        if (node == null || depth > 8) return
        val text = node.text?.toString()
        val desc = node.contentDescription?.toString()
        if (!text.isNullOrBlank())  sb.appendLine(text.trim())
        if (!desc.isNullOrBlank() && desc != text) sb.appendLine(desc.trim())
        for (i in 0 until node.childCount) extractNodeText(node.getChild(i), sb, depth + 1)
    }

    // ── Click by Text ─────────────────────────────────────────────────────────

    fun clickByText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        return findAndClick(root, text.lowercase())
    }

    private fun findAndClick(node: AccessibilityNodeInfo?, query: String): Boolean {
        if (node == null) return false
        val nodeText = node.text?.toString()?.lowercase() ?: ""
        val nodeDesc = node.contentDescription?.toString()?.lowercase() ?: ""
        if ((nodeText.contains(query) || nodeDesc.contains(query)) && node.isClickable) {
            node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            return true
        }
        for (i in 0 until node.childCount) {
            if (findAndClick(node.getChild(i), query)) return true
        }
        return false
    }

    // ── Click by Resource ID ──────────────────────────────────────────────────

    fun clickById(resourceId: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByViewId(resourceId)
        return nodes.firstOrNull()?.let { node ->
            node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            true
        } ?: false
    }

    // ── Gesture Dispatch ──────────────────────────────────────────────────────

    fun performTap(x: Float, y: Float): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 50)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, null, null)
    }

    fun performSwipe(
        startX: Float, startY: Float,
        endX: Float,   endY: Float,
        durationMs: Long = 300
    ): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX,   endY)
        }
        val stroke  = GestureDescription.StrokeDescription(path, 0, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, null, null)
    }

    fun scrollDown(): Boolean {
        val display = resources.displayMetrics
        val cx      = display.widthPixels  / 2f
        val startY  = display.heightPixels * 0.7f
        val endY    = display.heightPixels * 0.3f
        return performSwipe(cx, startY, cx, endY)
    }

    fun scrollUp(): Boolean {
        val display = resources.displayMetrics
        val cx      = display.widthPixels  / 2f
        val startY  = display.heightPixels * 0.3f
        val endY    = display.heightPixels * 0.7f
        return performSwipe(cx, startY, cx, endY)
    }

    // ── System Actions ────────────────────────────────────────────────────────

    fun goHome()    = performGlobalAction(GLOBAL_ACTION_HOME)
    fun goBack()    = performGlobalAction(GLOBAL_ACTION_BACK)
    fun goRecents() = performGlobalAction(GLOBAL_ACTION_RECENTS)

    fun openNotifications() =
        performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    fun openQuickSettings() =
        performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)

    // ── Scroll Node ───────────────────────────────────────────────────────────

    fun scrollForward(): Boolean {
        val root = rootInActiveWindow ?: return false
        return findScrollable(root)?.performAction(
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        ) ?: false
    }

    fun scrollBackward(): Boolean {
        val root = rootInActiveWindow ?: return false
        return findScrollable(root)?.performAction(
            AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        ) ?: false
    }

    private fun findScrollable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            val found = findScrollable(node.getChild(i))
            if (found != null) return found
        }
        return null
    }

    // ── Input Text ────────────────────────────────────────────────────────────

    fun inputText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = findFocused(root) ?: return false
        val args = android.os.Bundle().apply {
            putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                text
            )
        }
        return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun findFocused(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isFocused && node.isEditable) return node
        for (i in 0 until node.childCount) {
            val found = findFocused(node.getChild(i))
            if (found != null) return found
        }
        return null
    }
}
