package com.jarvis.assistant.core.utils

import com.jarvis.assistant.core.constants.AppConstants
import com.jarvis.assistant.core.di.DefaultDispatcher
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * EmbeddingUtils — Generates lightweight text embeddings for semantic memory search.
 *
 * Uses a hash-based TF-IDF approximation when no ML model is available,
 * producing a fixed-size float vector per text input.
 *
 * For production: swap embed() with a real MiniLM-L6 TFLite model.
 * Cosine similarity is used for memory retrieval.
 */
@Singleton
class EmbeddingUtils @Inject constructor(
    @DefaultDispatcher private val dispatcher: CoroutineDispatcher
) {

    companion object {
        private val STOP_WORDS = setOf(
            "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
            "have", "has", "had", "do", "does", "did", "will", "would", "could",
            "should", "may", "might", "must", "can", "to", "of", "in", "for",
            "on", "with", "at", "by", "from", "and", "or", "but", "not", "so",
            "i", "you", "he", "she", "it", "we", "they", "me", "him", "her",
            "my", "your", "his", "its", "our", "their", "that", "this", "what",
            "which", "who", "when", "where", "how", "why"
        )
    }

    /**
     * Generate a fixed-size embedding vector for a text string.
     * Dimension = AppConstants.VECTOR_DIMENSION (384)
     */
    suspend fun embed(text: String): FloatArray = withContext(dispatcher) {
        val dim = AppConstants.VECTOR_DIMENSION
        val vector = FloatArray(dim)
        val normalized = text.lowercase().trim()
        val tokens = normalized.split(Regex("\\W+"))
            .filter { it.length > 1 && it !in STOP_WORDS }

        if (tokens.isEmpty()) return@withContext vector

        // TF-IDF inspired hash-projection embedding
        for (token in tokens) {
            val baseHash = token.hashCode()
            // Project each character n-gram into the vector
            for (ngLen in 2..minOf(token.length, 4)) {
                for (i in 0..token.length - ngLen) {
                    val ngram = token.substring(i, i + ngLen)
                    val h = abs(ngram.hashCode())
                    val idx1 = (h % dim + dim) % dim
                    val idx2 = ((h / dim) % dim + dim) % dim
                    val idx3 = ((h xor baseHash) % dim + dim) % dim

                    val weight = 1f / ngLen   // shorter n-grams have more weight
                    vector[idx1] += weight
                    vector[idx2] += weight * 0.7f
                    vector[idx3] += weight * 0.5f
                }
            }
        }

        // Apply positional weighting — earlier tokens carry more context
        for ((pos, token) in tokens.withIndex()) {
            val weight = 1f / (1f + pos * 0.1f)
            val h = abs(token.hashCode())
            val idx = (h % dim + dim) % dim
            vector[idx] += weight
        }

        // L2 normalize
        val norm = sqrt(vector.map { it * it }.sum())
        if (norm > 0f) {
            for (i in vector.indices) vector[i] /= norm
        }

        vector
    }

    /**
     * Cosine similarity between two embedding vectors.
     * Returns a value in [-1, 1]; higher = more similar.
     */
    fun cosineSimilarity(a: FloatArray, b: FloatArray): Float {
        require(a.size == b.size) { "Dimension mismatch: ${a.size} vs ${b.size}" }
        var dot = 0f; var normA = 0f; var normB = 0f
        for (i in a.indices) {
            dot   += a[i] * b[i]
            normA += a[i] * a[i]
            normB += b[i] * b[i]
        }
        val denom = sqrt(normA) * sqrt(normB)
        return if (denom == 0f) 0f else dot / denom
    }

    /**
     * Find top-K most similar texts given a query embedding.
     */
    fun topKSimilar(
        query: FloatArray,
        candidates: List<Pair<String, FloatArray>>,
        k: Int = 5,
        threshold: Float = AppConstants.MEMORY_SIMILARITY_THRESHOLD
    ): List<Pair<String, Float>> {
        return candidates
            .map { (text, vec) -> text to cosineSimilarity(query, vec) }
            .filter { (_, score) -> score >= threshold }
            .sortedByDescending { (_, score) -> score }
            .take(k)
    }

    /**
     * Serialize FloatArray to Base64 string for Room storage.
     */
    fun serializeEmbedding(embedding: FloatArray): String {
        val bytes = ByteArray(embedding.size * 4)
        val bb = java.nio.ByteBuffer.wrap(bytes)
        embedding.forEach { bb.putFloat(it) }
        return android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
    }

    /**
     * Deserialize Base64 string back to FloatArray.
     */
    fun deserializeEmbedding(encoded: String): FloatArray {
        val bytes = android.util.Base64.decode(encoded, android.util.Base64.NO_WRAP)
        val bb = java.nio.ByteBuffer.wrap(bytes)
        return FloatArray(bytes.size / 4) { bb.float }
    }
}
