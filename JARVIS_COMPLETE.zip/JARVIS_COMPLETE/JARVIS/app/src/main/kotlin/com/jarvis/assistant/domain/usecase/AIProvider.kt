package com.jarvis.assistant.domain.usecase

import com.jarvis.assistant.domain.entities.Message
import kotlinx.coroutines.flow.Flow

/**
 * AIProvider — the central interface every AI backend must implement.
 *
 * Implementations:
 * • OpenAIProvider     (GPT-4o, GPT-3.5-turbo)
 * • GeminiProvider     (Gemini 1.5 Flash/Pro)
 * • GroqProvider       (Llama3, Mixtral via Groq)
 * • OpenRouterProvider (multi-model fallback)
 * • LocalLlamaProvider (llama.cpp JNI)
 */
interface AIProvider {

    /** Provider identifier — matches AppConstants.AIProvider */
    val id: String

    /** Human-readable name */
    val name: String

    /** Whether this provider requires internet */
    val requiresInternet: Boolean

    /**
     * Single-shot completion — returns full response when done.
     * Use for short responses where streaming isn't needed.
     */
    suspend fun complete(
        messages: List<Message>,
        systemPrompt: String,
        maxTokens: Int = 1024,
        temperature: Float = 0.7f
    ): String

    /**
     * Streaming completion — emits tokens as they arrive.
     * The UI collects this to render text progressively.
     */
    fun stream(
        messages: List<Message>,
        systemPrompt: String,
        maxTokens: Int = 1024,
        temperature: Float = 0.7f
    ): Flow<String>

    /**
     * Whether this provider is currently available / configured.
     */
    suspend fun isAvailable(): Boolean
}
