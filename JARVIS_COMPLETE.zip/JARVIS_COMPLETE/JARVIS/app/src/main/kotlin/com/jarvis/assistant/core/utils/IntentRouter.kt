package com.jarvis.assistant.core.utils

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * IntentRouter — Translates JARVIS voice commands into Android Intents.
 *
 * Handles: app launches, phone calls, alarms, settings, web search, navigation.
 */
@Singleton
class IntentRouter @Inject constructor(
    @ApplicationContext private val context: Context
) {

    sealed class RoutedIntent {
        data class Resolved(val intent: Intent, val description: String) : RoutedIntent()
        data class NotFound(val reason: String) : RoutedIntent()
    }

    fun route(command: String): RoutedIntent {
        val lower = command.lowercase().trim()

        return when {
            // ── App Launch ────────────────────────────────────────────────────
            lower.contains("open ") || lower.contains("launch ") || lower.contains("start ") ->
                routeAppLaunch(command)

            // ── Phone Call ────────────────────────────────────────────────────
            lower.startsWith("call ") ->
                routePhoneCall(command)

            // ── Alarm ─────────────────────────────────────────────────────────
            lower.contains("alarm") || lower.contains("wake me") || lower.contains("set timer") ->
                routeAlarm(command)

            // ── Settings ──────────────────────────────────────────────────────
            lower.contains("wifi") || lower.contains("wi-fi") ->
                routeWifiSettings()
            lower.contains("bluetooth") ->
                routeBluetoothSettings()
            lower.contains("settings") ->
                RoutedIntent.Resolved(Intent(Settings.ACTION_SETTINGS), "Opening Settings")

            // ── Web Search ────────────────────────────────────────────────────
            lower.contains("search for") || lower.contains("google") || lower.contains("search") ->
                routeWebSearch(command)

            // ── Navigation ────────────────────────────────────────────────────
            lower.contains("navigate to") || lower.contains("directions to") || lower.contains("take me to") ->
                routeNavigation(command)

            // ── YouTube ───────────────────────────────────────────────────────
            lower.contains("play") && lower.contains("youtube") ->
                routeYouTube(command)

            // ── WhatsApp ──────────────────────────────────────────────────────
            lower.contains("whatsapp") || lower.contains("message") ->
                routeWhatsApp(command)

            else -> RoutedIntent.NotFound("No matching intent for: $command")
        }
    }

    // ── App Launch ────────────────────────────────────────────────────────────

    private fun routeAppLaunch(command: String): RoutedIntent {
        val appName = command.extractAppName() ?: return RoutedIntent.NotFound("Couldn't find app name")
        val intent  = getAppLaunchIntent(appName)
            ?: return RoutedIntent.NotFound("App not found: $appName")
        return RoutedIntent.Resolved(intent, "Opening $appName")
    }

    fun getAppLaunchIntent(appName: String): Intent? {
        val pm = context.packageManager
        val packages = pm.getInstalledPackages(PackageManager.GET_META_DATA)
        val query = appName.lowercase().trim()

        // Exact label match first
        val exactMatch = packages.firstOrNull { pkg ->
            pm.getApplicationLabel(pkg.applicationInfo)
                .toString().lowercase() == query
        }
        if (exactMatch != null) {
            return pm.getLaunchIntentForPackage(exactMatch.packageName)
                ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        // Fuzzy match — package name or label contains query
        val fuzzy = packages.firstOrNull { pkg ->
            val label = pm.getApplicationLabel(pkg.applicationInfo).toString().lowercase()
            label.contains(query) || pkg.packageName.lowercase().contains(query)
        }
        return fuzzy?.let {
            pm.getLaunchIntentForPackage(it.packageName)
                ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    // ── Phone Call ────────────────────────────────────────────────────────────

    private fun routePhoneCall(command: String): RoutedIntent {
        val contactName = command.extractContactName()
            ?: return RoutedIntent.NotFound("No contact name found")
        val phone = lookupContactPhone(contactName)

        return if (phone != null) {
            val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$phone"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            RoutedIntent.Resolved(intent, "Calling $contactName")
        } else {
            // Dial without number — let user search
            val intent = Intent(Intent.ACTION_DIAL)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            RoutedIntent.Resolved(intent, "Opening dialler")
        }
    }

    private fun lookupContactPhone(name: String): String? {
        return try {
            val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER)
            val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
            val selectionArgs = arrayOf("%$name%")
            context.contentResolver.query(uri, projection, selection, selectionArgs, null)
                ?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        cursor.getString(cursor.getColumnIndexOrThrow(
                            ContactsContract.CommonDataKinds.Phone.NUMBER
                        ))
                    } else null
                }
        } catch (e: Exception) { null }
    }

    // ── Alarm ─────────────────────────────────────────────────────────────────

    private fun routeAlarm(command: String): RoutedIntent {
        val timeStr = command.extractTime()
        val intent  = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS Alarm")
            if (timeStr != null) {
                // Parse time string
                val parts = timeStr.replace(Regex("\\s*(am|pm)", RegexOption.IGNORE_CASE), "").split(":")
                val hour   = parts[0].trim().toIntOrNull() ?: 7
                val minute = if (parts.size > 1) parts[1].trim().toIntOrNull() ?: 0 else 0
                val amPm   = if (timeStr.lowercase().contains("pm") && hour < 12) 12 else 0
                putExtra(AlarmClock.EXTRA_HOUR, hour + amPm)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
            }
        }
        return RoutedIntent.Resolved(intent, "Setting alarm${if (timeStr != null) " for $timeStr" else ""}")
    }

    // ── Settings ──────────────────────────────────────────────────────────────

    private fun routeWifiSettings() = RoutedIntent.Resolved(
        Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        "Opening WiFi Settings"
    )

    private fun routeBluetoothSettings() = RoutedIntent.Resolved(
        Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        "Opening Bluetooth Settings"
    )

    // ── Web Search ────────────────────────────────────────────────────────────

    private fun routeWebSearch(command: String): RoutedIntent {
        val query = command
            .replace(Regex("search for|google|search", RegexOption.IGNORE_CASE), "")
            .trim()
        val intent = Intent(Intent.ACTION_VIEW,
            Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return RoutedIntent.Resolved(intent, "Searching for $query")
    }

    // ── Navigation ────────────────────────────────────────────────────────────

    private fun routeNavigation(command: String): RoutedIntent {
        val destination = command
            .replace(Regex("navigate to|directions to|take me to", RegexOption.IGNORE_CASE), "")
            .trim()
        val uri = Uri.parse("google.navigation:q=${Uri.encode(destination)}")
        val intent = Intent(Intent.ACTION_VIEW, uri)
            .setPackage("com.google.android.apps.maps")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        return if (isIntentResolvable(intent)) {
            RoutedIntent.Resolved(intent, "Navigating to $destination")
        } else {
            val fallback = Intent(Intent.ACTION_VIEW,
                Uri.parse("https://maps.google.com/?q=${Uri.encode(destination)}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            RoutedIntent.Resolved(fallback, "Navigating to $destination")
        }
    }

    // ── YouTube ───────────────────────────────────────────────────────────────

    private fun routeYouTube(command: String): RoutedIntent {
        val query = command
            .replace(Regex("play|on youtube|youtube", RegexOption.IGNORE_CASE), "")
            .trim()
        val intent = Intent(Intent.ACTION_VIEW,
            Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return RoutedIntent.Resolved(intent, "Playing $query on YouTube")
    }

    // ── WhatsApp ──────────────────────────────────────────────────────────────

    private fun routeWhatsApp(command: String): RoutedIntent {
        val pm = context.packageManager
        val whatsAppIntent = pm.getLaunchIntentForPackage("com.whatsapp")
            ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (whatsAppIntent != null) {
            RoutedIntent.Resolved(whatsAppIntent, "Opening WhatsApp")
        } else {
            RoutedIntent.NotFound("WhatsApp not installed")
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun isIntentResolvable(intent: Intent): Boolean =
        context.packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY) != null

    fun launchIntent(intent: Intent) {
        context.startActivity(intent)
    }
}
