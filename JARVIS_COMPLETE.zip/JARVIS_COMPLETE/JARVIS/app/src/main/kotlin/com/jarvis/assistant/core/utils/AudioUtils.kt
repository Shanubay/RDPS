package com.jarvis.assistant.core.utils

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import com.jarvis.assistant.core.di.IoDispatcher
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.coroutineContext
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * AudioUtils — provides raw PCM audio capture and amplitude analysis.
 *
 * Used by:
 * • Wake word detection → raw PCM buffer
 * • UI waveform visualizer → amplitude levels
 * • Voice tone analysis → RMS + zero crossing rate
 */
@Singleton
class AudioUtils @Inject constructor(
    @ApplicationContext private val context: Context,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) {

    companion object {
        const val SAMPLE_RATE       = 16000   // 16kHz — optimal for speech
        const val CHANNEL_CONFIG    = AudioFormat.CHANNEL_IN_MONO
        const val AUDIO_FORMAT      = AudioFormat.ENCODING_PCM_16BIT
        const val BUFFER_SIZE_MULT  = 2
        const val SILENCE_THRESHOLD = 500     // RMS below this = silence
    }

    val minBufferSize: Int by lazy {
        AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT)
            .let { if (it <= 0) 3200 else it * BUFFER_SIZE_MULT }
    }

    /**
     * Continuously capture audio and emit amplitude levels (0.0 - 1.0).
     * Used for the waveform UI visualizer.
     */
    fun amplitudeFlow(): Flow<Float> = flow {
        var recorder: AudioRecord? = null
        try {
            recorder = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT, minBufferSize
            )
            if (recorder.state != AudioRecord.STATE_INITIALIZED) {
                emit(0f); return@flow
            }
            recorder.startRecording()
            val buffer = ShortArray(minBufferSize / 2)
            while (coroutineContext.isActive) {
                val read = recorder.read(buffer, 0, buffer.size)
                if (read > 0) {
                    val rms = computeRms(buffer, read)
                    val amplitude = (rms / 8000f).coerceIn(0f, 1f)
                    emit(amplitude)
                }
            }
        } finally {
            recorder?.stop()
            recorder?.release()
        }
    }.flowOn(ioDispatcher)

    /**
     * Capture raw PCM buffers — used by wake word and Vosk STT.
     * Emits pairs of (ShortArray samples, read count).
     */
    fun pcmBufferFlow(): Flow<Pair<ShortArray, Int>> = flow {
        var recorder: AudioRecord? = null
        try {
            recorder = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT, minBufferSize
            )
            if (recorder.state != AudioRecord.STATE_INITIALIZED) return@flow
            recorder.startRecording()
            val buffer = ShortArray(minBufferSize / 2)
            while (coroutineContext.isActive) {
                val read = recorder.read(buffer, 0, buffer.size)
                if (read > 0) emit(Pair(buffer.copyOf(), read))
            }
        } finally {
            recorder?.stop()
            recorder?.release()
        }
    }.flowOn(ioDispatcher)

    /**
     * Compute RMS (Root Mean Square) amplitude of PCM samples.
     */
    fun computeRms(buffer: ShortArray, count: Int): Float {
        if (count == 0) return 0f
        var sum = 0.0
        for (i in 0 until count) sum += buffer[i].toDouble() * buffer[i].toDouble()
        return sqrt(sum / count).toFloat()
    }

    /**
     * Detect voice activity — returns true if audio contains speech.
     */
    fun isVoiceActive(buffer: ShortArray, count: Int): Boolean =
        computeRms(buffer, count) > SILENCE_THRESHOLD

    /**
     * Zero Crossing Rate — correlates with voice frequency / emotion.
     */
    fun zeroCrossingRate(buffer: ShortArray, count: Int): Float {
        if (count < 2) return 0f
        var crossings = 0
        for (i in 1 until count) {
            if ((buffer[i] >= 0) != (buffer[i - 1] >= 0)) crossings++
        }
        return crossings.toFloat() / count
    }

    /**
     * Detect emotion from voice characteristics.
     */
    fun detectEmotion(buffer: ShortArray, count: Int): VoiceEmotion {
        val rms = computeRms(buffer, count)
        val zcr = zeroCrossingRate(buffer, count)
        return when {
            rms > 5000 && zcr > 0.05f -> VoiceEmotion.EXCITED
            rms > 3000 && zcr < 0.03f -> VoiceEmotion.STRESSED
            rms < 1000                 -> VoiceEmotion.CALM
            else                       -> VoiceEmotion.NEUTRAL
        }
    }

    /**
     * Convert 16-bit PCM ShortArray to ByteArray for Vosk.
     */
    fun shortsToBytesLittleEndian(shorts: ShortArray, count: Int): ByteArray {
        val bytes = ByteArray(count * 2)
        for (i in 0 until count) {
            bytes[i * 2]     = (shorts[i].toInt() and 0xFF).toByte()
            bytes[i * 2 + 1] = (shorts[i].toInt() shr 8 and 0xFF).toByte()
        }
        return bytes
    }

    enum class VoiceEmotion { CALM, NEUTRAL, EXCITED, STRESSED }
}
