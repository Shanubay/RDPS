package com.jarvis.assistant.data.local.dao

import androidx.room.*
import com.jarvis.assistant.data.local.entities.ConversationEntity
import com.jarvis.assistant.data.local.entities.MessageEntity
import kotlinx.coroutines.flow.Flow

// ══════════════════════════════════════════════════════════════════════════════
// ConversationDao — Room DAO for conversations and messages
// ══════════════════════════════════════════════════════════════════════════════

@Dao
interface ConversationDao {

    // ── Conversations ─────────────────────────────────────────────────────────

    @Query("SELECT * FROM conversations ORDER BY updated_at DESC")
    fun getAllConversations(): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations WHERE id = :id LIMIT 1")
    suspend fun getConversationById(id: String): ConversationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConversation(conversation: ConversationEntity)

    @Update
    suspend fun updateConversation(conversation: ConversationEntity)

    @Query("DELETE FROM conversations WHERE id = :id")
    suspend fun deleteConversation(id: String)

    @Query("DELETE FROM conversations")
    suspend fun deleteAllConversations()

    @Query("UPDATE conversations SET message_count = message_count + 1, updated_at = :timestamp WHERE id = :conversationId")
    suspend fun incrementMessageCount(conversationId: String, timestamp: Long)

    @Query("UPDATE conversations SET title = :title WHERE id = :id")
    suspend fun updateTitle(id: String, title: String)

    @Query("UPDATE conversations SET summary = :summary WHERE id = :id")
    suspend fun updateSummary(id: String, summary: String)

    // ── Messages ──────────────────────────────────────────────────────────────

    @Query("""
        SELECT * FROM messages 
        WHERE conversation_id = :conversationId 
        ORDER BY timestamp ASC
    """)
    fun getMessagesForConversation(conversationId: String): Flow<List<MessageEntity>>

    @Query("""
        SELECT * FROM messages 
        ORDER BY timestamp DESC 
        LIMIT :limit
    """)
    fun getRecentMessages(limit: Int): Flow<List<MessageEntity>>

    @Query("""
        SELECT * FROM messages 
        ORDER BY timestamp DESC 
        LIMIT :limit
    """)
    suspend fun getRecentMessagesOnce(limit: Int): List<MessageEntity>

    @Query("SELECT * FROM messages WHERE id = :id LIMIT 1")
    suspend fun getMessageById(id: String): MessageEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessages(messages: List<MessageEntity>)

    @Update
    suspend fun updateMessage(message: MessageEntity)

    @Query("DELETE FROM messages WHERE id = :id")
    suspend fun deleteMessage(id: String)

    @Query("DELETE FROM messages WHERE conversation_id = :conversationId")
    suspend fun deleteMessagesForConversation(conversationId: String)

    @Query("""
        SELECT * FROM messages 
        WHERE content LIKE '%' || :query || '%'
        ORDER BY timestamp DESC
        LIMIT 50
    """)
    fun searchMessages(query: String): Flow<List<MessageEntity>>

    @Query("SELECT COUNT(*) FROM messages WHERE conversation_id = :conversationId")
    suspend fun getMessageCount(conversationId: String): Int

    @Query("""
        SELECT * FROM messages 
        WHERE conversation_id = :conversationId 
        ORDER BY timestamp DESC 
        LIMIT :limit
    """)
    suspend fun getLastNMessages(conversationId: String, limit: Int): List<MessageEntity>

    @Query("UPDATE messages SET status = :status WHERE id = :id")
    suspend fun updateMessageStatus(id: String, status: String)

    @Query("UPDATE messages SET content = :content WHERE id = :id")
    suspend fun updateMessageContent(id: String, content: String)

    // ── Stats ─────────────────────────────────────────────────────────────────

    @Query("SELECT COUNT(*) FROM messages")
    suspend fun getTotalMessageCount(): Int

    @Query("SELECT SUM(token_count) FROM messages WHERE role = 'ASSISTANT'")
    suspend fun getTotalTokensGenerated(): Long?
}
