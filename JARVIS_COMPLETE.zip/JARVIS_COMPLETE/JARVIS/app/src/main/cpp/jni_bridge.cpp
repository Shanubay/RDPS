// jni_bridge.cpp — JARVIS llama.cpp JNI Bridge
// Connects Kotlin/JVM to native llama.cpp inference engine

#include <jni.h>
#include <string>
#include <vector>
#include <android/log.h>
#include <functional>
#include <memory>
#include <atomic>

#define LOG_TAG "JARVIS_LLM"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// ── Conditional llama.cpp include ─────────────────────────────────────────────
#if __has_include("llama.cpp/llama.h")
    #include "llama.cpp/llama.h"
    #define LLAMA_AVAILABLE 1
#else
    #define LLAMA_AVAILABLE 0
    LOGI("llama.cpp not found — stub mode active");
#endif

// ── Global state ──────────────────────────────────────────────────────────────
static std::atomic<bool> g_stop_generation{false};

#if LLAMA_AVAILABLE
static llama_model*   g_model   = nullptr;
static llama_context* g_context = nullptr;
#endif

// ── Helper: JString to std::string ───────────────────────────────────────────
static std::string jstring_to_string(JNIEnv* env, jstring jstr) {
    if (!jstr) return "";
    const char* chars = env->GetStringUTFChars(jstr, nullptr);
    std::string result(chars);
    env->ReleaseStringUTFChars(jstr, chars);
    return result;
}

// ── Helper: Invoke Kotlin token callback ─────────────────────────────────────
static void invoke_token_callback(JNIEnv* env, jobject callback, const std::string& token) {
    jclass cls = env->GetObjectClass(callback);
    jmethodID method = env->GetMethodID(cls, "onToken", "(Ljava/lang/String;)V");
    if (method) {
        jstring jtoken = env->NewStringUTF(token.c_str());
        env->CallVoidMethod(callback, method, jtoken);
        env->DeleteLocalRef(jtoken);
    }
    env->DeleteLocalRef(cls);
}

extern "C" {

// ── Load model from file path ─────────────────────────────────────────────────
JNIEXPORT jboolean JNICALL
Java_com_jarvis_assistant_core_llm_LlamaEngine_loadModel(
        JNIEnv* env, jobject /* this */,
        jstring model_path, jint n_ctx, jint n_threads) {

#if LLAMA_AVAILABLE
    std::string path = jstring_to_string(env, model_path);
    LOGI("Loading model: %s", path.c_str());

    // Free previous model if any
    if (g_context) { llama_free(g_context);        g_context = nullptr; }
    if (g_model)   { llama_free_model(g_model);    g_model   = nullptr; }

    // Model parameters
    llama_model_params model_params = llama_model_default_params();
    model_params.n_gpu_layers = 0;  // CPU only on mobile

    g_model = llama_load_model_from_file(path.c_str(), model_params);
    if (!g_model) {
        LOGE("Failed to load model: %s", path.c_str());
        return JNI_FALSE;
    }

    // Context parameters
    llama_context_params ctx_params = llama_context_default_params();
    ctx_params.n_ctx      = (uint32_t) n_ctx;
    ctx_params.n_threads  = (uint32_t) n_threads;
    ctx_params.n_batch    = 512;

    g_context = llama_new_context_with_model(g_model, ctx_params);
    if (!g_context) {
        LOGE("Failed to create context");
        llama_free_model(g_model);
        g_model = nullptr;
        return JNI_FALSE;
    }

    LOGI("Model loaded successfully");
    return JNI_TRUE;
#else
    LOGI("loadModel (stub): %s", jstring_to_string(env, model_path).c_str());
    return JNI_TRUE;  // stub always succeeds
#endif
}

// ── Check if model is loaded ──────────────────────────────────────────────────
JNIEXPORT jboolean JNICALL
Java_com_jarvis_assistant_core_llm_LlamaEngine_isModelLoaded(
        JNIEnv* env, jobject /* this */) {
#if LLAMA_AVAILABLE
    return (g_model != nullptr && g_context != nullptr) ? JNI_TRUE : JNI_FALSE;
#else
    return JNI_FALSE;
#endif
}

// ── Stream inference with token callbacks ─────────────────────────────────────
JNIEXPORT jstring JNICALL
Java_com_jarvis_assistant_core_llm_LlamaEngine_generate(
        JNIEnv* env, jobject /* this */,
        jstring prompt_jstr, jint max_tokens, jfloat temperature,
        jobject callback) {

    std::string prompt = jstring_to_string(env, prompt_jstr);
    g_stop_generation.store(false);

#if LLAMA_AVAILABLE
    if (!g_model || !g_context) {
        return env->NewStringUTF("[ERROR: No model loaded]");
    }

    // Tokenize prompt
    int n_prompt_tokens = -llama_tokenize(
        g_model, prompt.c_str(), prompt.size(), nullptr, 0, true, true);
    if (n_prompt_tokens <= 0) {
        return env->NewStringUTF("[ERROR: Tokenization failed]");
    }

    std::vector<llama_token> tokens(n_prompt_tokens);
    llama_tokenize(g_model, prompt.c_str(), prompt.size(),
                   tokens.data(), tokens.size(), true, true);

    // Eval prompt
    llama_kv_cache_clear(g_context);
    for (int i = 0; i < (int)tokens.size(); i += 512) {
        int batch = std::min(512, (int)tokens.size() - i);
        if (llama_decode(g_context,
                llama_batch_get_one(tokens.data() + i, batch, i, 0))) {
            return env->NewStringUTF("[ERROR: Prompt eval failed]");
        }
    }

    // Sampling
    llama_token eos_token = llama_token_eos(g_model);
    std::string result;
    result.reserve(1024);

    auto sparams = llama_sampler_chain_default_params();
    llama_sampler* sampler = llama_sampler_chain_init(sparams);
    llama_sampler_chain_add(sampler, llama_sampler_init_temp(temperature));
    llama_sampler_chain_add(sampler, llama_sampler_init_dist(0));

    for (int i = 0; i < max_tokens && !g_stop_generation.load(); i++) {
        llama_token token = llama_sampler_sample(sampler, g_context, -1);
        if (token == eos_token) break;

        char token_buf[256] = {};
        int32_t n = llama_token_to_piece(g_model, token, token_buf, sizeof(token_buf), 0, true);
        if (n > 0) {
            std::string piece(token_buf, n);
            result += piece;

            // Stream token to Kotlin callback
            if (callback) {
                invoke_token_callback(env, callback, piece);
            }
        }

        // Eval generated token
        llama_decode(g_context, llama_batch_get_one(&token, 1, tokens.size() + i, 0));
    }

    llama_sampler_free(sampler);
    return env->NewStringUTF(result.c_str());

#else
    // Stub response when llama.cpp not compiled
    std::string stub = "I am JARVIS, running in stub mode. Compile llama.cpp for full offline AI.";
    if (callback) {
        // Stream word by word as a demo
        std::string word;
        for (char ch : stub) {
            word += ch;
            if (ch == ' ' || ch == '.') {
                invoke_token_callback(env, callback, word);
                word.clear();
            }
        }
        if (!word.empty()) invoke_token_callback(env, callback, word);
    }
    return env->NewStringUTF(stub.c_str());
#endif
}

// ── Stop ongoing generation ───────────────────────────────────────────────────
JNIEXPORT void JNICALL
Java_com_jarvis_assistant_core_llm_LlamaEngine_stopGeneration(
        JNIEnv* env, jobject /* this */) {
    g_stop_generation.store(true);
    LOGI("Generation stop requested");
}

// ── Unload model and free memory ──────────────────────────────────────────────
JNIEXPORT void JNICALL
Java_com_jarvis_assistant_core_llm_LlamaEngine_unloadModel(
        JNIEnv* env, jobject /* this */) {
#if LLAMA_AVAILABLE
    if (g_context) { llama_free(g_context);     g_context = nullptr; }
    if (g_model)   { llama_free_model(g_model); g_model   = nullptr; }
    LOGI("Model unloaded");
#endif
}

// ── Get model context size ────────────────────────────────────────────────────
JNIEXPORT jint JNICALL
Java_com_jarvis_assistant_core_llm_LlamaEngine_getContextSize(
        JNIEnv* env, jobject /* this */) {
#if LLAMA_AVAILABLE
    if (g_context) return (jint) llama_n_ctx(g_context);
#endif
    return 0;
}

// ── Get vocabulary size ───────────────────────────────────────────────────────
JNIEXPORT jint JNICALL
Java_com_jarvis_assistant_core_llm_LlamaEngine_getVocabSize(
        JNIEnv* env, jobject /* this */) {
#if LLAMA_AVAILABLE
    if (g_model) return (jint) llama_n_vocab(g_model);
#endif
    return 0;
}

} // extern "C"
