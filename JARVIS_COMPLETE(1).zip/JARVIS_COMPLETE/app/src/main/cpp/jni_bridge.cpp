#include <jni.h>
#include <string>
#include <android/log.h>

#define LOG_TAG "JarvisLLM"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

#if LLAMA_AVAILABLE
#include "llama.h"
#endif

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_jarvis_assistant_core_llm_LlamaEngine_nativeLoadModel(
        JNIEnv* env, jobject, jstring modelPath, jint nCtx, jint nThreads) {
#if LLAMA_AVAILABLE
    const char* path = env->GetStringUTFChars(modelPath, nullptr);
    llama_model_params params = llama_model_default_params();
    llama_model* model = llama_load_model_from_file(path, params);
    env->ReleaseStringUTFChars(modelPath, path);
    return model != nullptr ? JNI_TRUE : JNI_FALSE;
#else
    LOGI("nativeLoadModel: stub mode");
    return JNI_FALSE;
#endif
}

JNIEXPORT jboolean JNICALL
Java_com_jarvis_assistant_core_llm_LlamaEngine_nativeIsModelLoaded(
        JNIEnv* env, jobject) {
#if LLAMA_AVAILABLE
    return JNI_TRUE;
#else
    LOGI("nativeIsModelLoaded: stub mode");
    return JNI_FALSE;
#endif
}

JNIEXPORT jstring JNICALL
Java_com_jarvis_assistant_core_llm_LlamaEngine_nativeGenerate(
        JNIEnv* env, jobject, jstring prompt, jint maxTokens, jfloat temperature, jobject callback) {
#if LLAMA_AVAILABLE
    const char* p = env->GetStringUTFChars(prompt, nullptr);
    LOGI("nativeGenerate: %s", p);
    env->ReleaseStringUTFChars(prompt, p);
    return env->NewStringUTF("");
#else
    LOGI("nativeGenerate: stub mode");
    return env->NewStringUTF("[STUB: Load a local GGUF model to use offline AI]");
#endif
}

JNIEXPORT void JNICALL
Java_com_jarvis_assistant_core_llm_LlamaEngine_nativeStopGeneration(
        JNIEnv* env, jobject) {
    LOGI("nativeStopGeneration called");
}

JNIEXPORT void JNICALL
Java_com_jarvis_assistant_core_llm_LlamaEngine_nativeUnloadModel(
        JNIEnv* env, jobject) {
    LOGI("nativeUnloadModel called");
}

JNIEXPORT jint JNICALL
Java_com_jarvis_assistant_core_llm_LlamaEngine_nativeGetContextSize(
        JNIEnv* env, jobject) {
    return 0;
}

JNIEXPORT jint JNICALL
Java_com_jarvis_assistant_core_llm_LlamaEngine_nativeGetVocabSize(
        JNIEnv* env, jobject) {
    return 0;
}

JNIEXPORT jstring JNICALL
Java_com_jarvis_assistant_core_llm_LlamaEngine_nativeGetVersion(
        JNIEnv* env, jobject) {
    return env->NewStringUTF("stub-1.0");
}

} // extern "C"
