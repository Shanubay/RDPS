package com.jarvis.assistant.core.di

import android.content.Context
import com.jarvis.assistant.core.utils.BatteryUtils
import com.jarvis.assistant.core.utils.NetworkUtils
import com.jarvis.assistant.core.utils.TimeUtils
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object UtilsModule {

    @Provides @Singleton
    fun provideTimeUtils() = TimeUtils()

    @Provides @Singleton
    fun provideBatteryUtils(@ApplicationContext context: Context) = BatteryUtils(context)

    @Provides @Singleton
    fun provideNetworkUtils(@ApplicationContext context: Context) = NetworkUtils(context)
}
