package com.jarvis.assistant.core.llm

import com.jarvis.assistant.core.constants.AppConstants
import com.jarvis.assistant.core.di.IoDispatcher
import com.jarvis.assistant.domain.entities.Message
import com.jarvis.assistant.domain.entities.MessageRole
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LlamaEngine @Inject constructor(
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) {

    companion object {
        private const val TAG = "LlamaEngine"
        private var nativeLibLoaded = false

        init {
            try {
                System.loadLibrary("jarvis-llm")
                nativeLibLoaded = true
                android.util.Log.i(TAG, "llama.cpp JNI bridge loaded")
            } catch (e: UnsatisfiedLinkError) {
                android.util.Log.w(TAG, "Native lib not found — stub mode")
                nativeLibLoaded = false
            }
        }
    }

    // ── Native declarations (prefixed with 'native' to avoid clash) ───────────
    private external fun nativeLoadModel(modelPath: String, nCtx: Int, nThreads: Int): Boolean
    private external fun nativeIsModelLoaded(): Boolean
    private external fun nativeGenerate(prompt: String, maxTokens: Int, temperature: Float, cb: TokenCallback): String
    private external fun nativeStopGeneration()
    private external fun nativeUnloadModel()
    private external fun nativeGetContextSize(): Int
    private external fun nativeGetVocabSize(): Int

    interface TokenCallback { fun onToken(token: String) }

    // ── Public API ─────────────────────────────────────────────────────────────

    suspend fun loadModel(
        modelPath: String,
        contextSize: Int = AppConstants.MODEL_CONTEXT_SIZE,
        threads: Int     = AppConstants.MODEL_THREADS_DEFAULT
    ): Boolean = withContext(ioDispatcher) {
        if (!nativeLibLoaded) return@withContext false
        try { nativeLoadModel(modelPath, contextSize, threads) }
        catch (e: Exception) { false }
    }

    fun isModelLoaded(): Boolean {
        if (!nativeLibLoaded) return false
        return try { nativeIsModelLoaded() } catch (e: Exception) { false }
    }

    fun streamGenerate(
        prompt: String,
        maxTokens: Int  = AppConstants.DEFAULT_MAX_TOKENS,
        temperature: Float = AppConstants.DEFAULT_TEMPERATURE
    ): Flow<String> = callbackFlow {
        if (!nativeLibLoaded || !isModelLoaded()) {
            send("Running in stub mode. Load a local model from Model Manager.")
            close()
            return@callbackFlow
        }
        val cb = object : TokenCallback {
            override fun onToken(token: String) { trySend(token) }
        }
        try {
            withContext(ioDispatcher) {
                nativeGenerate(prompt, maxTokens, temperature, cb)
            }
        } catch (e: Exception) {
            android.util.Log.e(TAG, "Generation error", e)
        } finally { close() }
        awaitClose {
            if (nativeLibLoaded) try { nativeStopGeneration() } catch (_: Exception) {}
        }
    }.flowOn(ioDispatcher)

    suspend fun unloadModel() = withContext(ioDispatcher) {
        if (!nativeLibLoaded) return@withContext
        try { nativeUnloadModel() } catch (_: Exception) {}
    }

    fun getContextSize(): Int {
        if (!nativeLibLoaded) return 0
        return try { nativeGetContextSize() } catch (e: Exception) { 0 }
    }

    fun getVocabSize(): Int {
        if (!nativeLibLoaded) return 0
        return try { nativeGetVocabSize() } catch (e: Exception) { 0 }
    }

    fun formatPrompt(systemPrompt: String, messages: List<Message>): String {
        val sb = StringBuilder()
        sb.append("<|im_start|>system\n$systemPrompt\n<|im_end|>\n")
        messages.takeLast(10).forEach { msg ->
            val role = when (msg.role) {
                MessageRole.USER      -> "user"
                MessageRole.ASSISTANT -> "assistant"
                MessageRole.SYSTEM    -> "system"
            }
            sb.append("<|im_start|>$role\n${msg.content}\n<|im_end|>\n")
        }
        sb.append("<|im_start|>assistant\n")
        return sb.toString()
    }
}
