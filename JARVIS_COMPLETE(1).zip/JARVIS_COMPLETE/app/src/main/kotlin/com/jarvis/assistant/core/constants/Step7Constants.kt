package com.jarvis.assistant.core.constants

// Step7Constants — additional notification IDs and TTS params
// (Actions are in AppConstants.Actions)

object Step7Constants {
    const val TTS_DEFAULT_SPEED  = 1.0f
    const val TTS_DEFAULT_PITCH  = 1.0f
    const val TTS_WHISPER_SPEED  = 0.75f
    const val TTS_WHISPER_PITCH  = 0.9f

    const val NOTIFICATION_ID_VOICE   = 1001
    const val NOTIFICATION_ID_OVERLAY = 1002
    const val NOTIFICATION_ID_AI      = 1003
    const val NOTIFICATION_ID_DEVICE  = 1004

    const val TOKEN_THRESHOLD_FAST    = 150
    const val TOKEN_THRESHOLD_COMPLEX = 800
}
