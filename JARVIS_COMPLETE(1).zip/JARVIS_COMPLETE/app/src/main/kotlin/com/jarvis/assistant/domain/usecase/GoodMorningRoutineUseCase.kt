package com.jarvis.assistant.domain.usecase

import com.jarvis.assistant.core.utils.TimeUtils
import com.jarvis.assistant.domain.repository.AIRepository
import com.jarvis.assistant.domain.repository.MemoryRepository
import javax.inject.Inject

class GoodMorningRoutineUseCase @Inject constructor(
    private val aiRepository: AIRepository,
    private val memoryRepository: MemoryRepository,
    private val timeUtils: TimeUtils
) {
    suspend fun execute(userName: String): String {
        val time = timeUtils.formatCurrentTime()
        val date = timeUtils.formatCurrentDate()
        val greeting = when (timeUtils.currentTimeOfDay) {
            TimeUtils.TimeOfDay.EARLY_MORNING -> "Good early morning"
            TimeUtils.TimeOfDay.MORNING       -> "Good morning"
            TimeUtils.TimeOfDay.AFTERNOON     -> "Good afternoon"
            TimeUtils.TimeOfDay.EVENING       -> "Good evening"
            TimeUtils.TimeOfDay.NIGHT         -> "Good evening"
        }

        val name = if (userName.isNotBlank()) ", $userName" else ""
        return "$greeting$name. It's $time on $date. All systems are online and ready."
    }
}
