package com.jarvis.assistant.data.repository

import com.jarvis.assistant.core.constants.AppConstants
import com.jarvis.assistant.core.utils.AppPreferences
import com.jarvis.assistant.data.remote.AIRouter
import com.jarvis.assistant.data.remote.api.ElevenLabsApi
import com.jarvis.assistant.data.remote.dto.ElevenLabsTtsRequest
import com.jarvis.assistant.data.remote.dto.ElevenLabsVoiceSettings
import com.jarvis.assistant.domain.entities.Message
import com.jarvis.assistant.domain.repository.AIRepository
import com.google.gson.Gson
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.File
import java.io.FileOutputStream
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AIRepositoryImpl @Inject constructor(
    private val aiRouter: AIRouter,
    private val prefs: AppPreferences,
    private val gson: Gson,
    private val okHttpClient: OkHttpClient
) : AIRepository {

    // ── Chat Completion ───────────────────────────────────────────────────────

    override suspend fun complete(
        messages: List<Message>,
        systemPrompt: String,
        provider: String,
        maxTokens: Int
    ): Result<String> = runCatching {
        val routing = aiRouter.selectProvider("", forceProvider = provider)
        routing.provider.complete(messages, systemPrompt, maxTokens)
    }

    override fun stream(
        messages: List<Message>,
        systemPrompt: String,
        provider: String,
        maxTokens: Int
    ): Flow<String> {
        // Build a flow that routes dynamically at subscription time
        return kotlinx.coroutines.flow.flow {
            val routing = aiRouter.selectProvider(
                queryText     = messages.lastOrNull()?.content ?: "",
                forceProvider = provider.ifBlank { null }
            )
            routing.provider.stream(messages, systemPrompt, maxTokens)
                .collect { token -> emit(token) }
        }
    }

    // ── Whisper STT ───────────────────────────────────────────────────────────

    override suspend fun transcribeAudio(audioBytes: ByteArray): Result<String> = runCatching {
        val key = prefs.openAiKey.first()
        if (key.isBlank()) return Result.failure(Exception("OpenAI key not set for Whisper"))

        val api = buildOpenAiApi()

        // Write bytes to temp file
        val tmpFile = File.createTempFile("jarvis_audio", ".wav")
        FileOutputStream(tmpFile).use { it.write(audioBytes) }

        val filePart = MultipartBody.Part.createFormData(
            "file", "audio.wav",
            tmpFile.asRequestBody("audio/wav".toMediaType())
        )
        val modelPart    = "whisper-1".toRequestBody("text/plain".toMediaType())
        val languagePart = "en".toRequestBody("text/plain".toMediaType())

        val response = api.transcribeAudio("Bearer $key", filePart, modelPart, languagePart)
        tmpFile.delete()

        if (!response.isSuccessful) {
            throw Exception("Whisper HTTP ${response.code()}")
        }
        response.body()?.text ?: throw Exception("Empty Whisper response")
    }

    // ── ElevenLabs TTS ────────────────────────────────────────────────────────

    override suspend fun generateSpeech(
        text: String,
        provider: String,
        voiceId: String,
        speed: Float,
        pitch: Float
    ): Result<ByteArray> = runCatching {
        when (provider) {
            AppConstants.TTSProvider.ELEVENLABS -> generateElevenLabsSpeech(text, voiceId)
            else -> throw Exception("Use Android TTS for provider: $provider")
        }
    }

    private suspend fun generateElevenLabsSpeech(text: String, voiceId: String): ByteArray {
        val key = prefs.elevenLabsKey.first()
        if (key.isBlank()) throw Exception("ElevenLabs key not set")

        val api = buildElevenLabsApi()
        val resolvedVoiceId = voiceId.ifBlank { AppConstants.ELEVENLABS_DEFAULT_VOICE }

        val request = ElevenLabsTtsRequest(
            text         = text,
            modelId      = "eleven_turbo_v2",
            voiceSettings = ElevenLabsVoiceSettings(
                stability       = 0.5f,
                similarityBoost = 0.75f,
                style           = 0.0f,
                useSpeakerBoost = true
            )
        )

        val response = api.textToSpeech(key, resolvedVoiceId, "mp3_44100_128", request)
        if (!response.isSuccessful) {
            throw Exception("ElevenLabs HTTP ${response.code()}: ${response.errorBody()?.string()}")
        }
        return response.body()?.bytes() ?: throw Exception("Empty ElevenLabs response")
    }

    // ── API Key Validation ────────────────────────────────────────────────────

    override suspend fun validateApiKey(provider: String, key: String): Boolean {
        return try {
            when (provider) {
                AppConstants.AIProvider.OPENAI -> {
                    // Minimal test request
                    val api = buildOpenAiApi()
                    val req = com.jarvis.assistant.data.remote.dto.OpenAiRequest(
                        model    = "gpt-4o-mini",
                        messages = listOf(
                            com.jarvis.assistant.data.remote.dto.OpenAiMessage("user", "hi")
                        ),
                        maxTokens = 1, stream = false
                    )
                    val resp = api.chatComplete("Bearer $key", req)
                    resp.isSuccessful || resp.code() == 400
                }
                AppConstants.TTSProvider.ELEVENLABS -> {
                    val api = buildElevenLabsApi()
                    val resp = api.validateKey(key)
                    resp.isSuccessful
                }
                else -> key.isNotBlank()
            }
        } catch (e: Exception) { false }
    }

    // ── Retrofit builders ─────────────────────────────────────────────────────

    private fun buildOpenAiApi() =
        Retrofit.Builder()
            .baseUrl(AppConstants.ApiUrl.OPENAI)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()
            .create(com.jarvis.assistant.data.remote.api.OpenAiApi::class.java)

    private fun buildElevenLabsApi() =
        Retrofit.Builder()
            .baseUrl(AppConstants.ApiUrl.ELEVENLABS)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()
            .create(ElevenLabsApi::class.java)
}
