package com.jarvis.assistant.presentation.viewmodel

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.core.constants.AppConstants
import com.jarvis.assistant.core.utils.AppPreferences
import com.jarvis.assistant.domain.entities.VoiceState
import com.jarvis.assistant.service.overlay.OverlayService
import com.jarvis.assistant.service.voice.VoiceOrchestrator
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class OverlayUiState(
    val isOverlayEnabled: Boolean    = false,
    val hasOverlayPermission: Boolean = false,
    val isExpanded: Boolean          = false,
    val voiceState: VoiceState       = VoiceState.IDLE,
    val responsePreview: String      = "",
    val amplitude: Float             = 0f,
    val waveform: List<Float>        = List(20) { 0f }
)

@HiltViewModel
class OverlayViewModel @Inject constructor(
    private val prefs: AppPreferences,
    private val voiceOrchestrator: VoiceOrchestrator
) : ViewModel() {

    private val _uiState = MutableStateFlow(OverlayUiState())
    val uiState: StateFlow<OverlayUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                prefs.overlayEnabled,
                voiceOrchestrator.voiceState,
                voiceOrchestrator.responseText,
                voiceOrchestrator.amplitude,
                voiceOrchestrator.waveform
            ) { overlayEnabled, voiceState, response, amplitude, waveform ->
                _uiState.update { it.copy(
                    isOverlayEnabled = overlayEnabled,
                    voiceState       = voiceState,
                    responsePreview  = response.take(120),
                    amplitude        = amplitude,
                    waveform         = waveform
                )}
            }.collect()
        }
    }

    fun checkOverlayPermission(context: Context): Boolean {
        val hasPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            Settings.canDrawOverlays(context) else true
        _uiState.update { it.copy(hasOverlayPermission = hasPermission) }
        return hasPermission
    }

    fun requestOverlayPermission(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            ).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
            context.startActivity(intent)
        }
    }

    fun showOverlay(context: Context) {
        if (!checkOverlayPermission(context)) {
            requestOverlayPermission(context)
            return
        }
        context.startService(
            Intent(context, OverlayService::class.java).apply {
                action = AppConstants.Actions.SHOW_OVERLAY
            }
        )
        _uiState.update { it.copy(isOverlayEnabled = true) }
        viewModelScope.launch { prefs.setOverlayEnabled(true) }
    }

    fun hideOverlay(context: Context) {
        context.startService(
            Intent(context, OverlayService::class.java).apply {
                action = AppConstants.Actions.HIDE_OVERLAY
            }
        )
        _uiState.update { it.copy(isOverlayEnabled = false) }
        viewModelScope.launch { prefs.setOverlayEnabled(false) }
    }

    fun toggleExpanded() {
        _uiState.update { it.copy(isExpanded = !it.isExpanded) }
    }
}
