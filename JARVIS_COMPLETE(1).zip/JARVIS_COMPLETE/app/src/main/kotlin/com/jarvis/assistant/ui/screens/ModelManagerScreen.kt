package com.jarvis.assistant.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.*
import com.jarvis.assistant.domain.entities.AIModel
import com.jarvis.assistant.domain.entities.ModelStatus
import com.jarvis.assistant.presentation.viewmodel.ModelManagerUiState
import com.jarvis.assistant.presentation.viewmodel.ModelManagerViewModel
import com.jarvis.assistant.ui.components.*
import com.jarvis.assistant.ui.theme.*

@Composable
fun ModelManagerScreen(viewModel: ModelManagerViewModel, onBack: () -> Unit) {
    val uiState by viewModel.uiState.collectAsState()

    Column(modifier = Modifier.fillMaxSize().background(JarvisColors.VoidBlack)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(JarvisSpacing.md),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(JarvisSpacing.sm)
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = JarvisColors.CyanCore) }
            Column {
                Text("LOCAL MODELS", style = MaterialTheme.typography.headlineMedium, color = JarvisColors.TextPrimary, letterSpacing = 4.sp)
                Text("ON-DEVICE AI  •  NO INTERNET REQUIRED", style = MaterialTheme.typography.labelSmall, color = JarvisColors.TextMuted, letterSpacing = 2.sp)
            }
        }

        HudDivider()

        // Storage info
        uiState.storageInfo?.let { storage ->
            HudCard(modifier = Modifier.fillMaxWidth().padding(JarvisSpacing.md)) {
                Column(modifier = Modifier.padding(JarvisSpacing.md), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    HudSectionHeader("Storage", accentColor = JarvisColors.GoldAlert)
                    HudProgressBar(
                        progress = if (storage.totalBytes > 0) (storage.usedByModelsGB / storage.totalGB.coerceAtLeast(0.01f)) else 0f,
                        label = "Disk: ${formatBytes(storage.usedBytes)} / ${formatBytes(storage.totalBytes)}"
                    )
                }
            }
        }

        LazyColumn(contentPadding = PaddingValues(JarvisSpacing.md), verticalArrangement = Arrangement.spacedBy(JarvisSpacing.sm)) {
            items(uiState.models) { model ->
                ModelCard(
                    model = model,
                    isDownloading = uiState.downloadingModelId == model.id,
                    downloadProgress = if (uiState.downloadingModelId == model.id) uiState.downloadProgress else 0,
                    isActive = uiState.activeModelId == model.id,
                    isLoadingModel = uiState.isLoadingModel,
                    onDownload = { viewModel.downloadModel(model.id) },
                    onCancel = { viewModel.cancelDownload(model.id) },
                    onDelete = { viewModel.deleteModel(model.id) },
                    onLoad = { viewModel.loadModel(model.id) },
                    onUnload = { viewModel.unloadModel() }
                )
            }
            item { Spacer(Modifier.height(JarvisSpacing.xxl)) }
        }
    }
}

@Composable
private fun ModelCard(
    model: AIModel,
    isDownloading: Boolean,
    downloadProgress: Int,
    isActive: Boolean,
    isLoadingModel: Boolean,
    onDownload: () -> Unit,
    onCancel: () -> Unit,
    onDelete: () -> Unit,
    onLoad: () -> Unit,
    onUnload: () -> Unit
) {
    val accentColor = when {
        isActive -> JarvisColors.GreenOnline
        model.status == ModelStatus.DOWNLOADED -> JarvisColors.CyanCore
        isDownloading -> JarvisColors.GoldAlert
        else -> JarvisColors.TextMuted
    }

    HudCard(modifier = Modifier.fillMaxWidth(), glowColor = accentColor, glowAlpha = if (isActive) 0.4f else 0.15f) {
        Column(modifier = Modifier.padding(JarvisSpacing.md), verticalArrangement = Arrangement.spacedBy(JarvisSpacing.sm)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(model.name, style = MaterialTheme.typography.titleMedium, color = JarvisColors.TextPrimary)
                    Text(model.description.take(60), style = MaterialTheme.typography.bodySmall, color = JarvisColors.TextMuted)
                }
                if (isActive) JarvisStatusLabel("ACTIVE", color = JarvisColors.GreenOnline)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                JarvisChip(text = formatBytes(model.sizeBytes), color = JarvisColors.TextSecondary)
                JarvisChip(text = model.ramRequired, color = JarvisColors.GoldAlert)
                JarvisChip(text = model.quantization, color = JarvisColors.CyanDim)
            }

            if (isDownloading) {
                HudProgressBar(
                    progress = downloadProgress / 100f,
                    label = "Downloading... $downloadProgress%"
                )
            }

            HudDivider()

            Row(horizontalArrangement = Arrangement.spacedBy(JarvisSpacing.sm)) {
                when {
                    isDownloading -> {
                        JarvisButton(text = "Cancel", onClick = onCancel, modifier = Modifier.weight(1f), isDestructive = true)
                    }
                    model.status == ModelStatus.DOWNLOADED || model.status == ModelStatus.LOADED -> {
                        if (isActive) {
                            JarvisButton(text = "Unload", onClick = onUnload, modifier = Modifier.weight(1f), color = JarvisColors.TextSecondary)
                        } else {
                            if (isLoadingModel) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                                    JarvisLoader(size = 16.dp)
                                    Text("Loading...", style = MaterialTheme.typography.bodySmall, color = JarvisColors.CyanCore)
                                }
                            } else {
                                JarvisButton(text = "Load", onClick = onLoad, modifier = Modifier.weight(1f))
                            }
                        }
                        IconButton(onClick = onDelete) {
                            Icon(Icons.Default.DeleteOutline, null, tint = JarvisColors.CrimsonAlert)
                        }
                    }
                    else -> {
                        JarvisButton(text = "Download", onClick = onDownload, modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

private fun formatBytes(bytes: Long): String = when {
    bytes >= 1_073_741_824L -> "${"%.1f".format(bytes / 1_073_741_824.0)} GB"
    bytes >= 1_048_576L -> "${"%.0f".format(bytes / 1_048_576.0)} MB"
    else -> "${"%.0f".format(bytes / 1024.0)} KB"
}
