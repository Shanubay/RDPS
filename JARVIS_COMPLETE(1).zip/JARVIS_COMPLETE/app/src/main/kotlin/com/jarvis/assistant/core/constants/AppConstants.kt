package com.jarvis.assistant.core.constants

// ══════════════════════════════════════════════════════════════════════════════
// AppConstants — JARVIS AI Command Center
// Single source of truth for all constants
// ══════════════════════════════════════════════════════════════════════════════

object AppConstants {

    // ── DataStore keys ────────────────────────────────────────────────────────
    object PrefsKeys {
        const val USER_NAME          = "user_name"
        const val AI_PROVIDER        = "ai_provider"
        const val VOICE_ENABLED      = "voice_enabled"
        const val OVERLAY_ENABLED    = "overlay_enabled"
        const val OFFLINE_MODE       = "offline_mode"
        const val TTS_PROVIDER       = "tts_provider"
        const val OPENAI_KEY         = "openai_key"
        const val GEMINI_KEY         = "gemini_key"
        const val GROQ_KEY           = "groq_key"
        const val OPENROUTER_KEY     = "openrouter_key"
        const val ELEVENLABS_KEY     = "elevenlabs_key"
        const val ELEVENLABS_VOICE_ID = "elevenlabs_voice_id"
    }

    // ── Intent / Broadcast actions ────────────────────────────────────────────
    object Actions {
        const val WAKE_WORD_DETECTED       = "com.jarvis.assistant.WAKE_WORD_DETECTED"
        const val START_LISTENING          = "com.jarvis.assistant.START_LISTENING"
        const val STOP_LISTENING           = "com.jarvis.assistant.STOP_LISTENING"
        const val START_WAKE_WORD          = "com.jarvis.assistant.START_WAKE_WORD"
        const val STOP_WAKE_WORD           = "com.jarvis.assistant.STOP_WAKE_WORD"
        const val SHOW_OVERLAY             = "com.jarvis.assistant.SHOW_OVERLAY"
        const val HIDE_OVERLAY             = "com.jarvis.assistant.HIDE_OVERLAY"
        const val TOGGLE_OVERLAY           = "com.jarvis.assistant.TOGGLE_OVERLAY"
        const val OPEN_MAIN                = "com.jarvis.assistant.OPEN_MAIN"
        const val DEVICE_TOGGLE_FLASHLIGHT = "com.jarvis.assistant.DEVICE_TOGGLE_FLASHLIGHT"
        const val DEVICE_SET_VOLUME        = "com.jarvis.assistant.DEVICE_SET_VOLUME"
        const val DEVICE_SET_BRIGHTNESS    = "com.jarvis.assistant.DEVICE_SET_BRIGHTNESS"
    }

    // ── AI Providers ──────────────────────────────────────────────────────────
    object AIProvider {
        const val LOCAL_LLAMA = "local_llama"
        const val OPENAI      = "openai"
        const val GEMINI      = "gemini"
        const val GROQ        = "groq"
        const val OPENROUTER  = "openrouter"
        const val ELEVENLABS  = "elevenlabs"
    }

    // ── API Base URLs ─────────────────────────────────────────────────────────
    object ApiUrls {
        const val OPENAI      = "https://api.openai.com/v1/"
        const val GEMINI      = "https://generativelanguage.googleapis.com/v1beta/"
        const val GROQ        = "https://api.groq.com/openai/v1/"
        const val OPENROUTER  = "https://openrouter.ai/api/v1/"
        const val ELEVENLABS  = "https://api.elevenlabs.io/v1/"
    }

    // ── TTS ───────────────────────────────────────────────────────────────────
    object TTSProvider {
        const val ANDROID_TTS = "android_tts"
        const val ELEVENLABS  = "elevenlabs"
    }

    // ── Model defaults ────────────────────────────────────────────────────────
    const val DEFAULT_MAX_TOKENS     = 512
    const val DEFAULT_TEMPERATURE    = 0.7f
    const val MODEL_CONTEXT_SIZE     = 2048
    const val MODEL_THREADS_DEFAULT  = 4
    const val MAX_LONG_TERM_MEMORIES = 500
    const val ELEVENLABS_DEFAULT_VOICE = "nPczCjzI2devNBz1zQrb"

    // ── STT ───────────────────────────────────────────────────────────────────
    const val STT_SILENCE_THRESHOLD_MS = 1500L

    // ── Model Catalog ─────────────────────────────────────────────────────────
    object ModelCatalog {
        val PHI3_MINI = ModelInfo(
            id          = "phi3-mini-4k",
            name        = "Phi-3 Mini 4K",
            description = "Microsoft Phi-3 Mini — fast, efficient, great for mobile",
            filename    = "phi3-mini-4k-instruct-q4.gguf",
            sizeBytes   = 2_200_000_000L,
            ramRequired = "3 GB",
            quantization = "Q4_K_M"
        )
        val TINYLLAMA = ModelInfo(
            id          = "tinyllama-1b",
            name        = "TinyLlama 1.1B",
            description = "Tiny but capable — perfect for low-RAM devices",
            filename    = "tinyllama-1.1b-chat-q4.gguf",
            sizeBytes   = 638_000_000L,
            ramRequired = "1 GB",
            quantization = "Q4_K_M"
        )
        val GEMMA2B = ModelInfo(
            id          = "gemma-2b",
            name        = "Gemma 2B",
            description = "Google's Gemma 2B — balanced speed and quality",
            filename    = "gemma-2b-it-q4.gguf",
            sizeBytes   = 1_500_000_000L,
            ramRequired = "2 GB",
            quantization = "Q4_K_M"
        )
        val ALL = listOf(PHI3_MINI, TINYLLAMA, GEMMA2B)
    }
}

data class ModelInfo(
    val id: String,
    val name: String,
    val description: String,
    val filename: String,
    val sizeBytes: Long,
    val ramRequired: String,
    val quantization: String
)
