package com.jarvis.assistant.service.device

import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import com.jarvis.assistant.core.constants.AppConstants
import com.jarvis.assistant.core.utils.NotificationHelper
import com.jarvis.assistant.domain.entities.DeviceState
import com.jarvis.assistant.domain.usecase.DeviceControlUseCase
import com.jarvis.assistant.service.accessibility.JarvisAccessibilityService
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject

/**
 * DeviceControlService — foreground service exposing all hardware control APIs.
 *
 * Responsibilities:
 * • Flashlight (CameraManager torch)
 * • Volume (AudioManager)
 * • Bluetooth (BluetoothAdapter)
 * • WiFi (WifiManager + Settings panel fallback for Android 10+)
 * • Brightness (Settings.System)
 * • DND (NotificationManager)
 * • Screen actions via AccessibilityService bridge
 */
@AndroidEntryPoint
class DeviceControlService : Service() {

    @Inject lateinit var notificationHelper: NotificationHelper
    @Inject lateinit var deviceControlUseCase: DeviceControlUseCase

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    // Current device state broadcast
    private val _deviceState = MutableStateFlow(DeviceState())
    val deviceState: StateFlow<DeviceState> = _deviceState.asStateFlow()

    // Flashlight state (camera manager callback)
    private val _flashlightOn = MutableStateFlow(false)

    inner class DeviceControlBinder : Binder() {
        fun getService() = this@DeviceControlService
    }

    private val binder = DeviceControlBinder()
    override fun onBind(intent: Intent): IBinder = binder

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        startForeground(
            com.jarvis.assistant.JarvisApplication.NOTIFICATION_ID_DEVICE,
            notificationHelper.buildDeviceNotification()
        )
        registerFlashlightCallback()
        startStatePolling()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            AppConstants.Actions.DEVICE_TOGGLE_FLASHLIGHT ->
                toggleFlashlight()
            AppConstants.Actions.DEVICE_SET_VOLUME -> {
                val level = intent?.getIntExtra("level", -1) ?: -1
                if (level >= 0) setVolume(level)
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        unregisterFlashlightCallback()
        serviceScope.cancel()
        super.onDestroy()
    }

    // ── State Polling ─────────────────────────────────────────────────────────

    private fun startStatePolling() {
        serviceScope.launch {
            while (isActive) {
                _deviceState.value = buildDeviceState()
                delay(2000L)
            }
        }
    }

    private fun buildDeviceState(): DeviceState {
        val am = getSystemService(AudioManager::class.java)
        val bm = getSystemService(BluetoothManager::class.java)
        val wm = applicationContext.getSystemService(WifiManager::class.java)

        return DeviceState(
            isWifiEnabled      = wm?.isWifiEnabled ?: false,
            isBluetoothEnabled = bm?.adapter?.isEnabled ?: false,
            isFlashlightOn     = _flashlightOn.value,
            volumeLevel        = am?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 0,
            maxVolume          = am?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: 15,
            batteryLevel       = getBatteryLevel(),
            isCharging         = isCharging(),
            isDoNotDisturb     = isDndEnabled(),
            brightnessLevel    = getBrightness(),
            currentApp         = JarvisAccessibilityService.foregroundPackage.value
        )
    }

    // ── Flashlight ────────────────────────────────────────────────────────────

    private var cameraManager: CameraManager? = null
    private var torchCameraId: String?        = null

    private val torchCallback = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            if (cameraId == torchCameraId) _flashlightOn.value = enabled
        }
        override fun onTorchModeUnavailable(cameraId: String) {
            _flashlightOn.value = false
        }
    }

    private fun registerFlashlightCallback() {
        cameraManager = getSystemService(CameraManager::class.java)
        torchCameraId = cameraManager?.cameraIdList?.firstOrNull()
        cameraManager?.registerTorchCallback(torchCallback, null)
    }

    private fun unregisterFlashlightCallback() {
        cameraManager?.unregisterTorchCallback(torchCallback)
    }

    fun toggleFlashlight() {
        serviceScope.launch {
            val newState = !_flashlightOn.value
            try {
                val id = torchCameraId ?: return@launch
                cameraManager?.setTorchMode(id, newState)
            } catch (e: Exception) {
                android.util.Log.e("DeviceCtrl", "Flashlight toggle failed", e)
            }
        }
    }

    fun setFlashlight(on: Boolean) {
        serviceScope.launch {
            try {
                val id = torchCameraId ?: return@launch
                cameraManager?.setTorchMode(id, on)
            } catch (e: Exception) {
                android.util.Log.e("DeviceCtrl", "Flashlight set failed", e)
            }
        }
    }

    // ── Volume ────────────────────────────────────────────────────────────────

    fun setVolume(level: Int) {
        val am  = getSystemService(AudioManager::class.java)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, level.coerceIn(0, max), 0)
    }

    fun adjustVolume(direction: Int) {
        val am = getSystemService(AudioManager::class.java)
        am.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            direction,
            AudioManager.FLAG_SHOW_UI
        )
    }

    fun muteVolume() {
        val am = getSystemService(AudioManager::class.java)
        am.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            AudioManager.ADJUST_MUTE,
            AudioManager.FLAG_SHOW_UI
        )
    }

    // ── Bluetooth ─────────────────────────────────────────────────────────────

    @Suppress("DEPRECATION", "MissingPermission")
    fun setBluetooth(enable: Boolean) {
        val adapter = getSystemService(BluetoothManager::class.java)?.adapter ?: return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            if (enable) adapter.enable() else adapter.disable()
        } else {
            // Android 13+ requires user action via panel
            openBluetoothSettings()
        }
    }

    private fun openBluetoothSettings() {
        val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(intent)
    }

    // ── WiFi ──────────────────────────────────────────────────────────────────

    fun openWifiSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val panel = Intent(Settings.Panel.ACTION_WIFI).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(panel)
        } else {
            @Suppress("DEPRECATION")
            val wm = applicationContext.getSystemService(WifiManager::class.java)
            // Direct toggle only available pre-Android 10
        }
    }

    // ── Brightness ────────────────────────────────────────────────────────────

    fun setBrightness(level: Int) {
        try {
            if (Settings.System.canWrite(this)) {
                Settings.System.putInt(
                    contentResolver,
                    Settings.System.SCREEN_BRIGHTNESS,
                    level.coerceIn(0, 255)
                )
            } else {
                val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                startActivity(intent)
            }
        } catch (e: Exception) {
            android.util.Log.e("DeviceCtrl", "Brightness set failed", e)
        }
    }

    // ── DND ───────────────────────────────────────────────────────────────────

    fun setDoNotDisturb(enable: Boolean) {
        val nm = getSystemService(android.app.NotificationManager::class.java)
        if (nm.isNotificationPolicyAccessGranted) {
            nm.setInterruptionFilter(
                if (enable) android.app.NotificationManager.INTERRUPTION_FILTER_NONE
                else android.app.NotificationManager.INTERRUPTION_FILTER_ALL
            )
        } else {
            startActivity(
                Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            )
        }
    }

    // ── System Navigation (via Accessibility) ─────────────────────────────────

    fun goHome()    = JarvisAccessibilityService.instance?.goHome()
    fun goBack()    = JarvisAccessibilityService.instance?.goBack()
    fun goRecents() = JarvisAccessibilityService.instance?.goRecents()

    fun tapAt(x: Float, y: Float)   = JarvisAccessibilityService.instance?.performTap(x, y)
    fun swipe(sx: Float, sy: Float,
              ex: Float, ey: Float) = JarvisAccessibilityService.instance?.performSwipe(sx, sy, ex, ey)

    fun clickByText(text: String)   = JarvisAccessibilityService.instance?.clickByText(text) ?: false
    fun readScreen()                = JarvisAccessibilityService.instance?.extractScreenText() ?: ""

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun getBatteryLevel(): Int {
        val filter = android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val intent = registerReceiver(null, filter) ?: return 100
        val level  = intent.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, 100)
        val scale  = intent.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100)
        return (level * 100 / scale.toFloat()).toInt()
    }

    private fun isCharging(): Boolean {
        val filter = android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val intent = registerReceiver(null, filter) ?: return false
        val status = intent.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, -1)
        return status == android.os.BatteryManager.BATTERY_STATUS_CHARGING ||
               status == android.os.BatteryManager.BATTERY_STATUS_FULL
    }

    private fun isDndEnabled(): Boolean {
        val nm = getSystemService(android.app.NotificationManager::class.java)
        return nm.currentInterruptionFilter ==
               android.app.NotificationManager.INTERRUPTION_FILTER_NONE
    }

    private fun getBrightness(): Int = try {
        Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
    } catch (e: Exception) { 128 }
}
