package com.jarvis.assistant.core.utils

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.jarvis.assistant.JarvisApplication
import com.jarvis.assistant.MainActivity
import com.jarvis.assistant.R
import com.jarvis.assistant.core.constants.AppConstants
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NotificationHelper @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val manager: NotificationManager
        get() = context.getSystemService(NotificationManager::class.java)

    private fun openJarvisIntent(): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            action = AppConstants.Actions.OPEN_MAIN
            flags  = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        return PendingIntent.getActivity(
            context, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun buildVoiceNotification(isListening: Boolean = false): Notification =
        NotificationCompat.Builder(context, JarvisApplication.CHANNEL_VOICE)
            .setContentTitle(if (isListening) "JARVIS is Listening" else "JARVIS Voice")
            .setContentText(if (isListening) "Speak now…" else "Say \"Hey Jarvis\" to activate")
            .setSmallIcon(R.drawable.ic_jarvis_logo)
            .setOngoing(true)
            .setSilent(true)
            .setContentIntent(openJarvisIntent())
            .build()

    fun buildOverlayNotification(): Notification =
        NotificationCompat.Builder(context, JarvisApplication.CHANNEL_OVERLAY)
            .setContentTitle("JARVIS Overlay Active")
            .setContentText("Floating assistant is running")
            .setSmallIcon(R.drawable.ic_jarvis_logo)
            .setOngoing(true)
            .setSilent(true)
            .setContentIntent(openJarvisIntent())
            .build()

    fun buildAiNotification(status: String = "Processing…"): Notification =
        NotificationCompat.Builder(context, JarvisApplication.CHANNEL_AI)
            .setContentTitle("JARVIS AI")
            .setContentText(status)
            .setSmallIcon(R.drawable.ic_jarvis_logo)
            .setOngoing(false)
            .setSilent(true)
            .build()

    fun buildDeviceNotification(): Notification =
        NotificationCompat.Builder(context, JarvisApplication.CHANNEL_DEVICE)
            .setContentTitle("JARVIS Device Control")
            .setContentText("Device automation active")
            .setSmallIcon(R.drawable.ic_jarvis_logo)
            .setOngoing(true)
            .setSilent(true)
            .setContentIntent(openJarvisIntent())
            .build()

    // Alias for backward compat
    fun buildDeviceControlNotification() = buildDeviceNotification()

    fun buildModelDownloadNotification(
        modelName: String,
        progress: Int
    ): Notification =
        NotificationCompat.Builder(context, JarvisApplication.CHANNEL_AI)
            .setContentTitle("Downloading $modelName")
            .setContentText("$progress%")
            .setSmallIcon(R.drawable.ic_jarvis_logo)
            .setProgress(100, progress, progress == 0)
            .setOngoing(true)
            .setSilent(true)
            .build()
}
